import { FieldsModel } from '@/models/Fields';
import { ApiError, ApiResponse, asyncHandler } from '@/utils';


const upsertSingleObject = (obj: any, key: string, value: any, userId: string) => {
  if(Object.hasOwn(value, '_id')){
    const subDocumentId = value._id;
    const subDocumentKey = `${key}._id`;
    const updateKey = `${key}.$`;

    return FieldsModel.updateOne(
      { 
        UserId: userId.toObjectId(), 
        [subDocumentKey]: subDocumentId.toObjectId() 
      },
      { $set: { [updateKey]: value } }
    ).exec();
  }else{
    return FieldsModel.updateOne(
      { UserId: userId.toObjectId() },
      { $push: { [key]: value } }
    ).exec();
  }
}

export const PATCH = asyncHandler(true, async (req: Request) => {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get('userId');
  
  if (!userId) {
    throw new ApiError(400, 'UserId  is required.');
  }

  const fieldsData = await req.json();

    const result = await FieldsModel.updateOne(
      { UserId: userId.toObjectId() },
      fieldsData,
      { upsert: true, new: true }
    );

    if (result.modifiedCount === 0 && result.upsertedCount === 0) {
      throw new ApiError(404, 'User not found or no changes made.');
    }

    return new ApiResponse(200, result, 'Fields updated/created successfully.');

  // const existingFields = await FieldsModel.findOne({UserId: userId.toObjectId()});
  
  // if(existingFields){
  //   const promises = [fieldsData].getEntries().map(([key, value]: [key: string, value: any ]) => {
  //     if(typeof value === 'string'){
  //       return existingFields.updateOne({ $set: { [key]: value } }).exec();
  //     }

  //     if ([value].checkType().isObject()) {
  //       return upsertSingleObject(existingFields, key, value, userId);
  //     }

  //     if([value].checkType().isArray()){
  //       return value.map((val: any) => upsertSingleObject(existingFields, key, val, userId));
  //     }
  //   });

  //   await Promise.all(promises);

  //   await existingFields.save();

  //   const updatedRecord = await FieldsModel.findOne({UserId: userId.toObjectId()});
    

  //   return new ApiResponse(200, updatedRecord, 'Fields updated successfully.');
  // }else {
  //   const fields = new FieldsModel({
  //     UserId: userId.toObjectId(),
  //     ...fieldsData
  //   });
  //   await fields.save();
  //   return new ApiResponse(200, fields, 'Fields created successfully.');
  // }
});


