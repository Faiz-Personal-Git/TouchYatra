import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { ProjectModel } from "@/models";
import { Collections } from "@/constants";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {id: string}}) => {
    const projects = await ProjectModel.aggregate([
        {$match: {_id: params.id.toObjectId()}},
        {
            $unwind: {
                path: '$TeamMembers',
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: Collections.TeamMembers,
                localField: 'TeamMembers',
                foreignField: '_id',
                as: 'TeamMembers'
            }
        },
        {
            $group: {
                _id: '$_id',
                UserId: {$first: "UserId"},
                ProjectName: { $first: '$ProjectName' },
                ProjectType: { $first: '$ProjectType' },
                StartDate: { $first: '$StartDate' },
                EndDate: { $first: '$EndDate' },
                Description: { $first: '$Description' },
                TechnologiesUsed: { $first: '$TechnologiesUsed' },
                TeamMembers: { $push: '$TeamMembers' },
                ProjectUrl: { $first: '$ProjectUrl' },
                ImageUrl: { $first: '$ImageUrl' },
                Contributions: { $first: '$Contributions' },
                createdAt: { $first: '$createdAt' },
                updatedAt: { $first: '$updatedAt' },
            }
        }
    ])

    if(!projects.length){
        throw new ApiError(404, "Project not found.");
    }

    return new ApiResponse(
        200, 
        projects[0], 
        'Project fetched successfully.'
    );
})