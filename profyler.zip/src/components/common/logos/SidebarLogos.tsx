"use client";
import React from "react";
import { motion } from "framer-motion";

export interface LogoIconProps {
    onClick?: () => void;
    icon?: React.ReactNode;
}

export interface LogoProps extends LogoIconProps {
    label?: string;
}

export const Logo = ({label, onClick, icon}: LogoProps) => {
    return (
      <a
        onClick={onClick}
        className="font-normal flex space-x-2 items-center text-sm text-black py-1 relative z-20"
      >
        <div className="h-5 w-6 bg-black dark:bg-white rounded-br-lg rounded-tr-sm rounded-tl-lg rounded-bl-sm flex-shrink-0">
            {icon}
        </div>
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="font-medium text-black dark:text-white whitespace-pre"
        >
          {label}
        </motion.span>
      </a>
    );
  };
  export const LogoIcon = ({onClick, icon}: LogoIconProps) => {
    return (
      <a
        onClick={onClick}
        className="font-normal flex space-x-2 items-center text-sm text-black py-1 relative z-20"
      >
        <div className="h-5 w-6 bg-black dark:bg-white rounded-br-lg rounded-tr-sm rounded-tl-lg rounded-bl-sm flex-shrink-0">
            {icon}
        </div>
      </a>
    );
  };