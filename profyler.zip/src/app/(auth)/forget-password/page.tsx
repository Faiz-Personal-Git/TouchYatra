import {ForgetPassword} from '@/views/(auth)'
import { Metadata } from 'next'

export default function page(){
  return <ForgetPassword/>
};

export const metadata: Metadata = {
  title: `Profyler - Forget Password`,
  description: `Forgot your Password`,
  icons: {
    icon: `path to asset file`,
  },
}