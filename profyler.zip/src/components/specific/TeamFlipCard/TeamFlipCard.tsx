import { cn } from '@/lib/utils'
import { modelTypes } from '@/types'
import React from 'react'
import { FaFacebook, FaGithub, FaInstagram, FaLinkedin, FaTwitter } from 'react-icons/fa'
import { imagePlaceholders } from '@/constants'
import css from  "./custom.module.css"

export function TeamFlipCardContainer({className, children}: {className?: string, children: React.ReactNode | React.ReactElement | React.JSX.Element}) {
    return (
        <ul className={cn("grid lg:grid-cols-3 sm:grid-cols-2 gap-8 p-12", className)}>
            {children}
        </ul>
    )
}

export  function TeamFlipCard({ member, onClick }: {member: modelTypes.Team_Members, onClick: () => void}) {
    console.log(member.ImageUrl);
  return (
    <li className={cn(
        "md:max-w-[415px] max-w-full text-white",
        css["box-item"]
    )}>
        <div className={cn(css["flip-box"])}>
            {/* <!-- FLIP BOX FRONT --> */}
            <div className={cn(
                " sm:min-h-[450px] min-h-[375px] bg-no-repeat",
                css["flip-box-front"]
            )} style={{backgroundImage: `url(${member.ImageUrl?.toUrl()?.toReplaceTrim(imagePlaceholders.avtar1)})`}}>
                {/* <!-- MEMBER DETAILS --> */}
                <div className={cn("color-white", css.inner)}>
                    <h3 className={cn(
                        "flip-box-header capitalize font-semibold text-3xl"
                    )}>
                        {member.MemberName}
                    </h3>
                    <p className="capitalize text-primary text-white">{member.Designation}</p>
                </div>
            </div>
            {/* <!-- FLIP BOX FRONT --> */}

            {/* <!-- FLIP BOX BACK --> */}
            <div className={cn(
                "text-center sm:min-h-[450px] min-h-[375px] bg-no-repeat",
                css["flip-box-back"]
            )} style={{backgroundImage: `url(${member.ImageUrl?.toUrl()?.toReplaceTrim(imagePlaceholders.avtar1)})`}}>
                {/* <!-- MEMBER DETAILS --> */}
                <div className={css["inner"]}>
                    <h3 className={cn(
                        "flip-box-header capitalize font-semibold text-3xl cursor-pointer"
                    )} onClick={onClick}>
                        {member.MemberName}
                    </h3>
                    <p className="-mt-1 capitalize">{member.Designation}</p>

                    {member.Experience && <p className="capitalize mt-2">{member.Experience} years of Experience</p>}

                    <hr className="w-full h-px bg-gray-600 my-3" />

                    <span className="text-base mt-2 line-clamp-2">
                        {member.Bio?.toMoreSlice(100)}
                    </span>
                    <span className="text-base mt-2 line-clamp-2">
                        {member.Skills?.join(", ")}
                    </span>

                    {/* <!-- SOCIAL ICONS --> */}
                    <ul className="flex items-center justify-center gap-2 text-2xl text-gray-100 mt-5">
                        {/* <!-- FACEBOOK --> */}
                        {
                            member.Social?.Facebook && (
                                <FlipCardSocialLink href={member.Social?.Facebook?.toUrl("Facebook")} name={member.MemberName}>
                                    <FaFacebook size={24} className='text-blue-500' />
                                    {/* <i className="fa-brands fa-facebook-f"></i> */}
                                </FlipCardSocialLink>
                            )
                        }
                        {/* <!-- TWITTER --> */}
                        {
                            member.Social?.Twitter && (
                                <FlipCardSocialLink href={member.Social?.Twitter} name={member.MemberName}>
                                    <FaTwitter size={24} className='text-blue-500' />
                                    {/* <i className="fa-brands fa-github"></i> */}
                                </FlipCardSocialLink>
                            )
                        }
                        {/* <!-- LINKEDIN --> */}
                        {
                            member.Social?.LinkedIn && (
                                <FlipCardSocialLink href={member.Social?.LinkedIn?.toUrl("Linkedin")} name={member.MemberName}>
                                    <FaLinkedin size={24} className='text-blue-500' />
                                    {/* <i className="fa-brands fa-linkedin-in"></i> */}
                                </FlipCardSocialLink>
                            )
                        }
                        {/* <!-- INSTAGRAM --> */}
                        {
                            member.Social?.Instagram && (
                                <FlipCardSocialLink href={member.Social?.Instagram?.toUrl("Instagram")} name={member.MemberName}>
                                    <FaInstagram size={24} className='text-blue-500' />
                                    {/* <i className="fa-brands fa-instagram"></i> */}
                                </FlipCardSocialLink>
                            )
                        }
                        {/* <!-- GITHUB --> */}
                        {
                            member.Social?.Github && (
                                <FlipCardSocialLink href={member.Social?.Github?.toUrl("GitHub")} name={member.MemberName}>
                                    <FaGithub size={24} className='text-blue-500' />
                                    {/* <i className="fa-brands fa-github"></i> */}
                                </FlipCardSocialLink>
                            )
                        }
                    </ul>
                    
                </div>
            </div>
            {/* <!-- FLIP BOX BACK --> */}
        </div>
    </li>
  )
}

export const FlipCardSocialLink = ({
    href,
    name,
    children
}: {
    href: string,
    name: string,
    children: React.ReactNode | React.ReactElement<any> | React.JSX.Element
}) => {
    return (
        <li>
            <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`${name}'s GitHub profile`}
                className="w-10 h-10 grid place-items-center rounded-full border border-gray-300 hover:text-gray-900 hover:border-green-400 hover:-translate-y-1 hover:scale-105 hover:bg-green-500 transition-all duration-500"
            >
                {children}
            </a>
        </li>
    )
}