import { ApiResponse, callApi } from "@/utils";

export async function signUp(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/sign-up", data });
}

export async function checkEmailUniqueness(Email: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: "/api/v1/check-email-unique", params: {Email}});
}

export async function checkUsernameUniqueness(UserName: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: "/api/v1/check-username-unique", params: {UserName}});
}

export async function resendVerificationToken(UserName: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: "/api/v1/resend-verification-token", params: {UserName}});
}

export async function verifyToken(Token: string): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/verify-token", data: {Token}});
}

export async function verifyAccount(Token: string): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/verify-account", data: {Token}});
}

export async function sendResetPasswordToken(UserName: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: "/api/v1/send-reset-password-token", params: {UserName}});
}

type ResetPasswordProps = {
    Token: string;
    Password: string;
}

export async function ResetPassword(data: ResetPasswordProps): Promise<ApiResponse>{
    return callApi({method: 'POST', url: "/api/v1/reset-password", data});
}