import { DatabaseConfigOptions, Databases } from "@/types";
import { env } from "@/configuration"

export const databases: Databases = {
    main: "main",
    common: "common",
    other: "other"
}


export const databaseConfigOptions: DatabaseConfigOptions[] = [
    {name: databases.main, connectionString: env.mongoUri as string},
    {name: databases.common, connectionString: env.commonDbUrl as string}
]

