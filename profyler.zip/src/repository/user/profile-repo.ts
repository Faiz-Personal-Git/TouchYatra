import { ApiResponse, callApi } from "@/utils";

export async function uploadAvtar(data: FormData): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/profile/upload-avtar", data});
}

export async function uploadCoverImage(data: FormData): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/profile/upload-cover-image", data});
}

export async function uploadLogo(data: FormData): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/profile/upload-logo", data});
}