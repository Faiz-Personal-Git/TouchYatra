import { resend } from "@/lib"; 
import { env } from "@/configuration"

export interface EmailPayloadBase {
    to: string;
    subject: string;
    cc?: string;
    bcc?: string;
    replyTo?: string;
    attachments?: any;
}

export interface EmailPayloadWithReact extends EmailPayloadBase {
    react: any;
    text?: never;
}

export interface EmailPayloadWithText extends EmailPayloadBase {
    text: string;
    react?: never;
}

export type EmailPayload = EmailPayloadWithReact | EmailPayloadWithText;

export async function sendEmail(
    payload: EmailPayload
): Promise<boolean> {
    try{
        const response = await resend.emails.send({
            from: env.resendEmail || "",
            ...payload
        })
        console.log("Email sent", response)
        return !!response.data
    }catch(err){
        console.error("Email sent", err);
        return false
    }
}