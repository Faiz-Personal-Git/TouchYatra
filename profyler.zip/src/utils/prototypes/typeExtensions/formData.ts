
type FormDataValue =
  | Array<any>
  | Blob
  | Blob[]
  | File
  | File[]
  | FileList
  | Record<string, any>
  | string
  | number
  | Date
  | any

function appendToFormData(formData: FormData, key: string, value: FormDataValue, parentKey = "") {
  if (value instanceof Blob || value instanceof File) {
    formData.append(key, value)
  } else if (value instanceof FileList) {
    Array.from(value).forEach((file, index) => {
      formData.append(`${key}[${index}]`, file)
    })
  } else if (Array.isArray(value)) {
    value.forEach((item, index) => {
      appendToFormData(formData, `${key}[${index}]`, item, key)
    })
  } else if (value instanceof Date) {
    formData.append(key, value.toISOString())
  } else if (typeof value === "object" && value !== null) {
    Object.keys(value).forEach((nestedKey) => {
      const fullKey = parentKey ? `${parentKey}[${key}][${nestedKey}]` : `${key}[${nestedKey}]`
      appendToFormData(formData, fullKey, value[nestedKey], key)
    })
  } else {
    formData.append(key, String(value))
  }
}

export function objectToFormData(obj: Record<string, any>): FormData {
  const formData = new FormData()
  Object.keys(obj).forEach((key) => {
    appendToFormData(formData, key, obj[key])
  })
  return formData
}

// Extend the Array prototype
Array.prototype.toDeepFormData = function () {
  if (this.length === 0 || typeof this[0] !== "object") {
    throw new Error("Array must contain at least one object")
  }
  return objectToFormData(this[0])
}


declare global {
    interface Array<T> {
      toDeepFormData(): FormData
    }
  }

  export {}