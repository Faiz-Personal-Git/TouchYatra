import axios, { AxiosError } from 'axios'
import { ApiResponse } from './ApiResponse';

export type CallApiArg = {
    method?: 'GET' | 'PATCH' | 'PUT' | 'POST' | 'DELETE';
    baseURL?: string;
    url: string;
    data?: FormData | string | any;
    params?: Object;
    headers?: Object;
    responseType?: "json" | "blob" | "text";
}

export async function callApi({ method = "GET", baseURL, url, data, params, headers, responseType = "json", ...rest }: CallApiArg) : Promise<ApiResponse> {
    const api = axios.create({
        baseURL,
        headers,
        ...rest
    })

    try {
        const res = await api.request<ApiResponse>({method, url, data, params});
        return {...res.data, statusCode: res.status};
    } catch (error) {
        const axiosError = error as AxiosError<ApiResponse>;

        if (!(axiosError.response?.data)) {
            return new ApiResponse(axiosError.status || 500, axiosError.response, `Network error or server unreachable: ${axiosError.message}`, null, false);
        }
        
        return  {...axiosError.response.data, statusCode: axiosError.status} as ApiResponse;
    }
}