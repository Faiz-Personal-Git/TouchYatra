import { asyncHandler, ApiResponse } from "@/utils";
import { ExperienceModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const experiences = (await ExperienceModel.find({ UserId: params.userid?.toObjectId() })) ?? [];
    return new ApiResponse(
        200, 
        experiences.toRecords(),
        'Experience list fetched successfully.'
    );
})