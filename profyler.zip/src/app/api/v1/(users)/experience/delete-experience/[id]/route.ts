import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { ExperienceModel } from "@/models";
import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

type paramType = {
    params: {id: string}
}

export const DELETE = asyncHandler(true, async (req: Request, {params}: paramType) => {
    const id = params?.id;
    if(!id){
        throw new ApiError(404, "Id not found")
    }
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const experience = await ExperienceModel.findById(id);
    if(!experience){
        throw new ApiError(404, "Experience not found.")
    }

    if(experience.UserId.toString() !== session.user._id?.toString()){
        throw new ApiError(401, "Unauthorized request.")
    }

    const isDeleted = await ExperienceModel.findByIdAndDelete(id);
    if(!isDeleted){
        throw new ApiError(500, "Failed to delete experience.", isDeleted)
    }
    return new ApiResponse( 200, null, 'Experience deleted successfully.' );
})
