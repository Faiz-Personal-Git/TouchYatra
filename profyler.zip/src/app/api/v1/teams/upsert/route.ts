import { TeamMemberModel } from "@/models";
import { ApiError, ApiResponse, asyncHandler, extractArrayNotationFormData, serverSessions, uploadFile } from "@/utils";
import { NextRequest } from "next/server";

export const POST  = asyncHandler(
    true,
    async function(req: NextRequest){
        const session = await serverSessions();
        if(!session?.user){
            throw new ApiError(401, "Please login first.")
        }
    
        const data = await extractArrayNotationFormData(req)
        
        const isForUpdate = !!data._id;
        const isFileThere = !!(data?.ImageFile instanceof File);
        if(isFileThere){
            data.ImageUrl = await uploadFile(data.ImageFile as File, "/teams");
        }
        if(isForUpdate){
            const oldRecord = await TeamMemberModel.findById(data._id);
            if(!oldRecord){
                throw new ApiError(404, "Record not found.")
            }
    
            if(
                data.UserId? (
                    oldRecord.UserId.toString() !== data.UserId.toString() && 
                    oldRecord.UserId.toString()!== session.user._id?.toString()
                )
                : oldRecord.UserId.toString() !== session.user._id?.toString()
            ){
                throw new ApiError(401, "Unauthorized request.")
            }
        }
    
        if(!data?.UserId){
            data.UserId = session.user._id?.toObjectId();
        }

        //Need work for file upload

        const teamMember = isForUpdate
            ? await TeamMemberModel.findByIdAndUpdate(data._id, data, { new: true })
            : await TeamMemberModel.create(data);

        if(!teamMember){
            throw new ApiError(500, "Failed to save team member.");
        }
        await teamMember.save();
        return new ApiResponse(isForUpdate? 200 : 201, teamMember, "Team member saved successfully.");
    }
)