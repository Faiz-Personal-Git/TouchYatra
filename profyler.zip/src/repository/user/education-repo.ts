import { ApiResponse, callApi } from "@/utils";

export async function upsertEducation(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/educations/upsert", data });
}

export async function userEducations(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/educations/user-educations/${userId}`});
}

export async function getEducationById(EducationsId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/educations/getEducationById/${EducationsId}`});
}

export async function deleteEducation(EducationsId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/educations/delete-education/${EducationsId}`});
}