"use client"

import React, { useRef, useState, useEffect } from "react";
import { IconUpload, IconTrash, IconReload, IconFile, IconCrop, IconFrameOff, IconCircleCheck, IconCircleX } from "@tabler/icons-react";
import { useDropzone } from "react-dropzone";
import Image from 'next/image'
import Cropper from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { useToast } from "@/hooks";

interface FileUploadProps {
    onChange: (files: File[]) => void;
    accept?: {[key: string]: string[]};
    minSize?: number;
    maxSize?: number;
    maxFiles?: number;
    disabled?: boolean;
    autoFocus?: boolean;
    uploadedFiles?: string[] | string;
    removeUploadedFile?: (index: number) => void
  }

export function FileDropzone({
    onChange,
    accept,
    minSize,
    maxSize = 3,
    maxFiles = 1,
    disabled,
    autoFocus,
    uploadedFiles = [],
    removeUploadedFile
  }: FileUploadProps) {
    const [files, setFiles] = useState<File[]>([]);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [acceptedFiles] = useState<string>(accept ? Object.values(accept).reduce((acc, val) => `${acc},${val.join(",")}`, "") : "")
    const {toast} = useToast()

    useEffect(() => {
      if(files.length){
        onChange(files)
      }
    }, [files.length, JSON.stringify(files)])

    const handleFileChange = (newFiles: File[]) => {
      if (maxFiles !== undefined && files.length + newFiles.length > maxFiles) {
        toast({
          description: "Maximum file count reached.",
          variant: "destructive",
        })
        return;
      }
      setFiles((prevFiles) => maxFiles === 1? newFiles : [...prevFiles, ...newFiles]);
    };

    const handleClick = () => {
      fileInputRef.current?.click();
    };

    const multipleProp = maxFiles > 1 ? {multiple: true} : {};

    const { getRootProps, isDragActive } = useDropzone({
      multiple: maxFiles > 1,
      noClick: true,
      noKeyboard: false,
      onDrop: handleFileChange,
      onDropRejected: (error) => {
        const errors = error.map(({errors, file: {name}}) => `${name} - ${errors[0].message}`).join('\n');
        toast({
          description: errors,
          variant: "destructive",
        })
      },
      accept,
      minSize,
      maxSize: maxSize * 1024 * 1024,
      maxFiles,
      disabled,
      autoFocus
      // accept: {
      //   'image/*': ['.png', '.jpg', '.jpeg', '.gif'],
      //   'application/pdf': ['.pdf'],
      //   'text/csv': ['.csv'],
      // }
      

      // list for accept

      // accept: {
      //   'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.svg', '.ico', '.tiff', '.tif', '.heic', '.heif'],
      //   'application/pdf': ['.pdf'],
      //   'text/csv': ['.csv'],
      //   'text/plain': ['.txt', '.log'],
      //   'application/msword': ['.doc'],
      //   'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      //   'application/vnd.ms-excel': ['.xls'],
      //   'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      //   'application/vnd.ms-powerpoint': ['.ppt'],
      //   'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      //   'audio/*': ['.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac', '.wma'],
      //   'video/*': ['.mp4', '.mov', '.avi', '.mkv', '.wmv', '.flv', '.mpeg', '.webm', '.3gp'],
      //   'application/zip': ['.zip'],
      //   'application/x-rar-compressed': ['.rar'],
      //   'application/x-tar': ['.tar'],
      //   'application/gzip': ['.gz'],
      //   'application/x-7z-compressed': ['.7z'],
      //   'application/json': ['.json'],
      //   'application/xml': ['.xml'],
      //   'text/html': ['.html', '.htm'],
      //   'text/css': ['.css'],
      //   'application/javascript': ['.js'],
      //   'application/typescript': ['.ts', '.tsx'],
      //   'application/vnd.android.package-archive': ['.apk'],
      //   'application/x-apple-diskimage': ['.dmg'],
      //   'font/woff': ['.woff'],
      //   'font/woff2': ['.woff2'],
      //   'image/vnd.adobe.photoshop': ['.psd'],
      //   'application/illustrator': ['.ai'],
      //   'application/postscript': ['.eps'],
      //   'model/vnd.collada+xml': ['.dae'],
      //   'model/gltf+json': ['.gltf'],
      //   'model/gltf-binary': ['.glb'],
      //   'model/obj': ['.obj'],
      //   'application/rtf': ['.rtf'],
      //   'audio/midi': ['.midi', '.mid'],
      //   'application/vnd.mozilla.xul+xml': ['.xul'],
      //   'application/vnd.oasis.opendocument.text': ['.odt'],
      //   'application/vnd.oasis.opendocument.spreadsheet': ['.ods'],
      //   'application/vnd.oasis.opendocument.presentation': ['.odp'],
      //   'application/vnd.oasis.opendocument.graphics': ['.odg'],
      // }
    });
    
    const handleRemoveFile = (indexToRemove: number) => {
      const newFiles = files.filter((_, index) => index !== indexToRemove);
      setFiles(newFiles);
    };
    
    const handleCropFile = (idx: number, file: File) => {
      console.log({file})
      setFiles((prevFiles) => prevFiles.map((f, i) => i === idx ? file : f));
    }

  return (
    <div {...getRootProps()}>
        <div className={`cursor-pointer p-12 flex justify-center bg-white border border-dashed border-gray-300 rounded-xl dark:bg-neutral-800 dark:border-neutral-600  ${isDragActive ? "border-blue-500 bg-blue-50" : "border-gray-300"}`} onClick={handleClick}>
            <input
                ref={fileInputRef}
                id="file-upload-handle"
                type="file"
                onChange={(e) => handleFileChange(Array.from(e.target.files || []))}
                className="hidden"
                accept={acceptedFiles}
                size={maxSize}
                {...multipleProp}
            />
          <div className="text-center">
            <span className="inline-flex justify-center items-center size-16 bg-gray-100 text-gray-800 rounded-full dark:bg-neutral-700 dark:text-neutral-200">
              <IconUpload className="h-4 w-4 size-6 text-neutral-600 dark:text-neutral-400" />
            </span>

            {isDragActive ? (
              <div className="mt-4 flex flex-wrap justify-center text-sm leading-6 text-gray-600">
                <span className="pe-1 font-medium text-gray-800 dark:text-neutral-200">
                  Drop it
                </span>
              </div>
            ) : (
              <div className="mt-4 flex flex-wrap justify-center text-sm leading-6 text-gray-600">
                <span className="pe-1 font-medium text-gray-800 dark:text-neutral-200">
                  Drop your file here or
                </span>
                <span className="bg-white font-semibold text-blue-600 hover:text-blue-700 rounded-lg decoration-2 hover:underline focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-600 focus-within:ring-offset-2 dark:bg-neutral-800 dark:text-blue-500 dark:hover:text-blue-600">browse</span>
              </div>
            )}
      
            <p className="mt-1 text-xs text-gray-400 dark:text-neutral-400">
              Pick a file up to {maxSize}MB.
            </p>
          </div>
        </div>
      
        <div className="mt-4 space-y-2 empty:mt-0" data-hs-file-upload-previews="">
            {
                files.length > 0 && files.map((file, idx) => (
                    <SelectedFilesCard key={idx} idx={idx} file={file} handleCropFile={handleCropFile} handleRemoveFile={handleRemoveFile}/>
                ))
            }
            {
              (typeof uploadedFiles === "string" && uploadedFiles.trim() !== "") ? (
                <UploadedFileCard key={0} idx={0} path={uploadedFiles} remove={removeUploadedFile} />
              ) : (Array.isArray(uploadedFiles) && uploadedFiles.length > 0) && uploadedFiles.map((path, idx) => (
                path.trim() !== "" && <UploadedFileCard key={idx} idx={idx} path={path} remove={removeUploadedFile} />
              ))
            }
        </div>
    </div>
  )
}

interface SelectedFileCardProps {
  file: File,
  idx: number,
  handleCropFile: (idx: number, file: File) => void,
  handleRemoveFile: (indexToRemove: number) => void,
}

const SelectedFilesCard = ({file, idx, handleCropFile, handleRemoveFile}: SelectedFileCardProps) => {
  const cropperRef = useRef(null)
  const [showCrop, setShowCrop] = useState(false)
  const [cropSrc, setCropSrc] = useState<any>("")
  const [originalFile, setOriginalFile] = useState<File | null>(null)

  const getCroppedImageAsFile = (croppedImage: string) : any => {    
    const parts: any = croppedImage.split(',');
    const mime = parts[0].match(/:(.*?);/)[1];
    const byteString = atob(parts[1]);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);
  
    for (let i = 0; i < byteString.length; i++) {
      uint8Array[i] = byteString.charCodeAt(i);
    }

    const newFile = new Blob([uint8Array], { type: mime });
    return newFile
  };

  const getCropData = () => {
    const cropper = (cropperRef.current as any)?.cropper;
    if (typeof cropper?.getCroppedCanvas() === 'undefined') {
        return;
    }

    const croppedImage = cropper?.getCroppedCanvas()?.toDataURL();
    const newCroppedImage: Blob = getCroppedImageAsFile(croppedImage);
    const newCroppedFile = new File(
      [newCroppedImage],
      file.name, // Use the original file name
      { type: newCroppedImage.type }
    );
    handleCropFile(idx, newCroppedFile)
  };

  const getSource = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setCropSrc(reader.result);
    };
    reader.readAsDataURL(file);
  }

    return (
        <div className="p-3 bg-white border border-solid border-gray-300 rounded-xl dark:bg-neutral-800 dark:border-neutral-600 dz-processing dz-image-preview dz-error dz-complete complete">                            
            <div className="mb-1 flex justify-between items-center">                              
                <div className="flex items-center gap-x-3">                                
                    <span className="size-10 flex justify-center items-center border border-gray-200 text-gray-500 rounded-lg dark:border-neutral-700 dark:text-neutral-500">  
                      {
                        file.type?.toString().startsWith("image") ? (
                          <img className="rounded-lg object-cover h-full"  alt={file.name} src={URL.createObjectURL(file)} />
                        ): (
                          <IconFile className="h-4 w-4 size-6 text-neutral-600 dark:text-neutral-400" />
                        )
                      }
                    </span>                                
                    <div>                                  
                        <p className="text-sm font-medium text-gray-800 dark:text-white">                                    
                            <span className="truncate inline-block max-w-[300px] align-bottom">
                              {file.name}
                            </span>                               
                        </p>                                  
                        <p className="text-xs text-gray-500 dark:text-neutral-500">
                            {file.type} | {(file.size / (1024 * 1024)).toFixed(2)} MB
                        </p>                                  
                        {/* <p className="text-xs text-red-500" style="display: none;" data-hs-file-upload-file-error="">
                            File exceeds size limit.
                        </p>*/}
                    </div>                              
                </div>                              
                <div className="flex items-center gap-x-2">    
                    {/* <button type="button" className="text-gray-500 hover:text-gray-800 focus:outline-none focus:text-gray-800 dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200">
                      <IconReload className="shrink-0 size-5"/>
                    </button>                                 */}
                    {
                      file.type?.toString().startsWith("image") && (
                        <button type="button" onClick={(e) => {
                          e.preventDefault();
                          setOriginalFile(file);
                          getSource(file); 
                          setShowCrop(prev => !prev)
                        }} className="text-gray-500 hover:text-gray-800 focus:outline-none focus:text-gray-800 dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200">
                          {
                            !showCrop? (
                              <IconCrop className="shrink-0 size-5"/>
                            ): (
                              <IconCircleCheck className="shrink-0 size-5"/>
                            )
                          }
                        </button>
                      )
                    }
                    {
                      !showCrop? (
                        <button type="button" className="text-gray-500 hover:text-gray-800 focus:outline-none focus:text-gray-800 dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200" onClick={() => handleRemoveFile(idx)}>       
                          <IconTrash className="shrink-0 size-5"/>                           
                        </button>  
                      ) : (
                        <button type="button" className="text-gray-500 hover:text-gray-800 focus:outline-none focus:text-gray-800 dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200" onClick={() => {
                          setShowCrop(false)
                          handleCropFile(idx, originalFile as File)
                        }}>       
                          <IconCircleX className="shrink-0 size-5"/>                           
                        </button>  
                      )
                    }                            
                </div>                            
            </div>   
            <div>
              {
                showCrop && (
                  <>
                    <Cropper
                        src={cropSrc}
                        style={{ height: "200", width: '100%' }}
                        //initialAspectRatio={16 / 9}
                        //aspectRatio={16 / 9}
                        guides={false}
                        ref={cropperRef}
                        viewMode={1}
                        dragMode={"move"}
                        crop={getCropData}
                    />
                  </>
                )
              }
            </div>                         
        </div> 
    )
}

const UploadedFileCard = ({idx, path, remove}: {idx: number,path?: string, remove?: (index: number) => void}) => {
  const isImage = !!(path && path.toString().split('.')?.[1]?.match(/(jpg|jpeg|png|gif|webp|bmp|svg|ico|tiff|tif|heic|heif)/));
  // const fileName = path && path?.split('/')[path?.split('/').length - 1] || "unknown file";
  const fileName = path ? path.split('\\').pop() : "unknown file";
  console.log(fileName)
  return (
    <div className="p-3 bg-white border border-solid border-gray-300 rounded-xl dark:bg-neutral-800 dark:border-neutral-600 dz-processing dz-image-preview dz-error dz-complete complete">                            
        <div className="mb-1 flex justify-between items-center">                              
            <div className="flex items-center gap-x-3">                                
                <span className="size-10 flex justify-center items-center border border-gray-200 text-gray-500 rounded-lg dark:border-neutral-700 dark:text-neutral-500">  
                  {
                     isImage ? (
                      <img className="rounded-lg object-cover h-full"  alt={fileName} src={path} />
                    ): (
                      <IconFile className="h-4 w-4 size-6 text-neutral-600 dark:text-neutral-400" />
                    )
                  }
                </span>                                
                <div>                                  
                    <p className="text-sm font-medium text-gray-800 dark:text-white">                                    
                        <span className="truncate inline-block max-w-[300px] align-bottom">
                          {fileName}
                        </span>                               
                    </p>                                
                </div>                              
            </div>                              
            <div className="flex items-center gap-x-2">    
                <button type="button" className="text-gray-500 hover:text-gray-800 focus:outline-none focus:text-gray-800 dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200" onClick={(e) => {
                  e.preventDefault();
                  remove && remove(idx)
                }} >       
                      <IconTrash className="shrink-0 size-5"/>                           
                </button>                          
            </div>                            
        </div>                         
    </div> 
)
}