import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { CertificateModel } from "@/models";
import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

type paramType = {
    params: {certificate_id: string}
}

export const DELETE = asyncHandler(true, async (req: Request, {params}: paramType) => {
    const certificateId = params?.certificate_id;
    if(!certificateId){
        throw new ApiError(404, "Id not found")
    }
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const certificate = await CertificateModel.findById(certificateId);
    if(!certificate){
        throw new ApiError(404, "Certificate not found.")
    }

    if(certificate.UserId.toString() !== session.user._id?.toString()){
        throw new ApiError(401, "Unauthorized request.")
    }

    const isDeleted = await CertificateModel.findByIdAndDelete(certificateId);
    if(!isDeleted){
        throw new ApiError(500, "Failed to delete certificate.", isDeleted)
    }
    return new ApiResponse( 200, null, 'Certificate deleted successfully.' );
})