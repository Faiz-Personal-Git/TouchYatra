import mongoose, { Model, Schema } from "mongoose";

export interface Databases {
    main: string;
    common: string;
    other: string;
}

export interface DatabaseConfigOptions {
    name: string;
    connectionString: string;
}

export type ConnectionObject = {
    isConnected?: boolean;
    connectionUrl: string;
    connectionObj?: mongoose.Connection;
    createModel: (modelName: string, schema: Schema) => Model<any>
}

export type ConnectionsTypes = {
    other?: ConnectionObject[];
} & Record<string, ConnectionObject>;