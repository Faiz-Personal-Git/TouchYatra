import React from 'react'
import {SignIn} from '@/views/(auth)'
import { Metadata } from 'next'

export default function Page() {
  return <SignIn/>
}

export const metadata: Metadata = {
  title: `Profyler - Sign in`,
  description: `Signin to your account`,
  icons: {
    icon: `path to asset file`,
  },
}