import {UserModel} from '@/models'
import { z } from 'zod'
import {usernameValidation} from '@/schemas'
import { ApiError, ApiResponse, asyncHandler } from '@/utils'

const UsernameQuerySchema = z.object({
    UserName: usernameValidation
})

export const GET = asyncHandler(true, async (req: Request) => {

    const {searchParams} = new URL(req.url);
    const queryParams = {
        UserName: searchParams.get('UserName')
    };

    //TODO :- validate username with zod
    const result = UsernameQuerySchema.safeParse(queryParams);
    
    if(!result.success){
        const usernameErrors = result.error.format().UserName?._errors || [];
        throw new ApiError(
            400, 
            usernameErrors?.length > 0 ? usernameErrors.join(', ') : "Invalid query parameters.",
            usernameErrors
        );
    }

    const {UserName} = result.data;
    const user = await UserModel.findOne({UserName: UserName.trim().toLowerCase(), IsVerified: true});
    if(user){
        throw new ApiError(400, "Username is already taken.")
    }

    return new ApiResponse(200, null, "Username is unique.");
})