import { TeamMemberModel } from "@/models";
import { ApiError, ApiResponse, asyncHandler } from "@/utils";

export const GET = asyncHandler(
    true,
    async function(req: Request, {params}: {params: {userid: string}}){
        const userId = await params.userid;
        if(!userId){
            throw new ApiError(404, "UserId not found")
        }
        const teams = await TeamMemberModel.find({UserId: userId?.toObjectId()});
        return new ApiResponse(200, {records: teams, totalRecords: teams.length ?? 0}, "Team fetched successfully.");
    }
)