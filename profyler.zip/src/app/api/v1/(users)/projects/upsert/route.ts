import { asyncHandler, ApiError, ApiResponse, serverSessions } from "@/utils";
import { ProjectModel } from "@/models";

export const POST = asyncHandler(true, async (req: Request) => {
    const session = await serverSessions()
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const formData = await req.formData();
    const data = Object.fromEntries(formData) as Record<string, any>;
    const isForUpdate =!!data._id;

    if(isForUpdate){
        const oldRecord = await ProjectModel.findById(data._id);
        if(!oldRecord){
            throw new ApiError(404, "Record not found.")
        }

        if(
            data.UserId? (
                oldRecord.UserId.toString() !== data.UserId.toString() && 
                oldRecord.UserId.toString()!== session.user._id?.toString()
            )
            : oldRecord.UserId.toString() !== session.user._id?.toString()
        ){
            throw new ApiError(401, "Unauthorized request.")
        }
    }

    if(!data.UserId){
        data.UserId = session.user._id?.toObjectId();
    }

    //Need work for file upload

    const project = isForUpdate
        ? await ProjectModel.findByIdAndUpdate(data._id, data, { new: true })
        : await ProjectModel.create(data);

    if(!project){
        throw new ApiError(500, "Failed to save project.");
    }

    await project.save();
    return new ApiResponse(isForUpdate? 200 : 201, project, "project saved successfully.");
});