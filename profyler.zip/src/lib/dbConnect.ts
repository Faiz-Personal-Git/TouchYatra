import mongoose, { Model, Schema } from "mongoose";
import { databases, databaseConfigOptions} from '@/constants'
import { ConnectionObject, ConnectionsTypes } from "@/types";

export const connections : ConnectionsTypes  = {};

export async function dbConnect(name : string = databases.main): Promise<void> {
    if(!Array.isArray(connections[name]) && connections[name]?.isConnected){
        console.log(connections[name])
        console.log(`${name} database is already connected`);
        return;
    }

    let dbConfig = databaseConfigOptions.find(option => option.name === name);

    let connectionName = databases.other;
    let connectionString = name;

    if(dbConfig){
        connectionName = dbConfig.name;
        connectionString = dbConfig.connectionString;
    }

    const isArray = connectionName === databases.other && Array.isArray(connections[connectionName]);

    try {
        if(!isArray){
            connections[connectionName] = createConnection(connectionString);
            if(!connections[connectionName].isConnected){
                console.log(`Database, ${connectionName} connection failed`);
                // process.exit(1);
                return;
            }
            console.log(`Database, ${connectionName} connected successfully`);
            return;
        }

        const isConnectionExist = connections.other?.find(connection => connection?.connectionUrl === connectionString);
        if(isConnectionExist?.isConnected){
            console.log(`Your desired Unknown Database is already connected`)
            return;
        }

        connections.other?.push(createConnection(connectionString));

    } catch (error) {
        process.on('unhandledRejection', (reason, promise) => {
            console.error('Unhandled Rejection at:', promise, 'reason:', reason);
            // Consider logging to an error tracking service
          });
          
          process.on('uncaughtException', (error) => {
            console.error('Uncaught Exception thrown:', error);
            // Handle the error gracefully, possibly exit the process
            process.exit(1);
          });
        process.exit(1);
    }
}

export function createConnection(uri: string): ConnectionObject {
    const db = mongoose.createConnection(uri, {serverSelectionTimeoutMS: 30000,});
    const createModel = (modelName: string, schema: Schema): Model<any> => {
        return db.model(modelName, schema);
    };
    return {
        isConnected: db.readyState == 1,
        connectionUrl: uri,
        connectionObj: db,
        createModel
    } as ConnectionObject;
}

export const createModel = (dbname: string, modelKey: string, schema: Schema): Model<any> => {
    let connection = connections[dbname];

    if(connection?.isConnected){
        return connection.createModel(modelKey, schema) as Model<any>;
    }

    const connectionStr = databaseConfigOptions.find(x => x.name === dbname)?.connectionString as string;
    const newconnection = createConnection(connectionStr);
    return newconnection.createModel(modelKey, schema) as Model<any>;

};