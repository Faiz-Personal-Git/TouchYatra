import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { AwardModel } from "@/models";
import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

type paramType = {
    params: {award_id: string}
}

export const DELETE = asyncHandler(true, async (req: Request, {params}: paramType) => {
    const awardId = params?.award_id;
    if(!awardId){
        throw new ApiError(404, "Id not found")
    }
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const award = await AwardModel.findById(awardId);
    if(!award){
        throw new ApiError(404, "Award not found.")
    }

    if(award.UserId.toString() !== session.user._id?.toString()){
        throw new ApiError(401, "Unauthorized request.")
    }

    const isDeleted = await AwardModel.findByIdAndDelete(awardId);
    if(!isDeleted){
        throw new ApiError(500, "Failed to delete award.", isDeleted)
    }
    return new ApiResponse( 200, null, 'Award deleted successfully.' );
})