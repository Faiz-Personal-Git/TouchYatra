import { asyncHandler, ApiResponse } from "@/utils";
import { AwardModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const awards = (await AwardModel.find({ UserId: params.userid?.toObjectId() })) ?? [];
    return new ApiResponse(
        200, 
        awards.toRecords(), 
        'Awards fetched successfully.'
    );
})