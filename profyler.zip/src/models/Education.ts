import { Collections, databases } from "@/constants";
import { educationLevels } from "@/constants";
import { createModel } from "@/lib";
import { Schema, Document, Model } from "mongoose";

export interface Education extends Document {
    UserId: Schema.Types.ObjectId;
    EducationLevel: string;
    Institute: string;
    Degree: string;
    SpecializationOfStudy: string;
    Notes: string;
    StartDate: Date;
    EndDate: Date;
    Marks: number;
    Grade: number;
    City: string;
    State: string;
    Country: string;
}


const EducationSchema = new Schema<Education>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        EducationLevel: {
            type: String,
            enum: educationLevels,
            required: [true, "Education Level is required"],
        },
        Institute: {
            type: String,
            required: [true, "Institute name is required"]
        },
        Degree: {
            type: String
        },
        SpecializationOfStudy: {
            type: String
        },
        Notes: {
            type: String
        },
        StartDate: {
            type: Date,
            required: [true, "Start date is required"]
        },
        EndDate: {
            type: Date
        },
        Marks : {
            type: Number,
            min: 0
        },
        Grade: {
            type: Number,
            min: 0,
            max: 4.0 
        },
        City: {
            type: String,
            required: [true, "City is required"],
            trim: true
        },
        State: {
            type: String,
            required: [true, "State is required"],
            trim: true
        },
        Country: {
            type: String,
            required: [true, "Country is required"],
            uppercase: true,
            trim: true
        }
    },
    { timestamps: true }
)

export const EducationModel = createModel(databases.main, Collections.Education, EducationSchema) as Model<Education>;