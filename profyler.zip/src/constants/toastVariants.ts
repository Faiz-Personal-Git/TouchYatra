export const toastVariants = {
    default: "default",
    primary: "primary",
    secondary: "secondary",
    error: "error",
    warning: "warning",
    info: "info",
    success: "success",
    destructive: "destructive"
} as const