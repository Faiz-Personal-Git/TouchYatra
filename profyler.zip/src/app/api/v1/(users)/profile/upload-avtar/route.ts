import { NextRequest } from 'next/server';
import { ApiError, ApiResponse, asyncHandler, extractArrayNotationFormData, uploadFile } from '@/utils';
import { getServerSession } from 'next-auth';
import { authOptions } from '@authOptions/options';
import { ProfileModel } from '@/models';

export const POST = asyncHandler(true, async function(request: NextRequest){
  const session = await getServerSession(authOptions)
  if(!session?.user){
      throw new ApiError(401, "Please login first.")
  }
  const profile = await ProfileModel.findOne({UserId: session.user._id?.toObjectId()})
  if(!profile){
    throw new ApiError(404, "Profile not found.")
  }

  const data = await extractArrayNotationFormData(request);

  if(!data.Avatar){
    throw new ApiError(400, "Avatar is required.")
  }
  if(!(data.Avatar instanceof File)){
    profile.Avatar = data.Avatar;
  }else{
    const filePath = await uploadFile(data.Avatar as File);
    profile.Avatar = filePath as string;
  }

  await profile.save();
  return new ApiResponse(200, {Avatar: profile.Avatar}, "Avatar uploaded successfully.")
})

