"use client"
import { useSettingContext } from '@/context/SettingProvider';
import React from 'react'

export function AuthLayout({
    children,
  }: Readonly<{
    children: React.ReactNode;
  }>) {
    const {setBodyClassName} = useSettingContext({})

    React.useEffect(() => {
        setBodyClassName("bg-[url(/assets/theme/images/mountain_bg.avif)] bg-size-cover")

        return () => {
            setBodyClassName("")
        }
    }, [])

  return (
    <>
      {children}
    </>
  )
}
