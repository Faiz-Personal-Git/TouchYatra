import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { EducationModel, ExperienceModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {id: string}}) => {
    const experience = await ExperienceModel.findById(params.id);

    if(!experience){
        throw new ApiError(404, "Experience not found")
    }
    
    return new ApiResponse(
        200, 
        experience,
        'Experience fetched successfully.'
    );
})