import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { TeamMemberModel } from "@/models";
import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

type paramType = {
    params: {id: string}
}

export const DELETE = asyncHandler(true, async (req: Request, {params}: paramType) => {
    const teamMemberId = params?.id;
    if(!teamMemberId){
        throw new ApiError(404, "Id not found")
    }
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const teamMember = await TeamMemberModel.findById(teamMemberId);
    if(!teamMember){
        throw new ApiError(404, "Certificate not found.")
    }

    if(teamMember.UserId.toString() !== session.user._id?.toString()){
        throw new ApiError(401, "Unauthorized request.")
    }

    const isDeleted = await TeamMemberModel.findByIdAndDelete(teamMember);
    if(!isDeleted){
        throw new ApiError(500, "Failed to delete team member.", isDeleted)
    }
    return new ApiResponse( 200, null, 'Team member deleted successfully.' );
})