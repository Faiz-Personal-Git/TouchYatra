import {UserModel} from '@/models'
import { z } from 'zod'
import {emailValidation} from '@/schemas'
import { ApiError, ApiResponse, asyncHandler } from '@/utils'

const EmailQuerySchema = z.object({
    Email: emailValidation
})

export const GET = asyncHandler(true, async (req: Request) => {

    const {searchParams} = new URL(req.url);
    const queryParams = {
        Email: searchParams.get('Email')
    };

    //TODO :- validate email with zod
    const result = EmailQuerySchema.safeParse(queryParams);
    
    if(!result.success){
        const emailErrors = result.error.format().Email?._errors || [];
        throw new ApiError(
            400, 
            emailErrors?.length > 0 ? emailErrors.join(', ') : "Invalid query parameters.",
            emailErrors
        );
    }

    const {Email} = result.data;
    const user = await UserModel.findOne({Email: Email.trim().toLowerCase(), IsVerified: true});
    if(user){
        throw new ApiError(400, "Email is already exist.")
    }

    return new ApiResponse(200, null, "Email is unique.");
})