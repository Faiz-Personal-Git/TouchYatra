import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // output: 'export',
  reactStrictMode: true,
  /* config options here */
  images: {
    unoptimized: true,
    domains: [
      "api.microlink.io", // Microlink Image Preview
      "lh3.googleusercontent.com", // Google
    ],
  },
  
};

export default nextConfig;
