export const buttonVariants = {
    default: "default",
    destructive: "destructive",
    outline: "outline",
    primary: "primary",
    secondary: "secondary",
    error: "error",
    warning: "warning",
    info: "info",
    success: "success",
    ghost: "ghost",
    link: "link"
} as const;