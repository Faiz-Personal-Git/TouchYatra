"use client";

import React, {useEffect, useState} from 'react'
import Image from 'next/image'
import { modelTypes } from '@/types'
import { useAuthSession } from '@/hooks'
import { useRouter } from 'next/navigation'
import { projectRepo } from '@/repository/user'
import { BentoGridContainer, BentoGridItem } from '@ui/acertinityUi/bento-grid'
import {Modal, ModalBody, ModalContent} from '@ui/acertinityUi/animated-modal'
import { Container, Form, FormControl, FormField, FormItem, FormMessage, Input, LabelInputContainer, Select, SelectOptions, Textarea } from '@common/index';
import { useForm } from 'react-hook-form';
import {upsertProjectSchema} from '@/schemas'
import * as z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Label } from '@radix-ui/react-label';
import { MovingBorderButton } from '@ui/acertinityUi/moving-border-button';
import { FileDropzone } from '@common/fields/FileDropzone';
import { projectsDefaultValue } from '@/constants/defaultValues';
import {DatePicker} from '@ui/shadcnUi/DatePicker'
import { teamRepo } from '@/repository';
import { Team_Members } from '@/types/models';
import { imagePlaceholders } from '@/constants';
import { MultiSelectAutocomplete } from '@/components/common/fields/AutoComplete';

export default function Projects() {
    const router = useRouter()
    const {isAuthenticated, isLoading, session} = useAuthSession({required: true, onUnauthenticated: () => {
        router.replace("/sign-in")
    }})
    const [projects, setProjects] = useState<Array<modelTypes.Project> | null>(null)
    const form = useForm<z.infer<typeof upsertProjectSchema>>({
        resolver: zodResolver(upsertProjectSchema),
        defaultValues: projectsDefaultValue

    })
    const {control, reset, watch, handleSubmit, setValue} = form

    const [showModal, setShowModal] = useState(false)
    const [teams, setTeams] = useState<Array<Team_Members>>([])

    useEffect(() => {
        ;(async function(){
            if(!session){
                return;
            }
            const res = await projectRepo.userProjects(session.user._id as string)
            if(res.success){
                setProjects(res.data.records)
            }
            const teamRes = await teamRepo.getUserTeams(session.user._id as string)
            if(teamRes.success){
                setTeams(teamRes.data.records)
            }
        })()
    }, [session])

    if (isLoading) return <div>Loading...</div>

    if(!isAuthenticated) router.replace("/sign-in")


  return (
    <>
        <Container>
            <div>
                <Modal open={showModal} setOpen={setShowModal}>
                    <MovingBorderButton
                        containerClassName='h-10 w-28'
                        borderRadius="1.75rem"
                        className="bg-white dark:bg-slate-900 text-black dark:text-white border-neutral-200 dark:border-slate-800"
                        onClick={(e: any) => {
                            e.preventDefault();
                            reset();
                            setValue("UserId", session?.user?._id as string)
                            setShowModal(true)
                        }}
                    >
                        Add Project
                    </MovingBorderButton>
                    <ModalContent>
                        <ModalBody>
                            <Form {...form}>
                                <form className='p-5'>
                                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 my-3'>
                                        <FormField
                                            name='Images'
                                            control={control}
                                            render={({field: {onChange, value}})=>(
                                                <FormItem className='w-full justify-center flex'>
                                                    <FormControl>
                                                        <LabelInputContainer>
                                                            <FileDropzone 
                                                                accept={{"image/*": [".jpg", ".png", ".jpeg"]}}  
                                                                onChange={(file) => onChange(file)} 
                                                                uploadedFiles={watch("ImageUrl")} 
                                                                removeUploadedFile={(index) => setValue("ImageUrl", watch("ImageUrl")?.filter((_, i) => i !== index))}  
                                                            />
                                                        </LabelInputContainer>
                                                    </FormControl>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 my-3'>
                                        <FormField
                                            control={control}
                                            name="ProjectName"
                                            render={({field}) => (
                                                <FormItem className='w-full'>
                                                    <FormControl>
                                                        <LabelInputContainer>
                                                            <Label htmlFor="ProjectName">Name</Label>
                                                            <Input placeholder="First Name" {...field}/>
                                                            <FormMessage/>
                                                        </LabelInputContainer>
                                                    </FormControl>
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={control}
                                            name="ProjectType"
                                            render={({field}) => (
                                                <FormItem className='w-full'>
                                                    <FormControl>
                                                        <LabelInputContainer>
                                                            <Label htmlFor="ProjectType">Type</Label>
                                                            <Input placeholder="Type" {...field}/>
                                                            <FormMessage/>
                                                        </LabelInputContainer>
                                                    </FormControl>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 my-3'>
                                        <FormField
                                            control={control}
                                            name="StartDate"
                                            render={({field: {value, ...rest}}) => (
                                                <FormItem className='w-full'>
                                                    <FormControl>
                                                        <LabelInputContainer>
                                                            <Label htmlFor="StartDate">Start Date</Label>
                                                            <Input 
                                                                placeholder="Start Date" 
                                                                type='date' 
                                                                className='pl-3 pr-10'
                                                                value={value ? new Date(value).toISOString().split('T')[0] : ''}
                                                                {...rest}
                                                            />
                                                            <FormMessage/>
                                                        </LabelInputContainer>
                                                    </FormControl>
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={control}
                                            name="EndDate"
                                            render={({field: {value, ...rest}}) => (
                                                <FormItem className='w-full'>
                                                    <FormControl>
                                                        <LabelInputContainer>
                                                            <Label htmlFor="EndDate">End Date</Label>
                                                            <Input 
                                                                placeholder="Type" 
                                                                type='date' 
                                                                value={value ? new Date(value).toISOString().split('T')[0] : ''}
                                                                {...rest}
                                                            />
                                                            <FormMessage/>
                                                        </LabelInputContainer>
                                                    </FormControl>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <FormField
                                        control={control}
                                        name="Description"
                                        render={({field}) => (
                                            <FormItem className='w-full'>
                                                <FormControl>
                                                    <LabelInputContainer>
                                                        <Label htmlFor="Description">Description</Label>
                                                        <Textarea 
                                                        className="min-h-24"
                                                            placeholder="Description"
                                                            {...field}
                                                        />
                                                        <FormMessage/>
                                                    </LabelInputContainer>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={control}
                                        name="Technologies"
                                        render={({field}) => (
                                            <FormItem className='w-full my-2'>
                                                <FormControl>
                                                    <LabelInputContainer>
                                                        <Label htmlFor="Technologies">Technologies used</Label>
                                                        <Input 
                                                            placeholder="Technologies should be ',' seperated"
                                                            {...field}
                                                        />
                                                        <FormMessage/>
                                                    </LabelInputContainer>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={control}
                                        name="TeamMembers"
                                        render={({field}) => (
                                            <FormItem className='w-full my-2'>
                                                <FormControl>
                                                    <LabelInputContainer>
                                                        <Label htmlFor="Technologies">TeamMembers</Label>
                                                        <MultiSelectAutocomplete 
                                                            placeholder='select team member'
                                                            options={teams} 
                                                            optionValue='_id'
                                                            optionLabel='MemberName'
                                                            // renderLabel={(option: Team_Members) => {
                                                            //     return (
                                                            //         <div className='flex flex-row space-x-2 items-center'>
                                                            //             <Image src={option.ImageUrl.toCorrectUrl().toReplaceTrim(imagePlaceholders.avtar1)} width={20} height={20} alt={option.MemberName} />
                                                            //             <span>{option.MemberName}</span>
                                                            //         </div>
                                                            //     )
                                                            // }}
                                                        />
                                                        {/* <Select {...field} multiple>
                                                            <SelectOptions 
                                                                defaultOption={{label: "---Select Team members---", value: "", disabled: true}}
                                                                options={teams} 
                                                                optionValue='_id'
                                                                renderLabel={(option: Team_Members) => {
                                                                    return (
                                                                        <div className='flex flex-row space-x-2 items-center'>
                                                                            <Image src={option.ImageUrl.toCorrectUrl().toReplaceTrim(imagePlaceholders.avtar1)} width={20} height={20} alt={option.MemberName} />
                                                                            <span>{option.MemberName}</span>
                                                                        </div>
                                                                    )
                                                                }}
                                                            />
                                                        </Select> */}
                                                        <FormMessage/>
                                                    </LabelInputContainer>
                                                </FormControl>
                                            </FormItem>
                                        )}
                                    />
                                </form>
                            </Form>
                        </ModalBody>
                    </ModalContent>
                </Modal>
            </div>
            <div className='border border-gray-300 dark:border-white rounded rounded-md'>
                <BentoGridContainer className="max-w-4xl mx-auto">
                    {
                        projects?.map((project, idx) => (
                            <BentoGridItem 
                                key={idx} 
                                title={project.ProjectName} 
                                description={project.Description}
                                header={<Image src={project.ImageUrl[0]} alt="project" width={200} height={200} />}
                                className="flex flex-1 w-full h-full min-h-[6rem] dark:bg-dot-white/[0.2] rounded-lg bg-dot-black/[0.2] flex-col space-y-2 cursor-pointer"
                                onClick={() => {
                                    router.push(`/projects/${project._id}`)
                                }}
                            />
                        ))
                    }
                </BentoGridContainer>
            </div>
        </Container>
    </>
  )
}

