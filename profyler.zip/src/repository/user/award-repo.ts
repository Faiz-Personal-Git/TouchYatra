import { ApiResponse, callApi } from "@/utils";

export async function upsertAward(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/awards/upsert", data });
}

export async function userAwards(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/awards/user-awards/${userId}`});
}

export async function deleteAward(awardId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/awards/delete-award/${awardId}`});
}