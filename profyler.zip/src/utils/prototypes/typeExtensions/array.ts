Array.prototype.hasLength = function(){
    return this.length > 0;
}

Array.prototype.toRecords = function(){
    return {totalRecords: this.length, records: this};
}

//#region  Objects

class TypeCheckerResult {
    private value: any;

    constructor(value: Array<any>){
        this.value = value[0];
    }

    get type(): 'string' | 'number' | 'array' | 'object' | 'null' | 'undefined' | boolean {
        if (this.isString()) return 'string';
        if (this.isNumber()) return 'number';
        if (this.isArray()) return 'array';
        if (this.isObject()) return 'object';
        if (this.isNull()) return 'null';
        if(this.isUndefined()) return 'undefined';
        return false;
    }

    isString(): boolean {
        return typeof this.value === 'string';
    }

    isNumber(): boolean {
        return typeof this.value === 'number' && !isNaN(this.value);
    }

    isArray(): boolean {
        return Array.isArray(this.value);
    }

    isObject(): boolean {
        return this.value !== null && this.value !== undefined && typeof this.value === 'object' && !this.isArray();
    }

    isNullOrUndefined(): boolean {
        return this.value === null || this.value === undefined;
    }

    isNull(): boolean {
        return this.value === null;
    }

    isUndefined(): boolean {
        return this.value === undefined;
    }
}

type mapCallback = (value: {key: string, value?: any}, index: number, array: any[]) => any;


Array.prototype.hasProperties = function(): boolean{
    return Object.keys(this[0]).length > 0;
},
Array.prototype.isEqual = function(obj: any): boolean{
    return JSON.stringify(this[0]) === JSON.stringify(obj);
},
Array.prototype.getKeys = function(): string[]{
    return Object.keys(this[0]);
},
Array.prototype.getValues = function(): any[]{
    return Object.values(this[0] as any);
},
Array.prototype.getEntries = function(): [string, any][]{
    return Object.entries(this[0]);
},
Array.prototype.hasOwn = function(key: string): boolean{
    return Object.prototype.hasOwnProperty.call(this[0], key);
},
Array.prototype.checkType = function(): TypeCheckerResult {
    return new TypeCheckerResult(this as any);
},
Array.prototype.mapObj = function(callback: mapCallback): any[]{
    const obj = this.getEntries();
    if(obj.length === 0) return [];
    return obj.map(function(entries, index){
        return callback({key: entries[0], value: entries[1]}, index, obj);
    });
}
Array.prototype.changeKeys = function({prepend, append, removeKeys}:{prepend?: string, append?: string, removeKeys?: string}){
    const obj = this.getEntries();
    const newObj = {} as {[key: string]: any};

    const removeKeysArr = removeKeys?.split(",") || [];

    obj.forEach(([key, value]) => {
        if(removeKeysArr.includes(key)) return;
        newObj[`${prepend?.trim()? prepend.trim() : ""}${key.trim()}${append?.trim()? append.trim() : ""}`] = value;
    });
    return newObj;
}

Array.prototype.toFormData = function(specialKeys, callback) {
    const obj = this[0] as Record<string, any>;
    const formData = new FormData();
    const keyArr = specialKeys ? specialKeys.split(',') : []
    for (const key in obj) {
      if (Object.hasOwnProperty.call(obj, key)) {
        if(!callback){
            formData.append(key, obj[key]);
            continue;
        }

        if(keyArr.includes(key)){
            formData.append(key, callback(obj[key]));
            continue;
        }

        formData.append(key, obj[key]);
      }
    }
    return formData;
  }

//#endregion


declare global {
    interface Array<T> {
        hasLength(): boolean;
        toRecords(): {records: Array<any>, totalRecords: number};
        changeKeys(prop: {prepend?: string, append?: string, removeKeys?: string}): {[key: string]: any};

        hasProperties(): boolean;
        isEqual(obj: any): boolean;
        getKeys(): string[];
        getValues(): any[];
        getEntries(): [string, any][];
        hasOwn(key: string): boolean;
        checkType(): TypeCheckerResult;
        mapObj(callback: mapCallback): any[];
        toFormData(specialKeys?: string, callback?: (value: any) => any): FormData;
    }
}

export {}