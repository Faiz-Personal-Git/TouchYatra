import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { AwardModel } from "@/models";
import { getServerSession } from "next-auth";
import { authOptions } from "@authOptions/options";

export const POST = asyncHandler(true, async (req: Request) => {
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const formData = await req.formData();
    const data = Object.fromEntries(formData) as Record<string, any>;
    const isForUpdate =!!data._id;

    if(isForUpdate){
        const oldRecord = await AwardModel.findById(data._id);
        if(!oldRecord){
            throw new ApiError(404, "Record not found.")
        }

        if(
            data.UserId? (
                oldRecord.UserId.toString() !== data.UserId.toString() && 
                oldRecord.UserId.toString()!== session.user._id?.toString()
            )
            : oldRecord.UserId.toString() !== session.user._id?.toString()
        ){
            throw new ApiError(401, "Unauthorized request.")
        }
    }

    if(!data.UserId){
        data.UserId = session.user._id?.toObjectId();
    }
    //Need work for file upload

    const award = isForUpdate
        ? await AwardModel.findByIdAndUpdate(data._id, data, { new: true })
        : await AwardModel.create(data);


    if(!award){
        throw new ApiError(500, "Failed to save award.");
    }

    await award.save();
    return new ApiResponse(isForUpdate? 200 : 201, award, "Awards saved successfully.");
});