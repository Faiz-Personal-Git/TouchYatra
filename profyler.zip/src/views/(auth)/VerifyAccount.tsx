"use client";
import React, { useEffect, useState } from "react";
import {FormField, Form, FormMessage, FormControl, FormItem, Label, BorderGradient, LabelInputContainer, Input, VerificationCard} from '@common/index'
import * as z from "zod";
import {zodResolver} from '@hookform/resolvers/zod'
import { useForm } from "react-hook-form";
import { sendVerificationTokenSchema } from "@/schemas";
import { useToast } from "@/hooks";
import {  useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import {authRepo as repo} from '@/repository'

interface VerifyAccountProps {
    token: string;
}

export default function VefifyAccount({token}: VerifyAccountProps) {

  const [verificationLoading, setVerificationLoading] = useState(false)
  const [error, seterror] = useState<{Success: boolean, message: string}>()
  const {toast} = useToast()
  const router = useRouter()

  const form = useForm<z.infer<typeof sendVerificationTokenSchema>>({
    resolver: zodResolver(sendVerificationTokenSchema)
  })

  const {control, handleSubmit, reset, formState} = form;

  useEffect(() => {
    ;(
      async function(){
        setVerificationLoading(true)
        const {success, message} = await repo.verifyAccount(token);
        seterror({Success: success, message})
        setVerificationLoading(false)
      }
    )()
  }, [])

  if(verificationLoading){
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="w-16 h-16" />
      </div>
    )
  }

  
  const onSubmit = handleSubmit(async function(data: z.infer<typeof sendVerificationTokenSchema>): Promise<void>{
    const {success, message} = await repo.resendVerificationToken(data.UserName)
    toast({
      title: success? "Success!" : "Failed!",
      description: message,
      variant: success? "default" : "destructive"
    })
    if(success){
      reset();
    }
  })

  if(error){
    return (
      <VerificationCard
        Success={error.Success}
        message={error.message}
        SuccessButton={(btnClass) => (
          <button className={btnClass} onClick={() => router.replace('/sign-in')}>Go to Signin</button>
        )}
        ErrorForm={({formClass, inputClass, errorClass, buttonClass}) => (
          <Form {...form}>
            <form className={formClass} onSubmit={onSubmit}>
              <FormField
                control={control}
                name="UserName"
                render={({field}) => (
                  <FormItem>
                    <FormControl>
                      <LabelInputContainer className="mb-4">
                        <Label htmlFor="UserName">UserName</Label>
                        <BorderGradient>
                          <Input type="text" placeholder="Enter your username or email here" className={inputClass} {...field} />
                        </BorderGradient>
                        <FormMessage className={errorClass}/>
                      </LabelInputContainer>
                    </FormControl>
                  </FormItem>
                )}
              />
              <button className={buttonClass} type="submit" disabled={formState.isSubmitting}>
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
                <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent flex justify-center">
                  {
                    formState.isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 w-5 animate-spin" />
                        Sending Email...
                      </>
                    ) : ("Send Verification Email")
                  }
                </div>
              </button>

              {/* <button className="p-[3px] relative w-full" type="submit" disabled={formState.isSubmitting}>
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
                <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent flex justify-center">
                  {
                    formState.isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 w-5 animate-spin" />
                        Sending Email...
                      </>
                    ) : ("Send Verification Email")
                  }
                </div>
              </button> */}

            </form>
          </Form>
        )}
      />
    )
  }



  return (
    <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black my-10">
      <h2 className="font-bold text-xl text-neutral-800 dark:text-neutral-200">
        Welcome to Profyler
      </h2>
      <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
        Enter your username or email to send verification email again.
      </p>

      <Form {...form}>
        <form className="my-8" onSubmit={onSubmit}>
          <FormField
            control={control}
            name="UserName"
            render={({field}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="UserName">UserName</Label>
                    <BorderGradient>
                      <Input type="text" placeholder="Enter your username or email here" {...field} />
                    </BorderGradient>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />

          <button className="p-[3px] relative w-full" type="submit" disabled={formState.isSubmitting}>
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
            <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent flex justify-center">
              {
                formState.isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 w-5 animate-spin" />
                    Sending Email...
                  </>
                ) : ("Send Verification Email")
              }
            </div>
          </button>

        </form>
      </Form>
    </div>
  );
}