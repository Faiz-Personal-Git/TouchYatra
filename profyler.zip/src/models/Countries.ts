
import { Collections, databases } from '@/constants';
import { createModel } from '@/lib';
import {Schema, Document, Model} from 'mongoose';

export interface Country extends Document {
    Name: string;
    Code: string;
    Phone: string;
    Suggested?: boolean;
}

export const CountrySchema: Schema<Country> = new Schema(
    {
        Name: {
            type: String,
            required: [true, "Name is required"],
            trim: true,
        },
        Code: {
            type: String,
            required: [true, "Code is required"],
            trim: true,
            unique: true,
            uppercase: true,
        },
        Phone: {
            type: String,
            required: [true, "Phone is required"],
            trim: true
        },
        Suggested: {
            type: Boolean
        }
    }, {strict: false}
)

export const CountryModel = createModel(databases.main, Collections.Countries, CountrySchema) as Model<Country>;