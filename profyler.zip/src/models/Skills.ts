import { Collections, databases } from '@/constants';
import { createModel } from '@/lib';
import {Document, Model, Schema} from 'mongoose'

export interface Skills extends Document {
  UserId: Schema.Types.ObjectId;
  Name: string;
  Descriptions: string;
  Level: number;
  Keywords: string[];
}

const SkillsSchema = new Schema<Skills>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        Name: {
            type: String,
            required: true
        },
        Descriptions: {
            type: String
        },
        Level: {
            type: Number,
            default: 0
        },
        Keywords: {
            type: [String]
        },
    }, {timestamps: true}
)

export const SkillsModel = createModel(databases.main, Collections.Skills, SkillsSchema) as Model<Skills>;