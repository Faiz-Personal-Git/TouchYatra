"use server"

import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

export const serverSessions = async () => getServerSession(authOptions)
