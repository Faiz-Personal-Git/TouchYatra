import { Schema, Document, Model } from "mongoose";
import { createModel } from "@/lib";
import { Collections, databases } from "@/constants";

export interface Affiliation extends Document {
    Title: string;
    Department: string;
    Company: string;
    Headline: string;
}

const AffiliationSchema = new Schema<Affiliation>({
    Title: String,
    Department: String,
    Company: String,
    Headline: String
})


export interface Profile extends Document {
    UserId: Schema.Types.ObjectId;
    //Name
    Prefix: string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    Suffix: string;
    MaidenName: string;
    //End Name
    PhoneNo: string;
    Gender: string;
    BirthDay: Date;
    Affiliation: Affiliation;
    Teams: [Schema.Types.ObjectId];
    Avatar: string;
    CoverImage: string;
    Logo: string;
}

const ProfileSchema  = new Schema<Profile>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            ref: Collections.User
        },
        Prefix: {
            type: String,
            // enum: ["Mr.", "Mrs.", "Miss", "Ms.", "Dr.", "Prof."],
            trim: true
        },
        FirstName: {
            type: String,
            required: [true, "First name is required"],
            trim: true
        },
        MiddleName: {
            type: String,
            trim: true
        },
        LastName: {
            type: String,
            trim: true
        },
        PhoneNo: {
            type: String,
            trim: true,
        },
        Gender: {
            type: String,
            enum: ["M", "F", "O"],
        },
        BirthDay: {
            type: Date
        },
        Affiliation: {
            type: AffiliationSchema
        },
        Teams: {
            type: [Schema.Types.ObjectId],
            ref: Collections.TeamMembers
        },
        Avatar: {
            type: String
        },
        CoverImage: {
            type: String
        },
        Logo: {
            type: String
        },
    }
)

export const ProfileModel = createModel(databases.main, Collections.Profile, ProfileSchema) as Model<Profile>;