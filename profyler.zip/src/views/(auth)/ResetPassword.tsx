"use client";
import React, { useEffect, useState } from "react";
import {FormField, Form, FormMessage, FormControl, FormItem, LabelInputContainer, Input, Label, VerificationCard} from '@common/index'
import * as z from "zod";
import {zodResolver} from '@hookform/resolvers/zod'
import { useForm } from "react-hook-form";
import { resetPasswordSchema } from "@/schemas";
import { useToast } from "@/hooks";
import { useParams, useRouter } from "next/navigation";
import { Eye, EyeClosed, Loader2 } from "lucide-react";
import {authRepo as repo} from '@/repository'

interface ResetPasswordProps {
    token: string
}

export default function ResetPassword({token}: ResetPasswordProps) {
    const [passwordType, setPasswordType] = useState("password")
    const [newToken, setNewToken] = useState<string>("")
    const [tokenVerifyLoading, setTokenVerifyLoading] = useState<boolean>(false)
    const [error, seterror] = useState<{message:string, statusCode: number}>()
    const {toast} = useToast()
    const router = useRouter();
    const form = useForm<z.infer<typeof resetPasswordSchema>>({
      resolver: zodResolver(resetPasswordSchema)
    })
  
    const {control, handleSubmit, formState} = form;

    useEffect(() => {
      ;(async () => {
        setTokenVerifyLoading(true);
        debugger
        const res = await repo.verifyToken(token);
        console.log(res)
        const {success, message, data, statusCode} = res;
        if(success){
          setNewToken(data);
        }
        if(!success){
          seterror({message, statusCode});
        }
        setTokenVerifyLoading(false);
      })()
    }, [])

    if(tokenVerifyLoading){
      return (
        <div className="flex justify-center items-center h-screen">
          <Loader2 size={64} />
        </div>
      )
    }

    if(error){
      return (
        <VerificationCard 
          Success={false}
          message={error.message}
          // ErrorForm={({buttonClass}) => (
          //   <button className={buttonClass}></button>
          // )}
        />
      )
    }
    
    const onSubmit = handleSubmit(async function(data: z.infer<typeof resetPasswordSchema>): Promise<void>{
      const res = await repo.ResetPassword({Token: newToken, Password: data.NewPassword})
      const {success, message} = res
      toast({
        title: success? "Success!" : "Failed!",
        description: message,
        variant: success? "default" : "destructive"
      })
      if(success){
        router.replace('/sign-in');
      }
    })


    
    return (
      <>
        <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black my-10">
          <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
            Ready to change your password.
          </p>
    
          <Form {...form}>
            <form className="my-8" onSubmit={onSubmit}>
            <FormField
                control={control}
                name="NewPassword"
                render={({field}) => (
                  <FormItem>
                    <FormControl>
                      <LabelInputContainer className="mb-4">
                        <Label htmlFor="NewPassword">New Password</Label>
                        <div className="flex relative">
                            <Input placeholder="New Password" className="w-full" type={passwordType} {...field}/>
                            {
                                passwordType === "password" ? (
                                    <EyeClosed className="self-end z-50 absolute right-3 cursor-pointer mb-2" onClick={() => setPasswordType("text")}/>
                                ) : (
                                    <Eye className="self-end z-50 absolute right-3 cursor-pointer mb-2" onClick={() => setPasswordType("password")} />
                                )
                            }
                        </div>
                        <FormMessage/>
                      </LabelInputContainer>
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={control}
                name="ConfirmPassword"
                render={({field}) => (
                  <FormItem>
                    <FormControl>
                      <LabelInputContainer className="mb-4">
                        <Label htmlFor="ConfirmPassword">Re-Enter Password</Label>
                        <Input placeholder="Re-Enter Password" type="password" {...field}/>
                        <FormMessage/>
                      </LabelInputContainer>
                    </FormControl>
                  </FormItem>
                )}
              />
              <button className="p-[3px] relative w-full" type="submit" disabled={formState.isSubmitting}>
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
                <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent flex justify-center">
                  {
                    formState.isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 w-5 animate-spin" />
                        Loading...
                      </>
                    ) : ("Reset")
                  }
                </div>
              </button>
            </form>
          </Form>
        </div>
      </>
    )
  }
