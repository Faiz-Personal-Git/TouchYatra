import mongoose from 'mongoose'

String.prototype.toObjectId = function() { 
    return new mongoose.Types.ObjectId(this.toString());
}

declare global {
    interface String {
        toObjectId(): mongoose.Types.ObjectId;
    }
}

export {}