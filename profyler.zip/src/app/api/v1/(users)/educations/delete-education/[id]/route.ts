import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { EducationModel } from "@/models";
import { authOptions } from "@authOptions/options";
import { getServerSession } from "next-auth";

type paramType = {
    params: {id: string}
}

export const DELETE = asyncHandler(true, async (req: Request, {params}: paramType) => {
    const id = params?.id;
    if(!id){
        throw new ApiError(404, "Id not found")
    }
    const session = await getServerSession(authOptions)
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const education = await EducationModel.findById(id);
    if(!education){
        throw new ApiError(404, "Education not found.")
    }

    if(education.UserId.toString() !== session.user._id?.toString()){
        throw new ApiError(401, "Unauthorized request.")
    }

    const isDeleted = await EducationModel.findByIdAndDelete(id);
    if(!isDeleted){
        throw new ApiError(500, "Failed to delete education.", isDeleted)
    }
    return new ApiResponse( 200, null, 'Education deleted successfully.' );
})
