import { TeamDetails } from "@/views/(protected)/TeamDetails";
import { Metadata } from "next";

import React from 'react'

export default function page() {
  return (
    <TeamDetails />
  )
}

export const metadata: Metadata = {
  title: "Profyler - Team Details",
  description: "Team Details",
};
