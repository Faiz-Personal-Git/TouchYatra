export class ApiError extends Error {

  statusCode: number;
  message: string;
  data: any;
  success: boolean;
  errors: any;

  constructor(
    StatusCode : number,
    Message : string,
    Errors? : any,
    stack? : string
  ) {
    super(Message);
    this.statusCode = StatusCode;
    this.message = Message;
    this.data = null;
    this.success = false;
    this.errors = Errors;

    if (stack) {
      this.stack = stack;
    } else {
      Error.captureStackTrace(this, this.constructor);
    }
  }
}
