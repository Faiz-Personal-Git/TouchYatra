import { ApiResponse, callApi } from "@/utils";

export async function upsertSkill(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/skills/upsert", data });
}

export async function userSkills(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/skills/user-skills/${userId}`});
}

export async function getSkillById(SkillId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/skills/getById/${SkillId}`});
}

export async function deleteSkill(SkillId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/skills/delete-skill/${SkillId}`});
}