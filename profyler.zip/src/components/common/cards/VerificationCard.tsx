import React, { useState } from "react";
import { FaCheckCircle, FaExclamationCircle } from "react-icons/fa";

export interface VerificationCardProps {
  Success: boolean;
  message: string;
  SuccessButton?: (ButtonClass: string) => React.ReactElement,
  ErrorForm?: (props: {formClass: string,inputClass: string, errorClass: string, buttonClass: string}) => React.ReactElement | React.ReactNode
}

export const VerificationCard = ({ Success, message, SuccessButton, ErrorForm }: VerificationCardProps) => {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
        <div className="flex flex-col items-center">
          <img
            src="https://images.unsplash.com/photo-1633409361618-c73427e4e206"
            alt="Website Logo"
            className="w-20 h-20 object-contain mb-4 rounded-full"
          />
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Account Verification</h1>
          
          <div className="mt-6 w-full">
            {Success ? (
              <div className="text-center">
                <FaCheckCircle className="text-green-500 text-5xl mx-auto mb-4" />
                <p className="text-gray-600 mb-6">{message || "Your account has been successfully verified!"}</p>
                {SuccessButton && SuccessButton("bg-green-500 text-white px-6 py-2 rounded-full hover:bg-green-600 transition-colors duration-300 w-full")}
              </div>
            ) : (
              <div className="text-center">
                <FaExclamationCircle className="text-red-500 text-5xl mx-auto mb-4" />
                <p className="text-gray-600 mb-6">{message || "Verification failed. Please try again."}</p>
                {
                  ErrorForm && ErrorForm({
                    formClass: "space-y-4",
                    inputClass: "w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500",
                    errorClass: "text-red-500 text-sm mt-1",
                    buttonClass: "bg-red-500 text-white px-6 py-2 rounded-full hover:bg-red-600 transition-colors duration-300 w-full",
                  })
                }
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};