import { NextRequest } from 'next/server';
import { ApiError, ApiResponse, asyncHandler, extractArrayNotationFormData, uploadFile } from '@/utils';
import { getServerSession } from 'next-auth';
import { authOptions } from '@authOptions/options';
import { ProfileModel } from '@/models';

export const POST = asyncHandler(true, async function(request: NextRequest){
  const session = await getServerSession(authOptions)
  if(!session?.user){
      throw new ApiError(401, "Please login first.")
  }
  const profile = await ProfileModel.findOne({UserId: session.user._id?.toObjectId()})
  if(!profile){
    throw new ApiError(404, "Profile not found.")
  }

  const data = await extractArrayNotationFormData(request);

  if(!data.CoverImage){
    throw new ApiError(400, "Cover Image is required.")
  }
  if(!(data.CoverImage instanceof File)){
    profile.CoverImage = data.CoverImage;
  }else{
    const filePath = await uploadFile(data.CoverImage as File);
    profile.CoverImage = filePath as string;
  }

  await profile.save();
  return new ApiResponse(200, {CoverImage: profile.CoverImage}, "Cover Image uploaded successfully.")
})

