import {UserModel, UserToken} from '@/models'
import { ApiError, ApiResponse, asyncHandler } from '@/utils';

export const POST = asyncHandler(true, async (req: Request) => {
    const {Token} = await req.json();
    //TODO :- when data comes from url then is better when do data decode here
    // const decodedUsername = decodeURIComponent(username);

    const tokenRes = Token.decodeToken() as ApiResponse;

    if(!tokenRes.success){
        return tokenRes;
    }

    const tokenUser = tokenRes.data as UserToken;

    const user = await UserModel.findById(tokenUser._id);

    if(!user){
        throw new ApiError(404, "User not found");
    }

    if(user.IsVerified){
        throw new ApiError(400, "User already verified.");
    }

    if(tokenUser.UserName !== user.UserName){
        throw new ApiError(400, "User name is incorrect or taken by a different user");
    }

    if(tokenUser.Email !== user.Email){
        throw new ApiError(400, "Email is incorrect or taken by a different user");
    }

    user.IsVerified = true;
    await user.save();

    return new ApiResponse(200, null, "User is verified.")
})