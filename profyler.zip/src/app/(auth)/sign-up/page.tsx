import React from 'react'
import {Signup} from '@/views/(auth)'
import { Metadata } from 'next'

export default function page() {
  return <Signup/>
}

export const metadata: Metadata = {
  title: `Profyler - Signup`,
  description: `Signup account`,
  icons: {
    icon: `path to asset file`,
  },
}