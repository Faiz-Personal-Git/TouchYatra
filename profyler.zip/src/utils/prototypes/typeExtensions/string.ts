import {FieldBaseUrls} from '@/constants/fields'


String.prototype.toIntOrZero = function(){
    const val = parseInt(this.toString(), 10);
    return  isNaN(val) ? 0 : val
}

String.prototype.toBearerToken = function(){
    return {"Authorization": `Bearer ${this.toString()}`};
}

String.prototype.fromBearerToken = function(){
    const token = this.toString().split(' ')[1];
    return token;
}

String.prototype.toReplaceTrim = function(replacer){
    if(!replacer){
        return this.toString().trim()
    }
    return this.toString().trim() === "" ? replacer : this.toString().trim();
}

String.prototype.toReplaceSpace = function(replacer){
    return this.toString().replace(/\s+/g, replacer ? replacer : "_");
}

String.prototype.toMoreSlice = function(end: number, start = 0){
    return this.toString().trim()?.length > end ? `${this.toString().trim().slice(start, end)}...` : this.toString().trim();
}

String.prototype.toCorrectUrl = function(){
    return this.toString().replace(/\\/g, '/');
}

String.prototype.toUrl = function(urlFor){
    const url = this.toString().toCorrectUrl();
    if(!urlFor) return url;
    return url.startsWith(FieldBaseUrls[urlFor]) ? url : FieldBaseUrls[urlFor] + url;
}


type toUrlPropType = keyof typeof FieldBaseUrls;

declare global {
    interface String {
        toIntOrZero(): number;
        toReplaceTrim(replacer?: string): string;
        toReplaceSpace(replacer?: string): string;
        toMoreSlice(end: number, start?: number): string;
        toBearerToken(): {[key: string]: string};
        fromBearerToken(): string;
        toCorrectUrl(): string;
        toUrl(urlFor?: toUrlPropType): string;
    }
}

export {}