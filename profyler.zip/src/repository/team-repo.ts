import { ApiResponse, callApi } from "@/utils";

export async function upsertTeam(data: any): Promise<ApiResponse> {
    return callApi({method: "POST", url: "/api/v1/teams/upsert", data})
}

export async function getTeamById(id: string): Promise<ApiResponse> {
    return callApi({method: "GET", url: `/api/v1/teams/getById/${id}`})
}

export async function getUserTeams(userId: string): Promise<ApiResponse> {
    return callApi({method: "GET", url: `/api/v1/teams/getByUserId/${userId}`})
}

export async function deleteTeam(id: string): Promise<ApiResponse> {
    return callApi({method: "DELETE", url: `/api/v1/teams/deleteById/${id}`})
}