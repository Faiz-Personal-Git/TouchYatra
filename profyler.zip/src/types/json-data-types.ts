export type genders = {
    value: string;
    label: string;
}

export type countries = {
    code: string;
    label: string;
    phone: string;
    suggested?: boolean;
}