import { CountryModel } from "@/models";
import { ApiResponse, asyncHandler } from "@/utils";

export const GET = asyncHandler(true, async function(req: Request){
    const { searchParams } = new URL(req.url);
    const searchText = searchParams.get("search") ?? "";
    
    const schemaPaths = CountryModel.schema.paths;
    const searchConditions = Object.keys(schemaPaths)
        .filter(key => schemaPaths[key].instance === 'String')
        .map(key => ({
            [key]: { $regex: searchText, $options: 'i' }
        }));

    const countries = (await CountryModel.find({ $or: searchConditions })) ?? [];

    return new ApiResponse(200, countries.toRecords(), 'Countries fetched successfully.');
})