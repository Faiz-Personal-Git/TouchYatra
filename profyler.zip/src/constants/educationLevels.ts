export const educationLevels = [
    'High School',
    "Bachelor's Degree",
    "Master's Degree",
    "PhD",
    "Vocational Training",
    "Certificate Program"
];