import {UserModel, UserToken} from '@/models'
import { ApiError, ApiResponse, asyncHandler } from '@/utils';

export const POST = asyncHandler(true, async (req) => {
    const {Password, Token} = await req.json();
    //TODO :- when data comes from url then is better when do data decode here
    // const decodedUsername = decodeURIComponent(username);

    const tokenRes = Token.decodeToken() as ApiResponse;

    if(!tokenRes.success){
        return tokenRes;
    }

    const tokenUser = tokenRes.data as UserToken;

    const user = await UserModel.findById(tokenUser._id);

    if(!user){
        throw new ApiError(404, "User not found");
    }

    user.IsVerified = true;
    user.Password = Password;
    await user.save({validateBeforeSave: false});

    return new ApiResponse(200, null, "Password updated successfully, Please login with your new password");
})