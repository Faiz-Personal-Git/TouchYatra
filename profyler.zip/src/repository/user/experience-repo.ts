import { ApiResponse, callApi } from "@/utils";

export async function upsertExperience(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/experience/upsert", data });
}

export async function userExperiences(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/experience/user-experiences/${userId}`});
}

export async function getExperienceById(ExperienceId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/experience/getById/${ExperienceId}`});
}

export async function deleteExperience(ExperienceId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/experience/delete-experience/${ExperienceId}`});
}