import { asyncHandler, ApiResponse } from "@/utils";
import { SkillsModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const skills = (await SkillsModel.find({ UserId: params.userid?.toObjectId() })) ?? [];
    return new ApiResponse(
        200, 
        skills.toRecords(),
        'Skills fetched successfully.'
    );
})