import { FieldsModel } from "@/models/Fields";
import { ApiError, ApiResponse, asyncHandler } from "@/utils";

export const GET = asyncHandler(true, async (req: Request) => {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');
    const fields = await FieldsModel.findOne({ UserId: userId?.toObjectId() });
    if (!fields) {
        throw new ApiError(404, 'Fields not found.');
    }
    return new ApiResponse(200, fields, 'Fields fetched successfully.');
})