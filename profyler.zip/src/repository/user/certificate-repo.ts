import { ApiResponse, callApi } from "@/utils";

export async function upsertCertificate(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/certificates/upsert", data });
}

export async function userCertificates(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/certificates/user-certificates/${userId}`});
}

export async function deleteCertificate(certificateId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/certificates/delete-certificate/${certificateId}`});
}