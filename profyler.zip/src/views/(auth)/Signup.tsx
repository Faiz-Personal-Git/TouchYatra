"use client";
import React, { useEffect, useState } from "react";
import {FormField, Form, FormMessage, FormDescription, FormControl, FormItem, Input, Label, LabelInputContainer, BottomGradient} from '@common/index'
import * as z from "zod";
import {zodResolver} from '@hookform/resolvers/zod'
import {signUp, checkEmailUniqueness, checkUsernameUniqueness} from "@/repository/auth-repo.ts"
import { useForm } from "react-hook-form";
import { signupSchema } from "@/schemas";
import { useToast } from "@/hooks";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import {useDebounceCallback} from 'usehooks-ts'
import { ApiResponse } from "@/utils";
import Link from "next/link";
import { IconBrandGoogle } from "@tabler/icons-react";
import { signIn } from "next-auth/react";

export default function Signup() {
  const [isCheckingUserName, setIsCheckingUserName] = useState<boolean>(false);
  const [userName, setUserName] = useState<string>("")
  const debounceUserName = useDebounceCallback(setUserName, 300)

  const [isCheckingEmail, setIsCheckingEmail] = useState<boolean>(false);
  const [email, setEmail] = useState<string>("")
  const debounceEmail = useDebounceCallback(setEmail, 300)

  const {toast} = useToast()
  const router = useRouter()

  const form = useForm<z.infer<typeof signupSchema>>({
    resolver: zodResolver(signupSchema)
  })

  const {watch, trigger, getFieldState, setError, clearErrors, control, handleSubmit, formState} = form;

  function toggleError(field: any, res: ApiResponse):void {
    const {statusCode, success, message} = res;
    const {isDirty} = getFieldState(field)
    if(!success && isDirty){
      // setError(field, {type: "error", message: statusCode !== 0? message : `Error checking ${field}.`})
      setError(field, {type: "error", message})
    }else{
      clearErrors(field)
    }
  }

  useEffect(() => {
    if(getFieldState("Password").isDirty){
      trigger("Password")
    }
    if(getFieldState("ConfirmPassword").isDirty){
      trigger("ConfirmPassword")
    }
  }, [watch("Password"), watch("ConfirmPassword")])

  useEffect(() => {
    setIsCheckingUserName(getFieldState("UserName").isDirty)
    ;(async function(){
      const res = await checkUsernameUniqueness(userName);
      toggleError("UserName", res);
      setIsCheckingUserName(false)
    })()
  }, [userName])

  useEffect(() => {
    setIsCheckingEmail(getFieldState("Email").isDirty)
    ;(async function(){
      const res = await checkEmailUniqueness(email);
      toggleError("Email", res);
      setIsCheckingEmail(false)
    })()
  }, [email])

  const onSubmit = handleSubmit(async function(data: z.infer<typeof signupSchema>): Promise<void>{
    const res = await signUp(data);
    const {success, message} = res
    toast({
      title: success? "Success!" : "Failed!",
      description: message,
      variant: success? "default" : "destructive"
    })
    if(success){
      router.replace("/")
    }
  })

  return (
    <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black my-10">
      <h2 className="font-bold text-xl text-neutral-800 dark:text-neutral-200">
        Welcome to Profyler
      </h2>
      <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
        Login to Profyler if you can because we don't have a login flow
        yet
      </p>

      <Form {...form}>
        <form className="my-8" onSubmit={onSubmit}>
          <div className="flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 mb-4">
            <FormField
              control={control}
              name="FirstName"
              render={({field}) => (
                <FormItem>
                  <FormControl>
                    <LabelInputContainer>
                      <Label htmlFor="FirstName">First Name</Label>
                      <Input placeholder="First Name" {...field}/>
                      <FormMessage/>
                    </LabelInputContainer>
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name="LastName"
              render={({field}) => (
                <FormItem>
                  <FormControl>
                    <LabelInputContainer>
                      <Label htmlFor="LastName">Last Name</Label>
                      <Input placeholder="Last Name" {...field}/>
                      <FormMessage/>
                    </LabelInputContainer>
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
          <FormField
            control={control}
            name="UserName"
            render={({field: {onChange, ...rest}}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="UserName">User Name</Label>
                    <Input 
                      placeholder="User Name" 
                      onChange={(e) => {
                        onChange(e);
                        debounceUserName(e.target.value);
                      }}
                      {...rest} 
                    />
                    <FormDescription>
                      {isCheckingUserName && ( <Loader2 className="mr-2 h-4 w-4 animate-spin" />)}
                    </FormDescription>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="Email"
            render={({field: {onChange, ...rest}}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="Email">Email</Label>
                    <Input 
                      placeholder="Email" 
                      onChange={(e) => {
                        onChange(e);
                        debounceEmail(e.target.value);
                      }}
                      {...rest} 
                    />
                    <FormDescription>
                      {isCheckingEmail && ( <Loader2 className="mr-2 h-4 w-4 animate-spin" />)}
                    </FormDescription>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="Password"
            render={({field}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="Password">Password</Label>
                    <Input placeholder="Password" type="password" {...field}/>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="ConfirmPassword"
            render={({field}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="ConfirmPassword">Re-Enter Password</Label>
                    <Input placeholder="Re-Enter Password" type="password" {...field}/>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />


          <button className="p-[3px] relative w-full" type="submit" disabled={formState.isSubmitting}>
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
            <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent">
              {
                formState.isSubmitting ? (
                  <div className="flex justify-center">
                    <Loader2 className="animate-spin h-5 w-5 mr-2" />
                    Signing up...
                  </div>
                ) : ("Sign up ")
              }
            </div>
          </button>

          <div className='text-center mt-3'>
            <p>
                If you already have an Account? <Link  rel="preload" href="/sign-in" className='text-blue-600 hover:text-blue-800'>Sign In</Link>
            </p>
          </div>

          <div className="bg-gradient-to-r from-transparent via-neutral-300 dark:via-neutral-700 to-transparent my-8 h-[1px] w-full" />

          <div className="flex flex-col space-y-4">
            {/* <button
              className=" relative group/btn flex space-x-2 items-center justify-start px-4 w-full text-black rounded-md h-10 font-medium shadow-input bg-gray-50 dark:bg-zinc-900 dark:shadow-[0px_0px_1px_1px_var(--neutral-800)]"
              type="submit"
            >
              <IconBrandGithub className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
              <span className="text-neutral-700 dark:text-neutral-300 text-sm">
                GitHub
              </span>
              <BottomGradient />
            </button> */}
            <button
              className=" relative group/btn flex space-x-2 items-center justify-start px-4 w-full text-black rounded-md h-10 font-medium shadow-input bg-gray-50 dark:bg-zinc-900 dark:shadow-[0px_0px_1px_1px_var(--neutral-800)]"
              type="submit"
              onClick={(e) => {
                e.preventDefault();
                signIn("google", {callbackUrl: "/projects"});
              }}
            >
              <IconBrandGoogle className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
              <span className="text-neutral-700 dark:text-neutral-300 text-sm">
                Google
              </span>
              <BottomGradient />
            </button>
            {/* <button
              className=" relative group/btn flex space-x-2 items-center justify-start px-4 w-full text-black rounded-md h-10 font-medium shadow-input bg-gray-50 dark:bg-zinc-900 dark:shadow-[0px_0px_1px_1px_var(--neutral-800)]"
              type="submit"
            >
              <IconBrandOnlyfans className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
              <span className="text-neutral-700 dark:text-neutral-300 text-sm">
                OnlyFans
              </span>
              <BottomGradient />
            </button> */}
          </div>
        </form>
      </Form>
    </div>
  );
}