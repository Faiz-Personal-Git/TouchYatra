import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { EducationModel, SkillsModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {id: string}}) => {
    const skill = await SkillsModel.findById(params.id);

    if(!skill){
        throw new ApiError(404, "Skill not found")
    }

    return new ApiResponse(
        200, 
        skill,
        'Skill fetched successfully.'
    );
})