import { dbConnect } from "@/lib";
import {ProfileModel, UserModel} from "@/models";
import { env } from "@/configuration"
import {NextAuthOptions} from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import "@/utils/prototypes"

export const authOptions: NextAuthOptions = {
    
    providers: [
        GoogleProvider({
            clientId: env.googleClientKey as string,
            clientSecret: env.googleClientSecret as string,
        }),
        CredentialsProvider({
            id: "credentials",
            name: "Credentials",
            credentials: {
                UserName: { label: "UserName", type: "text", placeholder: "User Name"},
                Password: { label: "Password", type: "password", placeholder: "Password"}
            },
            async authorize(credentials: any, req: any) : Promise<any> {
                await dbConnect();
                try {
                    console.log('next-auth authorization')
                    console.log("dbconnected")
                    const user =  await UserModel.findOne({
                        $or: [
                            { UserName: credentials.Identifier.toLowerCase() },
                            { Email: credentials.Identifier.toLowerCase() }
                        ]
                    })

                    console.log("user", user)

                    if(!user){
                        throw new Error("Incorrect Credentials");
                    }

                    if(!user.IsVerified){
                        throw new Error("Please verify your account before login");
                    }

                    const isPasswordCorrect = await user.isPasswordCorrect(credentials.Password);
                    console.log("password matched", isPasswordCorrect);
                    if(!isPasswordCorrect){
                        throw new Error("Incorrect Credentials");
                    }

                    const profile = await ProfileModel.findOne({UserId: user._id})

                    user.LastLogin = new Date();
                    await user.save();
                    return {...user.toObject(), Profile: profile};
                } catch (error: any) {
                    console.log("next auth error", error)
                    throw new Error(error);
                }
            }
        })
    ],
    pages: {
        // signIn: '/sign-in',
        signIn: '/auth/signin',
        signOut: '/auth/signout',
        error: '/auth/error',
        verifyRequest: '/auth/verify-request',
        newUser: '/auth/new-user'
    },
    session: {
        strategy: "jwt",
    },
    secret: env.nextAuthSecret,
    callbacks: {
        async signIn({ user, account, profile }: any) {
            await dbConnect();

            if (account?.provider === "google") {
                try {
                    const existingGoogleId = await UserModel.findOne({ GoogleId: user.id });
                    if (existingGoogleId) {
                        const userProfile = await ProfileModel.findOne({ UserId: existingGoogleId._id });
        
                        user._id = existingGoogleId._id?.toString();
                        user.Email = existingGoogleId.Email;
                        user.UserName = existingGoogleId.UserName;
                        user.IsVerified = existingGoogleId.IsVerified;
                        user.UserType = existingGoogleId.UserType;
                        (user as any).Profile = userProfile ? userProfile.toObject() : {};
                        return true;
                    }
        
                    const existingUser = await UserModel.findOne({ Email: profile?.email });
                    if (existingUser) {
                        existingUser.GoogleId = user.id;
                        await existingUser.save();
                        const userProfile = await ProfileModel.findOne({ UserId: existingUser._id });
                        user._id = existingUser._id?.toString();
                        user.Email = existingUser.Email;
                        user.UserName = existingUser.UserName;
                        user.IsVerified = existingUser.IsVerified;
                        user.UserType = existingUser.UserType;
                        (user as any).Profile = userProfile ? userProfile.toObject() : {};
                        return true;
                    }

                    const newUser = new UserModel({
                        GoogleId: user.id,
                        Email: profile?.email,
                        UserName: profile?.name?.replace(/\s/g, '').toLowerCase() + Math.floor(Math.random() * 10000), // Generate a unique username
                        IsVerified: true
                    });
                    const savedUser = await newUser.save();
    
                    const newProfile = new ProfileModel({
                        UserId: savedUser._id,
                        FirstName: profile?.given_name,
                        LastName: profile?.family_name,
                        Avatar: profile?.picture,
                    });
                    const savedProfile = await newProfile.save();
    
                    user._id = savedUser._id?.toString();
                    user.Email = savedUser.Email;
                    user.UserName = savedUser.UserName;
                    user.IsVerified = savedUser.IsVerified;
                    user.UserType = savedUser.UserType;
                    (user as any).Profile = savedProfile.toObject();
                    return true;

                } catch (error) {
                    console.error("Error saving user from Google sign-in:", error);
                    return false; // Indicate sign-in failed
                }
            }
            return true;
        },
        async jwt({token, user, trigger}) {
            console.log("check its signup or signin", {trigger});
            if(user){
                token._id = user._id?.toString();
                token.Email = user.Email?.toString();
                token.UserName = user.UserName?.toString();
                token.IsVerified = user.IsVerified;
                token.UserType = user.UserType?.toString();
                token.FirstName = user.Profile?.FirstName?.toString();
                token.LastName = user.Profile?.LastName?.toString();
                token.Avatar = user.Profile?.Avatar?.toString();
                token.CoverImage = user.Profile?.CoverImage?.toString();
                token.Logo = user.Profile?.Logo?.toString();
            }
            return token;
        },
        async session({session, token}){
            if(token){
                session.user._id = token._id;
                session.user.Email = token.Email?.toString();
                session.user.UserName = token.UserName?.toString();
                session.user.IsVerified = token.IsVerified;
                session.user.UserType = token.UserType?.toString();
                session.user.FirstName = token.FirstName?.toString();
                session.user.LastName = token.LastName?.toString();
                session.user.Avatar = token.Avatar?.toString();
                session.user.CoverImage = token.CoverImage?.toString();
                session.user.Logo = token.Logo?.toString();
            }
            return session;
        }
    }
}