import { useSession, UseSessionOptions } from "next-auth/react"


export function useAuthSession(options?: UseSessionOptions<boolean>) {
    const {data: session, status, ...rest} = useSession(options);
    let isAuthenticated = false;
    let isLoading = true;

    switch (status) {
        case "loading":
            isLoading = true;
            isAuthenticated = false;
            break;
        case "authenticated": 
            isAuthenticated = true;
            isLoading = false;
            break;
        case "unauthenticated":
            isAuthenticated = false;
            isLoading = false;
            break;
    }

    return {
        isAuthenticated,
        isLoading,
        session,
        ...rest
    }
}