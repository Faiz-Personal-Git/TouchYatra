import { Collections, databases } from '@/constants';
import { createModel } from '@/lib';
import {Document, Model, Schema} from 'mongoose'

export interface Award extends Document {
  UserId: Schema.Types.ObjectId;
  Title: string;
  Url: string;
  Date: Date;
  Awarder: string;
  Summary: string;
}

const AwardSchema = new Schema<Award>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        Title: {
            type: String,
            required: true
        },
        Url: {
            type: String
        },
        Date: {
            type: Date,
            required: true
        },
        Awarder: {
            type: String
        },
        Summary: {
            type: String
        }
    }, {timestamps: true}
)

export const AwardModel = createModel(databases.main, Collections.Award, AwardSchema) as Model<Award>;