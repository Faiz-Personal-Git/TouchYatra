import React from 'react'
import {InputOTP, InputOTPGroup, InputOTPSeparator, InputOTPSlot}  from '@ui/shadcnUi/input-otp'
import { cn } from '@/lib/utils';

export interface OtpInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

export const OtpInput = React.forwardRef<HTMLInputElement, any>(({className, ...rest}, ref) => {
    const otpSlotClass: string = "w-full space-x-4 rounded-sm bg-gray-50 dark:bg-zinc-800 text-black dark:text-white shadow-input";
  return (
    <InputOTP className={cn("w-full space-x-4 rounded-sm ", className)} maxLength={6} {...rest} ref={ref}>
      <InputOTPGroup className="w-full space-x-4 rounded-sm bg-gray-50">
        <InputOTPSlot className={otpSlotClass} index={0} />
        <InputOTPSlot className={otpSlotClass} index={1} />
        <InputOTPSlot className={otpSlotClass} index={2} />
        <InputOTPSlot className={otpSlotClass} index={3} />
        <InputOTPSlot className={otpSlotClass} index={4} />
        <InputOTPSlot className={otpSlotClass} index={5} />
      </InputOTPGroup>
    </InputOTP>
  )
})
