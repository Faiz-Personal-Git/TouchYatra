"use client";
import React from "react";
import {FormField, Form, FormMessage, FormControl, FormItem, LabelInputContainer, Input, Label} from '@common/index'
import * as z from "zod";
import {zodResolver} from '@hookform/resolvers/zod'
import { useForm } from "react-hook-form";
import { sendVerificationTokenSchema} from "@/schemas";
import { Loader2 } from "lucide-react";
import Link from "next/link";
import {authRepo as repo} from '@/repository'
import { useToast } from "@/hooks";
import { toastVariants } from "@/constants/index";

export default function ForgetPassword() {
  const {toast} = useToast()
  const form = useForm<z.infer<typeof sendVerificationTokenSchema>>({
    resolver: zodResolver(sendVerificationTokenSchema),
    defaultValues : {
      UserName: ""
    }
  })

  const onSubmit = form.handleSubmit(async function(data: z.infer<typeof sendVerificationTokenSchema>): Promise<void>{
    const {success, message} = await repo.sendResetPasswordToken(data.UserName)
    toast({
      title: success ? "Success" : "Error",
      description: message,
      variant: success ? toastVariants.default : toastVariants.destructive,
    })
    if(success){
      form.reset();
    }
  })

  return (
    <>
      <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black my-10">
        <h2 className="font-bold text-xl text-neutral-800 dark:text-neutral-200">
          Welcome to Profyler
        </h2>

        <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
          Send verification email for Forget password
        </p>

        <Form {...form}>
          <form className="my-8" onSubmit={onSubmit}>
            <FormField
              control={form.control}
              name="UserName"
              render={({field}) => (
                <FormItem>
                  <FormControl>
                    <LabelInputContainer className="mb-4">
                      <Label htmlFor="UserName">UserName</Label>
                      <Input placeholder="UserName" {...field} />
                      <FormMessage/>
                    </LabelInputContainer>
                  </FormControl>
                </FormItem>
              )}
            />
            <button className="p-[3px] relative w-full" type="submit" disabled={form.formState.isSubmitting}>
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
              <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent flex justify-center">
                {
                  form.formState.isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 w-5 animate-spin" />
                      Sending email...
                    </>
                  ) : ("Send Email")
                }
              </div>
            </button>

            <div className='text-center mt-3'>
              <p>
                  If you don't have an Account? <Link  rel="preload" href="/sign-up" className='text-blue-600 hover:text-blue-800'>Sign Up</Link>
              </p>
            </div>
          </form>
        </Form>
        <div className="bg-gradient-to-r from-transparent via-neutral-300 dark:via-neutral-700 to-transparent my-8 h-[1px] w-full" />
      </div>
    </>
  );
}