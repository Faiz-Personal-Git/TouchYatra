import { ApiResponse, callApi } from "@/utils";

export async function upsertProject(data: any): Promise<ApiResponse>{
    return callApi({method: "POST", url: "/api/v1/projects/upsert", data });
}

export async function userProjects(userId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/project/user-projects/${userId}`});
}

export async function getProjectById(ProjectId: string): Promise<ApiResponse>{
    return callApi({method: "GET", url: `/api/v1/project/getById/${ProjectId}`});
}

export async function deleteProject(ProjectId: string): Promise<ApiResponse>{
    return callApi({method: "DELETE", url: `/api/v1/project/delete-project/${ProjectId}`});
}