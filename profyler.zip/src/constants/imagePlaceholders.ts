export const imagePlaceholders = {
    avtar1: "/assets/theme/images/blank-profile-picture-2.jpg"
} as const