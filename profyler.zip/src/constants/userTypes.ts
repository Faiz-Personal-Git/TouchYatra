export const UserTypes = [
    "admin",
    "user"
] as const;
