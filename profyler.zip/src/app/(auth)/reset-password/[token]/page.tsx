"use client";

import { useParams } from "next/navigation";
import {ResetPassword} from '@/views/(auth)'
import { Metadata } from "next";

export default function page() {
  const {token} = useParams<{token: string}>()
  return <ResetPassword token={token} />
}

const metadata: Metadata = {
  title: `Profyler - Reset Password`,
  description: `Reset your Password`,
  icons: {
    icon: `path to asset file`,
  },
}