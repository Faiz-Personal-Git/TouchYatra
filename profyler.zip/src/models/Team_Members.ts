import { Collections, databases } from "@/constants";
import { createModel } from "@/lib";
import { Schema, Model, Document } from "mongoose";

export interface Team_Members extends Document {
    UserId: Schema.Types.ObjectId;
    MemberName: string;
    Designation: string;
    Company: string;
    Email: string;
    ImageUrl: string;
    Experience: number;
    Bio: string;
    Skills: string[];
    Social: {
        Facebook: string;
        Twitter: string;
        LinkedIn: string;
        Instagram: string;
        Github: string;
    }
}

const Team_MembersSchema = new Schema<Team_Members>({
    UserId: {
        type: Schema.Types.ObjectId,
        ref: Collections.User,
        required: [true, 'User ID is required']
    },
    MemberName: {
        type: String,
        required: true
    },
    Designation: {
        type: String,
        required: true
    },
    Company: {
        type: String
    },
    Email: {
        type: String
    },
    ImageUrl: {
        type: String
    },
    Experience: {
        type: Number
    },
    Bio: {
        type: String,
        required: true
    },
    Skills: {
        type: [String]
    },
    Social: {
        Facebook: {
            type: String
        },
        Twitter: {
            type: String
        },
        LinkedIn: {
            type: String
        },
        Instagram: {
            type: String
        },
        Github: {
            type: String
        }
    }
}, {timestamps: true});

export const TeamMemberModel = createModel(databases.main, Collections.TeamMembers, Team_MembersSchema) as Model<Team_Members>;