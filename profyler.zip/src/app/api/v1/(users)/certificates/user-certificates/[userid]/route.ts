import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { CertificateModel } from "@/models";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const certificates = (await CertificateModel.find({ UserId: params.userid?.toObjectId() })) ?? [];
    return new ApiResponse(
        200, 
        certificates.toRecords(),
        'Certificates fetched successfully.'
    );
})