import "next-auth";
import {DefaultSession} from "next-auth";

declare module "next-auth" {
    interface User {
        _id?: string;
        IsVerified?: boolean;
        UserName?: string;
        Email?: string;
        UserType?: string;
        Profile?: {
            FirstName?: string;
            LastName?: string;
            Avatar?: string;
            CoverImage?: string;
            Logo?: string;
        }
    }
    interface Session {
        user: {
            _id?: string;
            IsVerified?: boolean;
            UserName?: string;
            Email?: string;
            UserType?: string;
            FirstName?: string;
            LastName?: string;
            Avatar?: string;
            CoverImage?: string;
            Logo?: string;
        } & DefaultSession["user"];
    }
}

declare module "next-auth/jwt" {
    interface JWT {
        _id?: string;
        IsVerified?: boolean;
        UserName?: string;
        Email?: string;
        UserType?: string;
        FirstName?: string;
        LastName?: string;
        Avatar?: string;
        CoverImage?: string;
        Logo?: string;
    }
}