import { env } from "@/configuration"
import {Html, Head, Font, Preview, Heading, Row, Section, Text, Button} from "@react-email/components"

interface ForgetPasswordVerificationEmailProps {
    FirstName: string,
    UserName?: string;
    Token: string
}

export  function ForgetPasswordVerificationEmail({FirstName, UserName, Token}: ForgetPasswordVerificationEmailProps){
    return (
        <Html lang="en" dir="ltr">
            <Head>
                <title>Forget password</title>
                <Font 
                    fontFamily="Roboto"
                    fallbackFontFamily="Verdana"
                    webFont={{
                        url: "https://fonts.gstatic.com/s/roboto/v27/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.woff2",
                        format: 'woff2'
                    }}
                    fontWeight={400}
                    fontStyle="normal"
                />
            </Head>
            <Section>
                <Row>
                    <Heading as="h2">Hello {FirstName}</Heading>
                </Row>
                <Row>
                    <Text>
                        Thank you, Please click the below button to forget your password.
                    </Text>
                </Row>
                <Row>
                    <Button href={`${env.appDomain}/reset-password/${Token}`} style={{color: '#61dafb'}}>
                        Verify here
                    </Button>
                </Row>
                <Row>
                    <Text>
                        If you did not request this code, please ignore this email.
                    </Text>
                </Row>
            </Section>
        </Html>
    )
}