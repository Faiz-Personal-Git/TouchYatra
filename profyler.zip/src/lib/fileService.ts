import fs from 'fs/promises'
import {fileURLToPath} from 'url'
import Path, {dirname} from 'path'
import multer from 'multer'
import { env } from "@/configuration"

interface MulterCallback {
    (req: any, file: any, cb: (error: Error | null, filename: string) => void): string | void;
}
  
export interface UploadFileOptions {
    path?: string;
    callback?: MulterCallback;
    filesize?: number;
}

export const uploadFile = async ({path, callback, filesize}: UploadFileOptions): Promise<multer.Multer> => {
  return multer({ 
    storage : multer.diskStorage({
      destination: async (req, file, cb) => {
        const uploadDir = `./public/${path ? path : 'temp'}`
        const isDirectoryExists = await createDirectoryIfNotExists(uploadDir);
        if(!isDirectoryExists){
          cb(new Error("error creating directory"), "error creating directory");
        }else{
            cb(null, uploadDir);
        }
      },
      filename: function(req, file, cb){
        if(file){
          
          if(!callback){
            let fileExtension = "";
            if (file.originalname.split(".").length > 1) {
              fileExtension = file.originalname.substring(
                file.originalname.lastIndexOf(".")
              );
            }
            const filenameWithoutExtension = file.originalname
            .toLowerCase()
            .split(" ")
            .join("-")
            ?.split(".")[0];
            cb(
              null,
              filenameWithoutExtension +
                  Date.now() +
                  Math.ceil(Math.random() * 1e5) + // avoid rare name conflict
                  fileExtension
            );
            return;
          }

          const result = callback(req, file, cb)
          if(result && typeof result === "string"){
            cb(null, result)
          }
        }
      }
    }),
    limits: {
      fileSize: filesize ? (filesize <= env.maxUploadFileSize ? filesize : env.maxUploadFileSize) : env.maxUploadFileSize,
    }
  })
}

export async function checkDirectoryExistance(directory: string){
    try {
        await fs.access(directory, fs.constants.R_OK | fs.constants.W_OK);
        return true;
    } catch (error) {
        return false;
    }
}

export async function createDirectoryIfNotExists(directory: string){
    try {
        const isDirectoryExists = await checkDirectoryExistance(directory);
        if(!isDirectoryExists){
            await fs.mkdir(new URL(directory, import.meta.url), { recursive: true });
        }
        return true;
    } catch (error) {
        console.log('error while creating directory', error)
        return false;
    }
}

export async function removeFile(filepath: string){
  try {
    const localFilePath = Path.join(dirname(fileURLToPath(import.meta.url)), '../../public', filepath);
    await fs.unlink(localFilePath);
  } catch (error) {
    console.log('error while remove file', error)
  }
}

export async function removeLocalFile(localPath: string){
  try {
    await fs.unlink(localPath);
    console.log('file removed successfully');
  } catch (error) {
    console.log('error while remove file', error)
  }
};

export async function removeUnusedMulterImageFilesOnError(req: any){
  try {
    const multerFile = req.file;
    const multerFiles = req.files;

    if (multerFile) {
      await removeLocalFile(multerFile.path);
    }

    if (multerFiles) {
      const filesValueArray = Object.values(multerFiles);
      filesValueArray.map((fileFields: any) => {
        fileFields.map((fileObject: any) => {
          removeLocalFile(fileObject.path);
        });
      });
    }
  } catch (error) {
    console.log("Error while removing image files: ", error);
  }
};