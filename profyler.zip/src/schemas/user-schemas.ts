import { z } from "zod";
// .regex(/^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?$/, "Enter a valid facebook url!")

export const upsertTeamSchema = z.object({
    _id: z.string().optional(),
    UserId: z.string({message: "UserId is required!"}).trim(),
    MemberName: z.string({message: "Name is required!"}).trim(),
    Designation: z.string({message: "Designation is required!"}).trim(),
    Company: z.string().trim().optional(),
    Email: z.string({message: "Email is required!"}).email({message: "Enter a valid email!"}).trim(),
    ImageFile: z.any().optional(),
    ImageUrl: z.string().optional(),
    Experience: z.number({message: "Experience is required!"}).optional(),
    Bio: z.string({message: "Bio is required!"}).trim(),
    Skills: z.array(z.string()).optional(),
    SkillsString: z.string().optional(),
    Social: z.object({
        Facebook: z.string().trim().optional(),
        Twitter: z.string().trim().optional(),
        LinkedIn: z.string().trim().optional(),
        Instagram: z.string().trim().optional(),
        Github: z.string().trim().optional(),
    }).optional()
})

export const upsertProjectSchema = z.object({
    UserId: z.string({message: "UserId is required!"}),
    ProjectName: z.string({message: "Project Name is required!"}).trim(),
    ProjectType: z.string({message: "Project Type is required!"}).trim(),
    StartDate: z.date({message: "Start Date is required!"}),
    EndDate: z.nullable(z.date()).optional(),
    Description: z.string({message: "Description is required!"}).trim(),
    TechnologiesUsed: z.array(z.string()).optional(),
    Technologies: z.string().optional(),
    TeamMembers: z.array(z.string()).optional(),
    TeamMembersIds: z.string().optional(),
    ProjectUrl: z.string().optional(),
    ImageUrl: z.array(z.string()).optional(),
    Images: z.any().optional(),
    Contributions: z.string().optional(),
})