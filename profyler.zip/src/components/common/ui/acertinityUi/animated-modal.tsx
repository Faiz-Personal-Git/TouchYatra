"use client";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import React, {
  ReactNode,
  createContext,
  forwardRef,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import {useOutsideClick} from '@/hooks/index'

interface ModalContextType {
  open: boolean;
  setOpen: (open: boolean) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

const ModalContext = createContext<ModalContextType | undefined>(undefined);

interface ModelProps {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onOpen?: () => void;
  onClose?: () => void;
  children: ReactNode;
}


export const ModalProvider = ({ open, setOpen, onOpen, onClose, children }: ModelProps) => {

  useEffect(() => {
    if(open){
      onOpen && onOpen();
    }
    if(!open){
      onClose && onClose();
    }
  }, [open])

  return (
    <ModalContext.Provider value={{ open, setOpen, onOpen, onClose }}>
      {children}
    </ModalContext.Provider>
  );
};

export const useModal = () => {
  const context = useContext(ModalContext);
  if (!context) {
    throw new Error("useModal must be used within a ModalProvider");
  }
  return context;
};


export function Modal({ open, setOpen, onOpen, onClose, children }: ModelProps) {
  return <ModalProvider open={open} setOpen={setOpen} onOpen={onOpen} onClose={onClose}>{children}</ModalProvider>;
}

export const ModalTrigger = ({
  children,
  className,
  onClick
}: {
  children: ReactNode;
  className?: string;
  onClick?: (event: any) => void;
}) => {
  const { setOpen } = useModal();
  return (
    <div
      className={cn(
        "px-4 py-2 rounded-md text-black dark:text-white text-center relative overflow-hidden cursor-pointer",
        className
      )}
      onClick={(e) => {
        onClick && onClick(e);
        setOpen(true);
      }}
    >
      {children}
    </div>
  );
};

export const ModalHeader = ({
  children, 
  className
}: {
  children: ReactNode;
  className?: string; 
}) => {
  return (
    <h4 className={cn("text-lg md:text-2xl text-neutral-600 dark:text-neutral-100 font-bold text-center mt-5 pb-3 border-b", className)}>
      <CloseIcon />
      {children}
    </h4>
  )
}

export const ModalBody = ({
  children,
  className,
  variant = "md",
  scrollable
}: {
  children: ReactNode;
  className?: string;
  variant?: "sm" | "md" | "lg" | "xl" | "full";
  scrollable?: boolean;
}) => {
  const { open } = useModal();

  const ModalWidth = 
            variant === "sm" 
            ? "md:max-w-[25%]" 
            : variant === "md" 
            ? "md:max-w-[40%]" 
            : variant === "lg" 
            ? "md:max-w-[60%]" 
            : variant === "xl" 
            ? "md:max-w-[80%]" 
            : variant === "full" 
            ? "md:max-w-[96%]" 
            : "md:max-w-[85%]";

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
  }, [open]);

  const modalRef = useRef<HTMLDivElement>(null);
  const { setOpen } = useModal();
  useOutsideClick(modalRef, () => setOpen(false));

  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open && modalRef.current && overlayRef.current) {
      const resizeObserver = new ResizeObserver((entries) => {
        for (let entry of entries) {
          if(overlayRef.current){
            overlayRef.current.style.height = `${entry.borderBoxSize[0].blockSize + 120}px`;
          }
        }
      });

      resizeObserver.observe(modalRef.current);

      return () => resizeObserver.disconnect();
    }
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{
            opacity: 0,
          }}
          animate={{
            opacity: 1,
            backdropFilter: "blur(10px)",
          }}
          exit={{
            opacity: 0,
            backdropFilter: "blur(0px)",
          }}
          className="fixed [perspective:800px] [transform-style:preserve-3d] inset-0 h-full w-full  flex items-baseline justify-center z-50 overflow-y-auto"
        >
          <Overlay ref={overlayRef} />

          <motion.div
            ref={modalRef}
            className={cn(
              "bg-white dark:bg-neutral-950 border border-transparent dark:border-neutral-800 md:rounded-2xl relative z-50 flex flex-col flex-1 mt-8",
              ModalWidth,
              scrollable ? "max-h-screen" : "",
              className
            )}
            initial={{
              opacity: 0,
              scale: 0.5,
              rotateX: 40,
              y: 40,
            }}
            animate={{
              opacity: 1,
              scale: 1,
              rotateX: 0,
              y: 0,
            }}
            exit={{
              opacity: 0,
              scale: 0.8,
              rotateX: 10,
            }}
            transition={{
              type: "spring",
              stiffness: 260,
              damping: 15,
            }}
          >
            
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const ModalContent = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) => {
  return (
    <div className={cn("flex flex-col flex-1 p-8 md:p-10 h-full", className)}>
      {children}
    </div>
  );
};

export const ModalFooter = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) => {
  return (
    <div
      className={cn(
        "flex justify-end p-4 bg-gray-100 dark:bg-neutral-900 rounded-br-2xl rounded-bl-2xl",
        className
      )}
    >
      {children}
    </div>
  );
};

const Overlay = forwardRef<HTMLDivElement, { className?: string }>(({ className }, ref) => {
  return (
    <motion.div
      ref={ref}
      initial={{
        opacity: 0,
      }}
      animate={{
        opacity: 1,
        backdropFilter: "blur(10px)",
      }}
      exit={{
        opacity: 0,
        backdropFilter: "blur(0px)",
      }}
      className={`fixed inset-0 h-full w-full bg-black bg-opacity-50 z-50 min-h-[120vh] ${className}`}
    ></motion.div>
  );
});

const CloseIcon = () => {
  const { setOpen } = useModal();
  return (
    <button
      onClick={() => setOpen(false)}
      className="absolute top-4 right-4 group"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-black dark:text-white h-4 w-4 group-hover:scale-125 group-hover:rotate-3 transition duration-200"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M18 6l-12 12" />
        <path d="M6 6l12 12" />
      </svg>
    </button>
  );
};
