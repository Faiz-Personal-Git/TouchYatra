import { ApiResponse, callApi } from "@/utils";

export async function getCountryByCode(code: string): Promise<ApiResponse> {
    return callApi({method: "GET", url: `/api/v1/countries/getCountryByCode/${code}`});
}

export async function getCountries(search?: string): Promise<ApiResponse> {
    return callApi({method: "GET", url: `/api/v1/countries/getCountries?search=${search}`});
}