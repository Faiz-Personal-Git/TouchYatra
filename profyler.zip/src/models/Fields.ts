import { Collections, databases } from "@/constants";
import { createModel } from "@/lib";
import {Model, Schema, Document} from "mongoose";

export interface CommonField extends Document {
    Label: string;
    Url: string;
    Hide: boolean;
    IsPrimary: boolean;
}

export const CommonFieldSchema: Schema = new Schema<CommonField>(
    {
        Label: {
            type: String,
            required: true
        },
        Url: {
            type: String,
            required: true
        },
        Hide: {
            type: Boolean,
            default: false
        },
        IsPrimary: {
            type: Boolean,
            default: false
        }
    }
);

export interface Fields extends Document {
    UserId: Schema.Types.ObjectId,

    //Link fields
    Website: CommonField[],
    Link: CommonField[],
    GitHub: CommonField[],
    Address: CommonField[],
    Instagram: CommonField[],
    Linkedin: CommonField[],
    Facebook: CommonField[],
    X: CommonField[],
    Snapchat: CommonField[],
    Pinterest: CommonField[],
    TikTok: CommonField[],
    Xing: CommonField[],
    Zoom: CommonField[],
    Teams: CommonField[],
    Meet: CommonField[],
    Whatsapp: CommonField[],
    Telegram: CommonField[],
    Discord: CommonField[],
    Line: CommonField[],
    Email: CommonField[],
    Youtube: CommonField[],
    Vimeo: CommonField[],
    Spotify: CommonField[],
    AppleMusic: CommonField[],
    SoundCloud: CommonField[],
    Behance: CommonField[],
    Dribbble: CommonField[],
    Twitch: CommonField[],

    // copyToClipboard fields
    Skype: CommonField[];
    WeChat: CommonField[];
    Signal: CommonField[];
    PSN: CommonField[];
    XboxLive: CommonField[];
    Notes: CommonField[];
}

const FieldsSchema: Schema = new Schema<Fields>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        Website: [CommonFieldSchema],
        Link: [CommonFieldSchema],
        GitHub: [CommonFieldSchema],
        Address: [CommonFieldSchema],
        Instagram: [CommonFieldSchema],
        Linkedin: [CommonFieldSchema],
        Facebook: [CommonFieldSchema],
        X: [CommonFieldSchema],
        Snapchat: [CommonFieldSchema],
        Pinterest: [CommonFieldSchema],
        TikTok: [CommonFieldSchema],
        Xing: [CommonFieldSchema],
        Zoom: [CommonFieldSchema],
        Teams: [CommonFieldSchema],
        Meet: [CommonFieldSchema],
        Whatsapp: [CommonFieldSchema],
        Telegram: [CommonFieldSchema],
        Discord: [CommonFieldSchema],
        Line: [CommonFieldSchema],
        Email: [CommonFieldSchema],
        Youtube: [CommonFieldSchema],
        Vimeo: [CommonFieldSchema],
        Spotify: [CommonFieldSchema],
        AppleMusic: [CommonFieldSchema],
        SoundCloud: [CommonFieldSchema],
        Behance: [CommonFieldSchema],
        Dribbble: [CommonFieldSchema],
        Twitch: [CommonFieldSchema],

        //Copy to clipboard fields
        Skype: [CommonFieldSchema],
        WeChat: [CommonFieldSchema],
        Signal: [CommonFieldSchema],
        PSN: [CommonFieldSchema],
        XboxLive: [CommonFieldSchema],
        Notes: [CommonFieldSchema]
    }
);

export const FieldsModel = createModel(databases.main, Collections.Fields, FieldsSchema) as Model<Fields>;