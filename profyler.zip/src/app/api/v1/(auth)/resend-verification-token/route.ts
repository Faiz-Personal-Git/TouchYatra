import {ProfileModel, UserModel} from '@/models'
import {ApiError, ApiResponse, asyncHandler, sendEmail} from '@/utils'
import { VerificationEmail } from '@emails/index';

export const GET = asyncHandler(true, async (req: Request) => {

    const {searchParams} = new URL(req.url);
    const UserName = searchParams.get("UserName");

    const user = await UserModel.findOne({UserName});
    if(!user){
        throw new ApiError(404, "User not found");
    }

    if(user.IsVerified){
        throw new ApiError(400, "User already verified");
    }

    const profile = await ProfileModel.findOne({UserId: user._id});


    const emailres = await sendEmail({
        to: user.Email,
        subject: "Verify your Account!",
        react: VerificationEmail({FirstName: profile?.FirstName ?? user.UserName, UserName: user.UserName, Token: user.generateToken()}),
    });
    
    if(!emailres){
        throw new ApiError(500, "Error sending verification code to your email account.");
    }
    
    return new ApiResponse(201, null, "Verification code sent successfully to your email account.");
})