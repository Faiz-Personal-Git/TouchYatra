import { Collections, databases } from '@/constants';
import { createModel } from '@/lib';
import {Document, Model, Schema} from 'mongoose'

export interface Project extends Document {
  UserId: Schema.Types.ObjectId;
  ProjectName: string;
  ProjectType: string;
  StartDate: Date;
  EndDate: Date;
  Description: string;
  TechnologiesUsed: [string];
  TeamMembers: [Schema.Types.ObjectId];
  ProjectUrl: string;
  ImageUrl: [string];
  Contributions: string;
}

const projectSchema = new Schema<Project>({
  UserId: {
    type: Schema.Types.ObjectId,
    ref: Collections.User,
    required: [true, 'User ID is required']
  },
  ProjectName: {
    type: String,
    required: [true, 'Project Name is required']
  },
  ProjectType: {
    type: String,
    required: [true, 'Project Type is required']
  },
  StartDate: {
    type: Date,
    required: [true, 'Start Date is required']
  },
  EndDate: {
    type: Date
  },
  Description: {
    type: String,
    required: [true, 'Description is required']
  },
  TechnologiesUsed: {
    type: [String]
  },
  TeamMembers: {
    type: [Schema.Types.ObjectId],
    ref: Collections.TeamMembers
  },
  ProjectUrl: {
    type: String
  },
  ImageUrl: {
    type: [String]
  },
  Contributions: {
    type: String
  }
}, {timestamps: true});

export const ProjectModel = createModel(databases.main, Collections.Projects, projectSchema) as Model<Project>;