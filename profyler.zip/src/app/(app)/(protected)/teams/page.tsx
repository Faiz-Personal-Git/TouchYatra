import Teams from '@/views/(protected)/Teams'
import { Metadata } from 'next';
import React from 'react'

export default function page() {
  return (
    <Teams/>
  )
}


export const metadata: Metadata = {
  title: "Profyler - Teams",
  description: "Profile - Teams",
};