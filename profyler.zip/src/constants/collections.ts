export const Collections = {
    User: "Users",
    Countries: "Countries",
    Education: "Education",
    Experience: "Experience",
    Fields: "Fields",
    Profile: "Profiles",
    Projects: "Projects",
    TeamMembers: "Team_Members",
    Certificates: "Certificates",
    Award: "Awards",
    Skills: "Skills"
} as const;