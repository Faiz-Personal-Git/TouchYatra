export interface Award {
    UserId: string;
    Title: string;
    Url: string;
    Date: Date;
    Awarder: string;
    Summary: string;
}

export interface Certificate {
    UserId: string;
    CertificateName: string;
    Url: string;
    IssuedDate: Date;
    IssuedBy: string;
    Summary: string;
}

export interface Country {
    Name: string;
    Code: string;
    Phone: string;
    Suggested?: boolean;
}
  
export interface Education {
    UserId: string;
    EducationLevel: string;
    Institute: string;
    Degree: string;
    SpecializationOfStudy: string;
    Notes: string;
    StartDate: Date;
    EndDate: Date;
    Marks: number;
    Grade: number;
    City: string;
    State: string;
    Country: string;
}

export interface Experience extends Document {
    UserId: string;
    Company: string;
    JobTitle: string;
    StartDate: Date;
    EndDate: Date;
    Description: string;
    Location: string;
    Industry: string; 
    Website: string;
    Responsibilities: string[];
    SkillsUsed: string[];
}

export interface Team_Members {
    _id?: string;
    UserId: string;
    MemberName: string;
    Designation: string;
    Company: string;
    ImageUrl: string;
    Experience: number;
    Bio: string;
    Skills: string[];
    Social?: {
        Facebook?: string;
        Twitter?: string;
        LinkedIn?: string;
        Instagram?: string;
        Github?: string;
    }
}


export interface Project {
    _id: string;
    UserId: string;
    ProjectName: string;
    ProjectType: string;
    StartDate: Date;
    EndDate: Date;
    Description: string;
    TechnologiesUsed: string[];
    TeamMembers: Team_Members[];
    ProjectUrl: string;
    ImageUrl: string[];
    Contributions: string;
}

export interface Affiliation {
    Title: string;
    Department: string;
    Company: string;
    Headline: string;
}

export interface Profile {
    UserId: string;
    //Name
    Prefix: string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    Suffix: string;
    MaidenName: string;
    //End Name
    PhoneNo: string;
    Gender: string;
    BirthDay: Date;
    Affiliation?: Affiliation;
    Teams: Team_Members[];
    Avatar: string;
    CoverImage: string;
    Logo: string;
}

export interface Skills {
    UserId: string;
    Name: string;
    Descriptions: string;
    Level: number;
    Keywords: string[];
}

export interface User extends Document {
    UserName: string;
    Email: string;
    Password?: string;
    IsVerified: boolean;
    GoogleId?: string;
    UserType: string;
    LastLogin: Date;
}