import React, { useEffect } from 'react'

export interface SettingContextType {
    bodyClassName: string;
    setBodyClassName: React.Dispatch<React.SetStateAction<string>>;
    mainCardClassName: string;
    setMainCardClassName: React.Dispatch<React.SetStateAction<string>>;
}

export const SettingContext = React.createContext<SettingContextType>({
    bodyClassName: "",
    setBodyClassName: () => {},
    mainCardClassName: "",
    setMainCardClassName: () => {}
})

export function SettingProvider({children}: { children: React.ReactNode | React.JSX.Element}) {
    const [bodyClassName, setBodyClassName] = React.useState<string>("")
    const [mainCardClassName, setMainCardClassName] = React.useState<string>("bg-white")
    
  return (
    <SettingContext.Provider value={{bodyClassName, setBodyClassName, mainCardClassName, setMainCardClassName}}>
      {children}
    </SettingContext.Provider>
  )
}

export interface useSettingContextProps {
  bodyClassName?: string;
  mainCardClassName?: string;
}

export function useSettingContext({bodyClassName, mainCardClassName}: useSettingContextProps): SettingContextType{
    const context = React.useContext(SettingContext)
    if (!context) {
        throw new Error("useSettingContext must be used within a SettingProvider")
    }

    useEffect(() => {
        if(bodyClassName){
            context.setBodyClassName(bodyClassName)
        }
        if(mainCardClassName){
            context.setMainCardClassName(mainCardClassName)
        }
    }, [])
    return context
}