import { Collections, databases } from '@/constants';
import { createModel } from '@/lib';
import {Document, Model, Schema} from 'mongoose'

export interface Certificate extends Document {
  UserId: Schema.Types.ObjectId;
  CertificateName: string;
  Url: string;
  IssuedDate: Date;
  IssuedBy: string;
  Summary: string;
}

const CertificateSchema = new Schema<Certificate>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        CertificateName: {
            type: String,
            required: true,
        },
        Url: {
            type: String,
        },
        IssuedDate: {
            type: Date,
            required: true,
        },
        IssuedBy: {
            type: String
        },
        Summary: {
            type: String
        }
    }, {timestamps: true}
)

export const CertificateModel = createModel(databases.main, Collections.Certificates, CertificateSchema) as Model<Certificate>;