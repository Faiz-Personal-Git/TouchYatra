"use client"

import {AuthProvider} from '@/context'
import "@/styles/globals.css"
import { Toaster } from "@ui/shadcnUi/toaster"
import {Inter} from "next/font/google"
import "@/utils/prototypes"
import { SettingProvider, useSettingContext } from '@/context/SettingProvider'

const inter = Inter({subsets: ["latin"]});

export function MainLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
        <SettingProvider>
            <AuthProvider>
                <Body>{children}</Body>
            </AuthProvider>
        </SettingProvider>
    </html>
  );
}

const Body = ({children} : {children: React.ReactNode}) => {
    const {bodyClassName} = useSettingContext({})
    return (
        <body
          // className={`${inter.className} ${bodyClassName} h-full overflow-hidden bg-gray-100`}
          // className={`${inter.className} ${bodyClassName} flex antialiased h-screen overflow-hidden bg-gray-100`}
          className={`${inter.className} ${bodyClassName} flex antialiased overflow-hidden bg-gray-100`}
        >
            {children}
            <Toaster/>
        </body>
    )
}
