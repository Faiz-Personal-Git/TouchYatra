import { Metadata } from 'next';
// import React from 'react'

// export default function page() {
//   return (
//     <div>
      
//     </div>
//   )
// }


export const metadata: Metadata = {
  title: "Profyler",
  description: "Profile - Project Details",
};
