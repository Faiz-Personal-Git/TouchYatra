"use client";

import React, {useEffect, useRef, useState} from 'react'
import { modelTypes } from '@/types'
import { useAuthSession, useToast } from '@/hooks'
import { useParams, useRouter } from 'next/navigation'
import { teamRepo } from '@/repository'
import { Container, Form, FormControl, FormDescription, FormField, FormItem, FormMessage, GoBackBtn, Heading, Input, LabelInputContainer, Textarea } from '@common/index';
import { useForm } from 'react-hook-form';
import {upsertTeamSchema} from '@/schemas'
import * as z from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Label } from '@radix-ui/react-label';
import { FaLinkedin, FaTwitter, FaGithub, FaFacebook, FaInstagram  } from "react-icons/fa";
import { MovingBorderButton } from '@/components/common/ui/acertinityUi/moving-border-button';
import {FileDropzone} from '@common/fields/FileDropzone'
import { useSettingContext } from '@/context/SettingProvider';
import {teamMemerDefaultValue} from '@/constants/defaultValues'

export function TeamDetails() {
    
    const {id} = useParams()
    const router = useRouter()
    useSettingContext({})
    const {isAuthenticated, isLoading, session} = useAuthSession({required: true, onUnauthenticated: () => {
            router.replace("/sign-in")
        }})
    const [fetching, setFetching] = useState(true)
    const {toast} = useToast()

    const form = useForm<z.infer<typeof upsertTeamSchema>>({
        resolver: zodResolver(upsertTeamSchema),
        defaultValues: teamMemerDefaultValue
    })
    const {control, handleSubmit, setValue, watch, reset} = form

    useEffect(() => {
        ;(async () => {
            if(id !== "1"){
                const {success, data, message} = await teamRepo.getTeamById(id as string)
                if(success){
                    reset({...data, SkillsString: data.Skills?.join(", ")})
                }else{
                    toast({
                        title: "Failed!",
                        description: message,
                        variant: "destructive"
                    })
                }
                setFetching(false)
            }else{
                setValue("UserId", session?.user?._id as string)
                setFetching(false)
            }
        })()
    }, [id, session])

    useEffect(() => {
        setValue("Skills", watch("SkillsString")?.split(",")?.map(skill => skill.trim()))
    }, [watch("SkillsString")])

    if(isLoading || fetching){
        return <div className='flex flex-col text-center font-bold text-2xl' style={{marginTop: "18%"}}>Loading...</div>
    }

    const onSubmit = handleSubmit(async function(data, event) : Promise<void>{
        event?.preventDefault();
        const formData = [data].toDeepFormData()
        const {success, message} = await teamRepo.upsertTeam(formData)
        toast({
            title: success ? "Success" : "Error",
            description: message,
            variant: success ? "success" : "destructive"
        })

        if(success){
            router.push("/teams")
        }
    })

  return (
    <Container>
        <GoBackBtn />
        <div className='p-5 rounded-2xl border border-solid border-gray-400 shadow-2xl bg-white m-10'>
            <Heading className='mb-4'>
                Team Member
            </Heading>
            <Form {...form}>
                <form onSubmit={onSubmit}>
                    
                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 mb-8'>
                        <FormField
                            name='ImageFile'
                            control={control}
                            render={({field: {onChange, value}})=>(
                                <FormItem className='w-full justify-center flex'>
                                    <FormControl>
                                        <LabelInputContainer>
                                            {/* <Label htmlFor="ImageUrl">Image</Label> */}
                                            <FileDropzone accept={{"image/*": [".jpg", ".png", ".jpeg"]}}  onChange={(file) => onChange(file[0])} uploadedFiles={watch("ImageUrl")} removeUploadedFile={(index) => {
                                                setValue("ImageUrl", "");
                                            }}  />
                                        </LabelInputContainer>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2'>
                        <FormField
                            control={control}
                            name="MemberName"
                            render={({field}) => (
                                <FormItem className='w-full'>
                                    <FormControl>
                                        <LabelInputContainer>
                                            <Label htmlFor="MemberName">Name <span className="text-red-500">*</span></Label>
                                            <Input placeholder="Name" {...field}/>
                                            <FormMessage/>
                                        </LabelInputContainer>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={control}
                            name="Designation"
                            render={({field}) => (
                                <FormItem className='w-full'>
                                    <FormControl>
                                        <LabelInputContainer>
                                            <Label htmlFor="Designation">Designation <span className="text-red-500">*</span></Label>
                                            <Input placeholder="Designation" {...field}/>
                                            <FormMessage/>
                                        </LabelInputContainer>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <div className='flex flex-col md:flex-row gap-2 md:space-y-0 md:space-x-2 my-2'>
                        <FormField
                            control={control}
                            name="Company"
                            render={({field}) => (
                            <FormItem className='w-full'>
                                <FormControl>
                                    <LabelInputContainer>
                                        <Label htmlFor="Company">Company</Label>
                                        <Input placeholder="Company" {...field}/>
                                        <FormMessage/>
                                    </LabelInputContainer>
                                </FormControl>
                            </FormItem>
                            )}
                        />
                        <FormField
                            control={control}
                            name="Experience"
                            render={({field: {onChange, value, ...rest}}) => (
                                <FormItem className='w-full'>
                                    <FormControl>
                                        <LabelInputContainer>
                                            <Label htmlFor="Experience">Experience <span className="text-red-500">*</span></Label>
                                            <Input placeholder="Experience" type="number" value={isNaN(value as number) ? 0 : value} onChange={(e) => onChange(e.target.value?.toIntOrZero())} {...rest}/>
                                            <FormMessage/>
                                        </LabelInputContainer>
                                    </FormControl>
                                </FormItem>
                            )}
                        />
                    </div>
                    <FormField
                        control={control}
                        name="Email"
                        render={({field}) => (
                            <FormItem className='w-full'>
                                <FormControl>
                                    <LabelInputContainer>
                                        <Label htmlFor="Email">Email <span className="text-red-500">*</span></Label>
                                        <Input placeholder="Email" {...field}/>
                                        <FormMessage/>
                                    </LabelInputContainer>
                                </FormControl>
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={control}
                        name="SkillsString"
                        render={({field}) => (
                            <FormItem className='w-full my-2'>
                                <FormControl>
                                    <LabelInputContainer>
                                        <Label htmlFor="SkillsString">Skills</Label>
                                        <Input placeholder="Skills" {...field}/>
                                        <FormDescription>
                                            Multiple skills will be comma seperated
                                        </FormDescription>
                                        <FormMessage/>
                                    </LabelInputContainer>
                                </FormControl>
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={control}
                        name="Bio"
                        render={({field}) => (
                            <FormItem className='w-full my-2'>
                                <FormControl>
                                    <LabelInputContainer>
                                        <Label htmlFor="Bio">Bio <span className="text-red-500">*</span></Label>
                                        <Textarea placeholder="Bio" {...field} className='h-24' />
                                        <FormMessage/>
                                    </LabelInputContainer>
                                </FormControl>
                            </FormItem>
                        )}
                    />
                    
                    <div className='md:space-y-0 md:space-x-2 my-2 space-y-4'>
                        <h3 className="text-lg font-medium text-gray-900 my-3">Social Media Links</h3>

                        <div className="space-y-4">                          
                            <FormField
                                control={control}
                                name="Social.Facebook"
                                render={({field}) => (
                                    <FormItem className='w-full'>
                                        <FormControl>
                                            <LabelInputContainer>
                                                <div className="flex relative">
                                                    <FaFacebook className="text-gray-400 self-start z-50 absolute left-4 mt-4" />
                                                    <Input placeholder="Facebook" className='w-full placeholder:translate-x-1 px-10' {...field}/>
                                                </div>
                                                <FormMessage/>
                                            </LabelInputContainer>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={control}
                                name="Social.Twitter"
                                render={({field}) => (
                                    <FormItem className='w-full'>
                                        <FormControl>
                                            <LabelInputContainer className='mb-4'>
                                                <div className="flex relative">
                                                    <FaTwitter className="text-gray-400 self-start z-50 absolute left-4 mt-4" />
                                                    <Input placeholder="Twitter" className='w-full placeholder:translate-x-1 px-10' {...field}/>
                                                </div>
                                                <FormMessage/>
                                            </LabelInputContainer>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={control}
                                name="Social.LinkedIn"
                                render={({field}) => (
                                    <FormItem className='w-full'>
                                        <FormControl>
                                            <LabelInputContainer className='flex'>
                                                <div className="flex relative">
                                                    <FaLinkedin className="text-gray-400 self-start z-50 absolute left-4 mt-4" />
                                                    <Input placeholder="LinkedIn" className='w-full placeholder:translate-x-1 px-10' {...field}/>
                                                </div>
                                                <FormMessage/>
                                            </LabelInputContainer>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={control}
                                name="Social.Instagram"
                                render={({field}) => (
                                    <FormItem className='w-full'>
                                        <FormControl>
                                            <LabelInputContainer className='flex'>
                                                <div className="flex relative">
                                                    <FaInstagram className="text-gray-400 self-start z-50 absolute left-4 mt-4" />
                                                    <Input placeholder="Instagram" className='w-full placeholder:translate-x-1 px-10' {...field}/>
                                                </div>
                                                <FormMessage/>
                                            </LabelInputContainer>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={control}
                                name="Social.Github"
                                render={({field}) => (
                                    <FormItem className='w-full'>
                                        <FormControl>
                                            <LabelInputContainer className='flex'>
                                                <div className="flex relative">
                                                    <FaGithub className="text-gray-400 self-start z-50 absolute left-4 mt-4" />
                                                    <Input placeholder="Github" className='w-full placeholder:translate-x-1 px-10' {...field}/>
                                                </div>
                                                <FormMessage/>
                                            </LabelInputContainer>
                                        </FormControl>
                                    </FormItem>
                                )}
                            />
                        </div>
                    </div>
                    <div className='w-full flex justify-end'>
                        <MovingBorderButton
                            type="submit"
                            containerClassName='h-10 w-32 my-2'
                            borderRadius="1.75rem"
                            className="bg-white dark:bg-slate-900 text-black dark:text-white border-neutral-200 dark:border-slate-800"
                        >
                            {(id && id === "1") ? "Add" : "Update"} Project
                        </MovingBorderButton>
                    </div>
                </form>
            </Form>
        </div>
    </Container>
  )
}
