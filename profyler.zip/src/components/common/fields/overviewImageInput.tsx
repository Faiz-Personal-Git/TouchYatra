import React, { useEffect, useRef, useState } from 'react'
import { IconUpload, IconUserCircle } from "@tabler/icons-react";

interface OverviewImageInputType {
  onChange: (files: File | null) => void;
  onRemove?: () => void;
  value: string | File | null | undefined;
}

export function OverviewImageInput({onChange, value, onRemove}: OverviewImageInputType) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [selectedFile, setSelectedFile] = useState<string | null>(null)

  useEffect(() => {
    if(typeof value === "string"){
      setSelectedFile(value)
    }

    if(value instanceof File){
      setSelectedFile(URL.createObjectURL(value))
    }

    if(value === null){
      setSelectedFile(null)
    }
  }, [value])

  function handleFileChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    onChange(file === undefined ? null :file)
    setSelectedFile(file !== undefined ? URL.createObjectURL(file) : null)
  }

  function handleRemoveFile(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    setSelectedFile(null)
    onChange(null)
    onRemove && onRemove();
  }

  function handleFileClick(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    fileInputRef.current?.click();
  }

  return (
    <div className="flex flex-wrap items-center gap-3 sm:gap-5">
      <div className="group">
        <span className=" flex shrink-0 justify-center items-center size-20 border-2 border-dotted border-gray-300 text-gray-400 cursor-pointer rounded-full hover:bg-gray-50 dark:border-neutral-700 dark:text-neutral-600 dark:hover:bg-neutral-700/50">
          {
            selectedFile ? (
              <img src={selectedFile || ""} alt='image' className="w-full h-full object-cover rounded-full"/>
            ) : (
              <IconUserCircle className="shrink-0 size-7" />
            )
          }
        </span>
      </div>

      <div className="grow">
        <div className="flex items-center gap-x-2">
          <input type='file' ref={fileInputRef} className='hidden' onChange={handleFileChange} />
          <button type="button" onClick={handleFileClick} className="py-2 px-3 inline-flex items-center gap-x-2 text-xs font-medium rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none" data-hs-file-upload-trigger="">
            
            <IconUpload className='shrink-0 size-4'/>
            Upload photo
          </button>
          <button type="button" onClick={handleRemoveFile} className="py-2 px-3 inline-flex items-center gap-x-2 text-xs font-semibold rounded-lg border border-gray-200 bg-white text-gray-500 shadow-sm hover:bg-gray-50 focus:outline-none focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:focus:bg-neutral-800" data-hs-file-upload-clear="">Delete</button>
        </div>
      </div>
    </div>
  )
}
