
import React from "react";
import Projects from '@/views/(protected)/Projects'
import { Metadata } from "next";

export default function page() {
  return (
    <Projects/>
  );
}

export const metadata: Metadata = {
  title: "Profyler",
  description: "Profile - Projects",
};