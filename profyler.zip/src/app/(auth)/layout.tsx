import { AuthLayout } from "@/layouts";


export default AuthLayout
