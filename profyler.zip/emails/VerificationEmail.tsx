import { env } from "@/configuration"
import {Html, Head, Font, Heading, Row, Section, Text, Button} from "@react-email/components"

interface VerificationEmailProps {
    FirstName: string;
    UserName?: string;
    Token: string;
}

export  function VerificationEmail({FirstName, UserName, Token}: VerificationEmailProps){
    return (
        <Html lang="en" dir="ltr">
            <Head>
                <title>Verify your Account</title>
                <Font 
                    fontFamily="Roboto"
                    fallbackFontFamily="Verdana"
                    webFont={{
                        url: "https://fonts.gstatic.com/s/roboto/v27/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.woff2",
                        format: 'woff2'
                    }}
                    fontWeight={400}
                    fontStyle="normal"
                />
            </Head>
            <Section>
                <Row>
                    <Heading as="h2">Hello {FirstName}</Heading>
                </Row>
                <Row>
                    <Text>
                        Thank you for registering, Please click the below button to verify your account.
                    </Text>
                </Row>
                <Row>
                    <Button href={`${env.appDomain}/verify-account/${Token}`} style={{color: '#61dafb'}}>
                        Verify here
                    </Button>
                </Row>
                <Row>
                    <Text>
                        If you did not request this code, please ignore this email.
                    </Text>
                </Row>
            </Section>
        </Html>
    )
}