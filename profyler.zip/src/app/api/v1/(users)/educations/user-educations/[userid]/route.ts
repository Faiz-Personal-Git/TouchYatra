import { asyncHandler, ApiResponse } from "@/utils";
import { EducationModel } from "@/models";
import { Collections } from "@/constants";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const UserId = params.userid as string;
    const educations = await EducationModel.aggregate([
        {$match: {UserId: UserId.toObjectId()}},
        {
            $lookup: {
                from: Collections.Countries.toLowerCase(), 
                localField: 'Country', 
                foreignField: 'Code', 
                as: 'CountryData',
                pipeline: [
                    {
                        $project: {
                            _id: 0,
                        }
                    }
                ]
            }
        },
        {
            $addFields: {
                CountryData: { $first: '$CountryData' }
            }
        },
        {
            $project: {
                __v: 0
            }
        }
    ])
    
    if(!educations?.hasLength()){
        
        return new ApiResponse(
            200, 
            educations.toRecords(),
            'Education list fetched successfully.'
        );
    }

    return new ApiResponse(
        200,
        educations.toRecords(),
        'Education list fetched successfully.'
    )

})