import { asyncHandler, ApiError, ApiResponse, serverSessions } from "@/utils";
import { ExperienceModel } from "@/models";

export const POST = asyncHandler(true, async (req: Request) => {
    const session = await serverSessions()
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const formData = await req.formData();
    const data = Object.fromEntries(formData) as Record<string, any>;
    const isForUpdate =!!data._id;

    if(isForUpdate){
        const oldRecord = await ExperienceModel.findById(data._id);
        if(!oldRecord){
            throw new ApiError(404, "Record not found.")
        }

        if(
            data.UserId? (
                oldRecord.UserId.toString() !== data.UserId.toString() && 
                oldRecord.UserId.toString()!== session.user._id?.toString()
            )
            : oldRecord.UserId.toString() !== session.user._id?.toString()
        ){
            throw new ApiError(401, "Unauthorized request.")
        }
    }

    if(!data.UserId){
        data.UserId = session.user._id?.toObjectId();
    }

    const experience = isForUpdate
        ? await ExperienceModel.findByIdAndUpdate(data._id, data, { new: true })
        : await ExperienceModel.create(data);

    if(!experience){
        throw new ApiError(500, "Failed to save experience.");
    }

    await experience.save();
    return new ApiResponse(isForUpdate? 200 : 201, experience, "Experience saved successfully.");
});