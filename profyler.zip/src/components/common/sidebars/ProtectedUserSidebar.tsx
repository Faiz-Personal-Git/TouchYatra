"use client";
import React, { useState } from "react";
import { Sidebar, SidebarBody, SidebarHeader, SidebarLink, SidebarLinksType } from "@ui/acertinityUi/sidebar";
import {Navigation} from '@ui/acertinityUi/sidebarNew'
import {
  IconArrowLeft,
  IconBrandTabler,
  IconSettings,
  IconUserBolt,
  IconArrowRight,
  IconArrowsDiff
} from "@tabler/icons-react";
import Image from "next/image";
import {Logo, LogoIcon} from '@common/logos'
import { useAuthSession } from "@/hooks";
import { useRouter } from "next/navigation";
import {signOut} from 'next-auth/react'
import {imagePlaceholders} from '@/constants'

export function ProtectedUserSidebar() {
    const router = useRouter()
    const {isLoading, isAuthenticated, session} = useAuthSession({required: true, onUnauthenticated: () => router.replace("/sign-in")})
    const [open, setOpen] = useState(true);
    const [animate, setAnimate] = useState(true)
    const links = [
      {
        label: "Dashboard",
        href: "/",
        icon: (isActive) => (
          <IconBrandTabler className={`text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0 ${isActive && "text-sky-500"}`} />
        ),
      },
      {
        label: "Profile",
        href: `/profile/${session?.user?._id}`,
        icon: (isActive) => (
          <IconUserBolt className={`text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0 ${isActive && "text-sky-500"}`} />
        ),
      },
      {
        label: "Projects",
        href: `/projects`,
        icon: (isActive) => (
          <IconUserBolt className={`text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0 ${isActive && "text-sky-500"}`} />
        ),
      },
      {
        label: "Teams",
        href: `/teams`,
        icon: (isActive) => (
          <IconUserBolt className={`text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0 ${isActive && "text-sky-500"}`} />
        ),
      },
      {
        label: "Settings",
        href: "#",
        icon: (isActive) => (
          <IconSettings className={`text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0 ${isActive && "text-sky-500"}`} />
        ),
      },
      {
        label: "Logout",
        onClick: (e: any) => {
          e.preventDefault();
          signOut();
          router.replace("/sign-in");
        },
        icon: () => (
          <IconArrowLeft className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
        ),
      },
    ] as SidebarLinksType[]

  return (
    <>
      <Sidebar open={open} setOpen={setOpen} animate={animate}>
        <SidebarBody className="justify-between gap-10 overflow-auto">

            <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
                {/* {
                    (open || !animate) ? (
                        <Logo label={`${session?.user?.FirstName} ${session?.user?.LastName}`}  icon={session?.user?.Logo && <Image src={session?.user?.Logo} className="h-7 w-7 flex-shrink-0 rounded-full" width={50} height={50} alt="Avatar" />} />
                    ) : (
                        <LogoIcon icon={session?.user?.Logo && <Image src={session?.user?.Logo} className="h-7 w-7 flex-shrink-0 rounded-full" width={50} height={50} alt="Avatar" />} />
                    )
                } */}
                <SidebarHeader 
                  name={`${session?.user?.FirstName} ${session?.user?.LastName}`} 
                  image={session?.user?.Avatar}
                  designation={session?.user?.UserType}
                />
                <div className="mt-8 flex flex-col gap-2">
                    {links.map((link, idx) => (
                        <SidebarLink key={idx} {...link} />
                    ))}
                </div>
            </div>
            <div className="flex">
                <SidebarLink
                  label={`${session?.user?.FirstName} ${session?.user?.LastName}`}
                  icon={() => (
                    <Image
                    src={session?.user?.Avatar ?? imagePlaceholders.avtar1}
                    className="h-7 w-7 flex-shrink-0 rounded-full"
                    width={50}
                    height={50}
                    alt="Avatar"
                    />
                  )}
                />
                {/* {
                  animate ? (
                    <IconArrowRight className="h-6 w-6 left-96 text-neutral-700 dark:text-neutral-200" onClick={() => setAnimate(!animate)} />
                  ) : (
                    <IconArrowsDiff className="h-6 w-6 left-96 text-neutral-700 dark:text-neutral-200" onClick={() => setAnimate(!animate)} />
                  )
                } */}
            </div>
        </SidebarBody>
      </Sidebar>
      
    </>
  )
}
