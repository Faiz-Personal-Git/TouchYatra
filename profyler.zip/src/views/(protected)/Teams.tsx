"use client";

import React, {useEffect, useRef, useState} from 'react'
import Image from 'next/image'
import { modelTypes } from '@/types'
import { useAuthSession } from '@/hooks'
import { useRouter } from 'next/navigation'
import { teamRepo } from '@/repository'
import { FaLinkedin, FaTwitter, FaGithub, FaFacebook, FaInstagram } from "react-icons/fa";
import { MovingBorderButton } from '@/components/common/ui/acertinityUi/moving-border-button';
import { imagePlaceholders } from '@/constants';
import { Container } from '@/components/common';
import { TeamFlipCard, TeamFlipCardContainer } from '@/components/specific/TeamFlipCard/TeamFlipCard';

export default function Teams() {
    const router = useRouter()
    const {isAuthenticated, isLoading, session} = useAuthSession({required: true, onUnauthenticated: () => {
        router.replace("/sign-in")
    }})
    const [fetching, setFetching] = useState(true);
    const [teams, setTeams] = useState<Array<modelTypes.Team_Members> | null>(null)

    useEffect(() => {
        ;(async function(){
            if(!session){
                return;
            }
            const res = await teamRepo.getUserTeams(session.user._id as string)
            if(res.success){
                setTeams(res.data.records)
            }
            setFetching(false)
        })()
    }, [session])

    if (isLoading || fetching) return <div>Loading...</div>

    if(!isAuthenticated) router.replace("/sign-in")


    const socialUrlRegex = /^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?$/;
  return (
    <>
      <Container>
        <div className='w-full flex justify-end'>
          <MovingBorderButton
            containerClassName='h-10 w-40'
            borderRadius="1.75rem"
            className="bg-white dark:bg-slate-900 text-black dark:text-white border-neutral-200 dark:border-slate-800"
            onClick={(e: any) => {
              e.preventDefault();
              router.push(`/teams/1`)
            }}
          >
            Add Team Member
          </MovingBorderButton>
        </div>
        <div>
          <div className='bg-white text-white py-10'>
            <div className='text-center'>
              <h1 className='text-4xl font-bold text-black'>Team</h1>
              <p className='text-xl font-light italic text-blue-500 mt-2'>Creative People</p>
            </div>
            <TeamFlipCardContainer>
              {
                teams?.map((member, idx: number) => (
                  <TeamFlipCard key={idx} member={member} onClick={() => router.push(`/teams/${member._id}`)} />
                ))
              }
              </TeamFlipCardContainer>
          </div>
        </div>
      </Container>
    </>
  )
}