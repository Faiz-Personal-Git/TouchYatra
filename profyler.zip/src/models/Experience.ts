import { Collections, databases } from "@/constants";
import { createModel } from "@/lib";
import { Document, Schema, Model } from "mongoose";

export interface Experience extends Document {
    UserId: Schema.Types.ObjectId;
    Company: string;
    JobTitle: string;
    StartDate: Date;
    EndDate: Date;
    Description: string;
    Location: string;
    Industry: string;  // Type of Industry like Technology, Management
    Website: string;
    Responsibilities: [string];
    SkillsUsed: [string];
}

const ExperienceSchema = new Schema<Experience>(
    {
        UserId: {
            type: Schema.Types.ObjectId,
            required: true,
            ref: Collections.User
        },
        Company: {
            type: String,
            required: [true, "Company name is required"]
        },
        JobTitle: {
            type: String,
            required: [true, "Job title is required"]
        },
        StartDate: {
            type: Date,
            required: [true, "Start date is required"]
        },
        EndDate: {
            type: Date
        },
        Description: {
            type: String
        },
        Location: {
            type: String
        },
        Industry: {
            type: String
        },
        Website: {
            type: String
        },
        Responsibilities: {
            type: [String]
        },
        SkillsUsed: {
            type: [String]
        }
    },
    { timestamps: true }
)

export const ExperienceModel = createModel(databases.main, Collections.Experience, ExperienceSchema) as Model<Experience>;