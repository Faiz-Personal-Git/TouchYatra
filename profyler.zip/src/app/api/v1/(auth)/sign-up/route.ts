import {ProfileModel, UserModel} from '@/models'
import { asyncHandler, ApiError, ApiResponse, sendEmail } from '@/utils';
import { env } from "@/configuration"
import { VerificationEmail } from '@emails/VerificationEmail';


export const POST = asyncHandler(true, async (req: Request) => {

    const {FirstName, LastName, UserName, Email, Password} = await req.json();

    const existingUserCount = await UserModel.countDocuments();
    if(existingUserCount === env.maxUsers){
        throw new ApiError(400, "Sorry user limit exceeded you can't signup with us.")
    }

    const existingUserNameUser = await UserModel.findOne({UserName});
    if(existingUserNameUser?.IsVerified){
        throw new ApiError(400, "Username already exists")
    }
    const existingEmailUser = await UserModel.findOne({Email});
    let token : string;
    if(existingEmailUser){
        if(existingEmailUser.IsVerified){
            throw new ApiError(400, "User already exists with this email");
        }
        if(existingUserNameUser){
            await UserModel.findByIdAndDelete(existingUserNameUser._id)
            await ProfileModel.findOneAndDelete({UserId: existingUserNameUser._id})
        }
        existingEmailUser.Password = Password;
        existingEmailUser.UserName = UserName;
        token = existingEmailUser.generateToken();
        await existingEmailUser.save();

        const profile = new ProfileModel({
            UserId: existingEmailUser._id,
            FirstName,
            LastName
        });
        await profile.save();

    }else{
        if(existingUserNameUser){
            existingUserNameUser.Password = Password;
            existingUserNameUser.Email = Email;
            token = existingUserNameUser.generateToken();
            await existingUserNameUser.save(); 

            const profile = await ProfileModel.findOne({$match: {UserId: existingUserNameUser._id}});
            if(profile){
                profile.FirstName = FirstName;
                profile.LastName = LastName;
                await profile.save({validateBeforeSave: false});
            }else{
                const profile = new ProfileModel({
                    UserId: existingUserNameUser._id,
                    FirstName,
                    LastName
                });
                await profile.save();
            }
        }else{
            const user = new UserModel({
                UserName,
                Email,
                Password,
                IsVerified: false
            });
            token = user.generateToken();
            await user.save();
            const profile = new ProfileModel({
                UserId: user._id,
                FirstName,
                LastName
            });
            await profile.save();
        }
    }

    const emailres = await sendEmail({
        to: Email,
        subject: "Verify your email",
        react: VerificationEmail({FirstName, UserName, Token: token}),
    });
    
    if(!emailres) throw new ApiError(500, "Error sending verification email");
    
    return new ApiResponse(201, null, "User registered successfully, please verify your email")
});