export const teamMemerDefaultValue = {
    UserId: "",
    MemberName: "",
    Designation: "",
    Company: "",
    Email: "",
    ImageUrl: "",
    Experience: 0,
    Bio: "",
    Skills: [],
    Social: {
        Facebook: "",
        Twitter: "",
        LinkedIn: "",
        Instagram: "",
        Github: "",
    }
}

export const projectsDefaultValue = {
    UserId: "",
    ProjectName: "",
    ProjectType: "",
    // StartDate: "",
    EndDate: null,
    Description: "",
    TechnologiesUsed: [],
    Technologies: "",
    TeamMembers: [],
    TeamMembersIds: "",
    ProjectUrl: "",
    ImageUrl: [],
    Images: "",
    Contributions: ""
}