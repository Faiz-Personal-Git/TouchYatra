import { Schema, Document, Model } from "mongoose";
import bcrypt from 'bcryptjs';
import { createModel } from "@/lib";
import { Collections, databases, UserTypes } from "@/constants";
import jwt from 'jsonwebtoken'
import { env } from "@/configuration"


export interface User extends Document {
    UserName: string;
    Email: string;
    Password: string;
    IsVerified: boolean;
    GoogleId: string;
    UserType: string;
    LastLogin: Date;
    isPasswordCorrect: (password: string) => Promise<boolean>;
    generateToken: () => string;
    isAdmin: () => boolean;
}

const UserSchema: Schema<User> = new Schema(
    {
        UserName: {
            type: String,
            required: [true, "Username is required"],
            trim: true,
            unique: true,
            lowercase: true,
            index: true
        },
        Email: {
            type: String,
            required: [true, "Email is required"],
            trim: true,
            unique: true,
            lowercase: true,
            match: [/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, "Please add a valid email"]
        },
        Password: {
            type: String,
            // required: [true, "Please enter a valid password"],
            trim: true,
            // match: [/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/, "Your password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., !@#$%^&*)."]
        },
        IsVerified: {
            type: Boolean,
            default: false
        },
        GoogleId: {
            type: String,
            unique: true
        },
        UserType: {
            type: String,
            end: UserTypes,
            default: "user"
        },
        LastLogin: {
            type: Date,
        },
    },
    {
        timestamps: true
    }
)

UserSchema.pre("save", async function (next) {
    if(!this.isModified("Password")) return next();

    this.Password = await bcrypt.hash(this.Password, 10)
    next()
})

UserSchema.methods.isPasswordCorrect = async function(password: string) : Promise<boolean> {
    return await bcrypt.compare(password, this.Password)
}

export interface UserToken {
    _id: string;
    Email: string;
    UserName: string;
}

UserSchema.methods.generateToken = function(){
    return jwt.sign(
        {
            _id: this._id,
            Email: this.Email,
            UserName: this.UserName,
        } as UserToken,
        env.jwtSecret as jwt.Secret,
        { expiresIn: env.jwtExpiry }
    )
}

UserSchema.methods.isAdmin = function(){
    return this.UserType === "admin";
}

export const UserModel = createModel(databases.main, Collections.User, UserSchema) as Model<User>