"use client";
import {UserLayout} from '@/layouts'

export default UserLayout