import { Collections } from '@/constants';
import {ProfileModel, UserModel} from '@/models'
import {ApiError, ApiResponse, asyncHandler, sendEmail} from '@/utils'
import { ForgetPasswordVerificationEmail } from '@emails/ForgetPasswordVerification';

export const GET = asyncHandler(true, async (req: Request) => {

    const {searchParams} = new URL(req.url);
    const UserName = searchParams.get("UserName");

    const user = await UserModel.findOne({
        $or: [
            {UserName: UserName?.toLowerCase()},
            {Email: UserName?.toLowerCase()}
        ]
    })

    if(!user){
        throw new ApiError(404, "User not found");
    }
    
    const Token = user.generateToken();

    const profile = await ProfileModel.findOne({UserId: user._id});

    const emailres = await sendEmail({
        to: user.Email, 
        subject: "Forgt Password",
        react: ForgetPasswordVerificationEmail({FirstName: profile?.FirstName ?? user.UserName, UserName: user.UserName, Token})
    });
    
    if(!emailres){
        throw new ApiError(500, "Error sending email.")
    }
    
    return new ApiResponse(201, null, "Email sent to your email account for reset password.");
})