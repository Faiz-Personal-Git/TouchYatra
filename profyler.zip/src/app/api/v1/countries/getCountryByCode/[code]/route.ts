import { CountryModel } from "@/models";
import { ApiResponse, asyncHandler } from "@/utils";

export const GET = asyncHandler(true, async function(req: Request, {params}: {params: {code: string}}){
    const country = await CountryModel.findOne({$match: {Code: params.code.toUpperCase()}});

    if(!country){
        return new ApiResponse(404, null, 'Country not found.');
    }

    return new ApiResponse(200, country, 'Countries fetched successfully.');
})