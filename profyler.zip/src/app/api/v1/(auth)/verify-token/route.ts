import {UserModel, UserToken} from '@/models'
import { ApiError, ApiResponse, asyncHandler } from '@/utils';


export const POST = asyncHandler(true, async (req: Request) => {
    const {Token}: {Token: string} = await req.json();
    if(!Token){
        throw new ApiError(404, "Token not found.");
    }

    const tokenRes = Token.decodeToken() as ApiResponse;

    if(!tokenRes.success){
        return tokenRes;
    }

    const tokenUser = tokenRes.data as UserToken;

    const user = await UserModel.findById(tokenUser._id);

    if(!user){
        throw new ApiError(404, "User not found");
    }

    const newToken = user.generateToken();

    return new ApiResponse(200, newToken, "User is verified.")
})