import type { Metadata } from "next";
import {MainLayout} from '@/layouts'

export const metadata: Metadata = {
  title: "Profyler",
  description: "Profile App",
};

export default MainLayout
