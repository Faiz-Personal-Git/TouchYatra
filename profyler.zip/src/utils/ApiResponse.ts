
export class ApiResponse {

  success : boolean;
  statusCode : number;
  message : string;
  data : any;
  errors : any | null = null;

  constructor(
    StatusCode : number, 
    Data: any = null, 
    Message: string = "", 
    Errors?: any, 
    Success? : boolean
  ) {
    this.success =  Success || (StatusCode >= 200 && StatusCode < 300);
    this.statusCode = StatusCode;
    this.message = Message ?? ((Success || (StatusCode >= 200 && StatusCode < 300))? "Operation Successful" : "Operation Failed");
    this.data = Data;
    this.errors = Errors;
  }
}
