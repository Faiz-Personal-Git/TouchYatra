export type envObject = {
    appDomain: string;
    mongoUri: string;
    commonDbUrl: string;
    resendApiKey: string;
    resendEmail: string;
    nextAuthSecret: string;
    cloudinaryUrl: string;
    cloudinaryApiKey: string;
    cloudinarySecret: string;
    maxUsers: number;
    googleApiKey?: string;
    googleClientKey?: string;
    googleClientSecret?: string;
    googleCaptchaSiteKey?: string;
    googleCaptchaSecretKey?: string;
    jwtSecret: string;
    jwtExpiry: string;
    maxUploadFileSize: number
}

export function getEnv(key: string) : any{
    const d = String(process.env[key]);
    // console.log(d.toIntOrZero())
    return d
}

export const env =  Object.freeze<envObject>({
    appDomain: getEnv("APP_DOMAIN"),
    mongoUri: getEnv("MONGO_URI"),
    commonDbUrl: getEnv("COMMONDB_URI"),
    resendApiKey: getEnv("RESEND_API_KEY"),
    resendEmail: getEnv("RESEND_EMAIL"),
    nextAuthSecret: getEnv("NEXTAUTH_SECRET"),
    cloudinaryUrl: getEnv("CLOUDINARY_URL"),
    cloudinaryApiKey: getEnv("CLOUDINARY_API_KEY"),
    cloudinarySecret: getEnv("CLOUDINARY_API_SECRET"),
    maxUsers: getEnv("MAX_USER"),
    googleApiKey: getEnv("GOOGLE_API_KEY"),
    googleClientKey: getEnv("GOOGLE_CLIENT_ID"),
    googleClientSecret: getEnv("GOOGLE_CLIENT_SECRET"),
    googleCaptchaSiteKey: getEnv("GOOGLE_CAPTCHA_SITE_KEY"),
    googleCaptchaSecretKey: getEnv("GOOGLE_CAPTCHA_SECRET_KEY"),
    jwtSecret: getEnv("JWT_TOKEN_SECRET"),
    jwtExpiry: getEnv("JWT_TOKEN_EXPIRY"),
    maxUploadFileSize: parseInt(getEnv("MAX_UPLOAD_FILE_SIZE")) || 3 * 1000 * 1000
})