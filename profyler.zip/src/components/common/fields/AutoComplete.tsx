import React from "react"
import { useState, useEffect, useCallback, useMemo } from "react"
import { FiX, FiChevronDown, FiCheck } from "react-icons/fi"

interface SelectDefaultOptionProps {
    value: any;
    label: any;
    disabled?: boolean;
    selected?: boolean;
}

interface MultiSelectAutocompleteProps {
  options: Array<any>
  placeholder?: string
  defaultOption?: SelectDefaultOptionProps;
  optionValue?: string;
  optionLabel?: string;
  renderValue?: (option: any) => string | number;
  renderLabel?: (option: any) => string | React.ReactElement<any> | React.ReactNode | React.JSX.Element;
  maxSelect?: number | null
  onChange?: (selectedItems: Array<any>) => void
}

export const MultiSelectAutocomplete: React.FC<MultiSelectAutocompleteProps> = ({
  options,
  placeholder,
  defaultOption,
  optionValue,
  optionLabel,
  renderValue,
  renderLabel,
  maxSelect,
  onChange,
}) => {
  const [isOpen, setIsOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedItems, setSelectedItems] = useState<Array<any>>([])
  const [focusedIndex, setFocusedIndex] = useState(-1)

  const filteredOptions = useMemo(() => {
    // return options.filter((option) => option[optionLabel].toLowerCase().includes(searchTerm.toLowerCase()))
    return options.filter((option) => JSON.stringify(option).toLowerCase().includes(searchTerm.toLowerCase()))
  }, [options, searchTerm, optionLabel])

  const handleClickOutside = useCallback((event: MouseEvent) => {
    if (!(event.target as Element).closest(".multiselect-container")) {
      setIsOpen(false)
    }
  }, [])

  useEffect(() => {
    document.addEventListener("click", handleClickOutside)
    return () => {
      document.removeEventListener("click", handleClickOutside)
    }
  }, [handleClickOutside])

  
  const checkIsSelected = (option: any, item: any) => {
    if(optionValue){
        return item[optionValue] === option[optionValue]
    }
    
    if(renderValue){
        return JSON.stringify(renderValue(item)) === JSON.stringify(renderValue(option))
    }

    return item === option
  }

  const toggleOption = (option: any) => {
    setSelectedItems((prev) => {

      const isSelected = prev.some((item) => checkIsSelected(option, item))

      let newSelectedItems: Array<any>
      if (isSelected) {

        newSelectedItems = prev.filter((item) => !checkIsSelected(option, item))

      } else {
        if (maxSelect && prev.length >= maxSelect) {
          newSelectedItems = prev
        } else {
          newSelectedItems = [...prev, option]
        }
      }
      onChange && onChange(newSelectedItems)
      return newSelectedItems
    })
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case "ArrowDown":
        e.preventDefault()
        setFocusedIndex((prev) => (prev < filteredOptions.length - 1 ? prev + 1 : prev))
        break
      case "ArrowUp":
        e.preventDefault()
        setFocusedIndex((prev) => (prev > 0 ? prev - 1 : prev))
        break
      case "Enter":
        if (focusedIndex >= 0 && focusedIndex < filteredOptions.length) {
          toggleOption(filteredOptions[focusedIndex])
        }
        break
      case "Escape":
        setIsOpen(false)
        break
      default:
        break
    }
  }

  const handleSearch = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
    setFocusedIndex(-1)
  }, [])

  const removeItem = (item: string | number) => {
    setSelectedItems((prev) => {
      const newSelectedItems = prev.filter((option) => !checkIsSelected(option, item))

      onChange && onChange(newSelectedItems)
      return newSelectedItems
    })
  }

  const clearAll = () => {
    setSelectedItems([])
    onChange && onChange([])
  }

  const renderOptionLabel = (option: any) => {
    if (renderLabel) {
      return renderLabel(option)
    }

    if(optionLabel){
        return option[optionLabel]
    }
    
    return option
  }

  const renderOptionValue = (option: any) => {
    if (renderValue) {
      return renderValue(option)
    }

    if(optionValue){
        return option[optionValue]
    }
    
    return option
  }


  return (
    <div className="multiselect-container relative w-full max-w-md">
      <div
        className="min-h-[45px] p-2 border rounded-lg bg-white shadow-sm cursor-text flex items-center gap-2 overflow-x-auto"
        onClick={() => setIsOpen(true)}
      >
        <div className="flex items-center gap-2 flex-nowrap">
          {selectedItems.map((item) => {
            const itemValue = renderValue ? renderValue(item) : optionValue? item[optionValue] : item;
            return (
                <span
                  key={Math.random() * selectedItems.length}
                  className="bg-blue-100 text-blue-800 px-2 py-1 rounded-md flex items-center gap-1 text-sm whitespace-nowrap"
                >
                  {renderOptionLabel(item)}
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      removeItem(item)
                    }}
                    className="ml-1 hover:text-blue-600"
                    aria-label={`Remove ${itemValue}`}
                  >
                    <FiX size={14} />
                  </button>
                </span>
              )
          })}
        </div>
        <input
          type="text"
          className="flex-1 outline-none min-w-[120px] bg-transparent"
          placeholder={selectedItems.length === 0 ? placeholder : ""}
          value={searchTerm}
          onChange={handleSearch}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          aria-expanded={isOpen}
          aria-haspopup="listbox"
        />
        <button
          onClick={(e) => {
            e.stopPropagation()
            setIsOpen(!isOpen)
          }}
          className="p-1 hover:bg-gray-100 rounded flex-shrink-0"
          aria-label="Toggle dropdown"
        >
          <FiChevronDown size={20} className={`transform transition-transform ${isOpen ? "rotate-180" : ""}`} />
        </button>
      </div>

      {isOpen && (
        <div className="absolute w-full mt-1 bg-white border rounded-lg shadow-lg z-10 max-h-60 overflow-auto">
          <div className="sticky top-0 bg-white border-b p-2 flex justify-between items-center">
            <span className="text-sm text-gray-500">{selectedItems.length} selected</span>
            {selectedItems.length > 0 && (
              <button onClick={clearAll} className="text-sm text-red-500 hover:text-red-600">
                Clear all
              </button>
            )}
          </div>

          {filteredOptions.length > 0 ? (
            <ul className="py-2" role="listbox">
              {defaultOption && (
                <li className="px-4 py-2 text-gray-500 cursor-not-allowed" role="option" aria-disabled="true">
                  {defaultOption.label}
                </li>
              )}
              {filteredOptions.map((option, index) => {
                const isSelected = selectedItems.some((item) => checkIsSelected(item, index))
                return (
                  <li
                    key={Math.random() * selectedItems.length}
                    className={`px-4 py-2 flex items-center gap-2 cursor-pointer ${index === focusedIndex ? "bg-gray-100" : "hover:bg-gray-50"}
                      ${isSelected ? "bg-blue-50" : ""}`}
                    onClick={() => toggleOption(option)}
                    role="option"
                    aria-selected={isSelected}
                  >
                    <div className="flex items-center gap-2 flex-1">{renderOptionLabel(option)}</div>
                    {isSelected && <FiCheck className="text-blue-500" size={16} />}
                  </li>
                )
              })}
            </ul>
          ) : (
            <div className="p-4 text-center text-gray-500">No matching options found</div>
          )}
        </div>
      )}
    </div>
  )
}

