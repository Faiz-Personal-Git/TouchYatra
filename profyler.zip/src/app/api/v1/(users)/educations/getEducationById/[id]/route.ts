import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { EducationModel } from "@/models";
import { Collections } from "@/constants";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {id: string}}) => {
    const education = await EducationModel.aggregate([
        {$match: {_id: params.id.toObjectId()}},
        {
            $lookup: {
                from: Collections.Countries.toLowerCase(), 
                localField: "Country", 
                foreignField: "Code", 
                as: "CountryData",
                pipeline: [
                    {
                        $project: {
                            _id: 0,
                        }
                    }
                ]
            }
        },
        {
            $addFields: {
                CountryData: { $first: '$CountryData' }
            }
        },
        {
            $project: {
                __v: 0
            }
        }
    ]);

    if(!education.hasLength()){
        throw new ApiError(404, "Education not found")
    }

    return new ApiResponse(
        200, 
        education[0],
        'Education fetched successfully.'
    );
})