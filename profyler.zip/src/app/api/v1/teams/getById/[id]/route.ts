import { TeamMemberModel } from "@/models";
import { ApiError, ApiResponse, asyncHandler } from "@/utils";

export const GET = asyncHandler(
    true, 
    async (req: Request, {params}: {params: {id: string}}) => {
        const teamMember = await TeamMemberModel.findById(params.id);
        
        if(!teamMember){
            throw new ApiError(404, "TeamMember not found")
        }

        return new ApiResponse(200, teamMember, "Team fetched successfully.");
    }
)