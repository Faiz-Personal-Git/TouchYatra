import { asyncHandler, ApiError, ApiResponse, serverSessions } from "@/utils";
import { EducationModel } from "@/models";

export const POST = asyncHandler(true, async (req: Request) => {
    const session = await serverSessions()
    if(!session?.user){
        throw new ApiError(401, "Please login first.")
    }

    const userId = session.user._id?.toString();
    // const {searchParams} = new URL(req.url);
    // const userId = searchParams.get("UserId")?.toString();

    const formData = await req.formData();
    const data = Object.fromEntries(formData) as Record<string, any>;
    const isForUpdate =!!data._id;

    if(isForUpdate){
        const oldRecord = await EducationModel.findById(data._id);
        if(!oldRecord){
            throw new ApiError(404, "Record not found.")
        }

        if(
            data.UserId? (
                oldRecord.UserId.toString() !== data.UserId.toString() && 
                oldRecord.UserId.toString()!== userId
            )
            : oldRecord.UserId.toString() !== userId
        ){
            throw new ApiError(401, "Unauthorized request.")
        }
    }

    if(!data.UserId){
        data.UserId = userId;
    }

    const education = isForUpdate
        ? await EducationModel.findByIdAndUpdate(data._id, data, { new: true })
        : await EducationModel.create(data);

    if(!education){
        throw new ApiError(500, "Failed to save education.");
    }

    await education.save();
    return new ApiResponse(isForUpdate? 200 : 201, education, "Educations saved successfully.");
});