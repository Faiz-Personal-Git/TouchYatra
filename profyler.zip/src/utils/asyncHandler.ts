import mongoose from 'mongoose';
import {ApiResponse, ApiError} from '@/utils';
import {dbConnect} from '@/lib';
import  "@/utils/prototypes";
import { NextRequest } from 'next/server';
   
export type RequestHandler = (req: NextRequest, res: any) => Promise<any>;

export const asyncHandler = (
  connectDbStr: string | boolean | string[], 
  requestHandler: RequestHandler,
) => {

  return async (req: NextRequest, res: any) => {
    try {
      // Connect to DB if needed
      await makeDbConnection(connectDbStr);

      // Parse multipart form data if it's a file upload request
      // if (req.headers.get('content-type')?.includes('multipart/form-data')) {
      //   return await handleFileUpload(req, requestHandler);
      // }

      // Handle regular requests
      return await asyncRequestApiHandler(() => requestHandler(req, res));
    } catch (error: any) {
      return handleError(error);
    }
  };
};


const makeDbConnection = async function(connectDbStr: string | boolean | string[]): Promise<any>{
  if(typeof connectDbStr === 'boolean' && connectDbStr === true){
    return dbConnect();
  }else if(typeof connectDbStr === "string"){
    return dbConnect(connectDbStr);
  }
  else if(Array.isArray(connectDbStr)){
    return Promise.all(connectDbStr.map((db) => dbConnect(db))); 
  }
}

const handleFileUpload = async (
  req: NextRequest,
  requestHandler: RequestHandler
): Promise<Response> => {
  try {
    // Validate content type
    const contentType = req.headers.get('content-type');
    if (!contentType?.includes('multipart/form-data')) {
      throw new ApiError(400, 'Invalid content type. Expected multipart/form-data');
    }

    // Process the request
    const response = await asyncRequestApiHandler(() => requestHandler(req, null));
    return response || new Response('No response from handler', { status: 500 });
  } catch (error: any) {
    return handleError(error);
  }
};


const asyncRequestApiHandler = async function(callback: () => Promise<any>): Promise<Response> {
  try {      
    const response = await callback();
    if(response && response instanceof ApiResponse){
      return Response.json(response, {status: response.statusCode || 200})
    }

    return Response.json(
      new ApiResponse(200, response),
      { status: 200 }
    );

  } catch (error: any) {

    return handleError(error);
  }
}

const handleError = (error: any): Response => {
  if (error instanceof ApiError) {
    return Response.json(error, { status: error.statusCode || 500 });
  } else if (error instanceof mongoose.Error) {
    let err;
    switch (error.name) {
      case "ValidationError":
        err = error as mongoose.Error.ValidationError;
        return Response.json(
          new ApiError(400, err.message, err.errors, err.stack),
          { status: 400 }
        );
      case "ValidatorError":
        err = error as mongoose.Error.ValidatorError;
        return Response.json(
          new ApiError(400, err.message, err, err.stack),
          { status: 400 }
        );
      default:
        return Response.json(
          new ApiError(500, error.message, error),
          { status: 500 }
        );
    }
  } else {
    return Response.json(
      new ApiError(
        500,
        error.message || error.name,
        error,
        error?.stack
      ),
      { status: error.status || error.statusCode || 500 }
    );
  }
}