"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import React, { useContext, useState, createContext } from "react";
import { BadgeNew } from "./Badge";
import { AnimatePresence, motion } from "framer-motion";
import { IconLayoutSidebarRightCollapse } from "@tabler/icons-react";
import { imagePlaceholders } from "@/constants/imagePlaceholders.ts";
import { cn } from "@/lib/utils.ts";

export const isMobile = () => {
    if (typeof window === "undefined") return false;
    const width = window.innerWidth;
    return width <= 1024;
};

interface SidebarContextProps {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  animate: boolean;
}

const SidebarContext = createContext<SidebarContextProps | undefined>(
  undefined
);

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider");
  }
  return context;
};

export const SidebarProvider = ({
  children,
  open: openProp,
  setOpen: setOpenProp,
  animate = true,
}: {
  children: React.ReactNode;
  open?: boolean;
  setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  animate?: boolean;
}) => {
  const [openState, setOpenState] = useState(isMobile() ? false : true);

  const open = openProp !== undefined ? openProp : openState;
  const setOpen = setOpenProp !== undefined ? setOpenProp : setOpenState;

  return (
    <SidebarContext.Provider value={{ open, setOpen, animate: animate }}>
      {children}
    </SidebarContext.Provider>
  );
};

export const SidebarBody = ({className, children}: {className?: string, children: React.ReactNode | React.ReactElement | React.JSX.Element}) => {
    const {open, setOpen} = useSidebar()
  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ x: -200 }}
            animate={{ x: 0 }}
            transition={{ duration: 0.2, ease: "linear" }}
            exit={{ x: -200 }}
            className={cn(
                "px-6  z-[100] py-10 bg-neutral-100 max-w-[14rem] lg:w-fit  fixed lg:relative  h-screen left-0 flex flex-col justify-between",
                className
            )}
          >
            <div className="flex-1 overflow-auto">
              {children}
            </div>
            {/* <div onClick={() => isMobile() && setOpen(false)}>
              <BadgeNew href="/resume" text="Read Resume" />
            </div> */}
          </motion.div>
        )}
      </AnimatePresence>
      <button
        className="fixed lg:hidden bottom-4 right-4 h-8 w-8 border border-neutral-200 rounded-full backdrop-blur-sm flex items-center justify-center z-50"
        onClick={() => setOpen(!open)}
      >
        <IconLayoutSidebarRightCollapse className="h-4 w-4 text-secondary" />
      </button>
    </>
  );
};

export const Sidebar = ({
  children,
  open,
  setOpen,
  animate,
}: {
  children: React.ReactNode;
  open?: boolean;
  setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  animate?: boolean;
}) => {
//   const [open, setOpen] = useState(isMobile() ? false : true);

  return (
    <SidebarProvider open={open} setOpen={setOpen} animate={animate}>
        {children}
    </SidebarProvider>
  );
};

export interface SidebarLinksType {
  label: string;
  href?: string;
  icon: (isActive?: boolean) => React.JSX.Element | React.ReactNode;
  condition?: boolean;
  onCLick?: (event : React.MouseEvent<HTMLButtonElement>) => void;
  className?: string;
  [key: string]: any;
}

export const SidebarLink = ({
    label,
    href,
    icon,
    condition = true,
    onClick,
    className,
    ...props
  }: SidebarLinksType) => {
    const { open, animate, setOpen } = useSidebar();
    const pathname = usePathname();
  
    if(!condition){
      return null;
    }
  
    if(onClick){
        return (
            <button
                onClick={(e: any) => {
                    onClick && onClick(e)
                    isMobile() && setOpen(false)
                }}
                className={cn(
                    "text-secondary hover:text-primary transition duration-200 flex items-center space-x-2 py-2 px-2 rounded-md text-sm"
                )}
                {...props}
            >
                {icon && icon()}
                {/* <link.icon
                    className={twMerge(
                    "h-4 w-4 flex-shrink-0",
                    isActive(link.href) && "text-sky-500"
                    )}
                /> */}
                <span>{label}</span>
            </button>
        )
    //   return (
    //     <button onClick={onClick} className={cn(
    //         "flex items-center justify-start gap-2  group/sidebar py-2", 
    //         className,
    //         "text-secondary hover:text-primary transition duration-200 space-x-2 px-2 rounded-md text-sm",
    //       )} {...props}>
  
    //       {icon && icon()}
  
    //       <motion.span
    //         animate={{
    //           display: animate ? (open ? "inline-block" : "none") : "inline-block",
    //           opacity: animate ? (open ? 1 : 0) : 1,
    //         }}
    //         className="text-neutral-700 dark:text-neutral-200 text-sm group-hover/sidebar:translate-x-1 transition duration-150 whitespace-pre inline-block !p-0 !m-0"
    //       >
    //         {label}
    //       </motion.span>
    //     </button>
    //   )
    }
  
    const isActive = (linkHref: string) => pathname === linkHref;
  
    if(href){
        return (
            <Link
                href={href}
                onClick={() => isMobile() && setOpen(false)}
                className={cn(
                    "text-secondary hover:text-primary transition duration-200 flex items-center space-x-2 py-2 px-2 rounded-md text-sm",
                    isActive(href) && "bg-white shadow-lg text-primary"
                )}
                {...props}
            >
                {icon && icon(isActive(href))}
                {/* <link.icon
                    className={twMerge(
                    "h-4 w-4 flex-shrink-0",
                    isActive(link.href) && "text-sky-500"
                    )}
                /> */}
                <span>{label}</span>
            </Link>
        )
    //   return (
    //     <Link
    //       href={href}
    //       className={cn(
    //         "flex items-center justify-start gap-2  group/sidebar py-2",
    //         className,
    //         "text-secondary hover:text-primary transition duration-200 space-x-2 px-2 rounded-md text-sm",
    //         isActive(href) && "bg-white shadow-lg text-primary"
    //       )}
    //       {...props}
    //     >
    //       {icon && icon(isActive(href))}
    
    //       <motion.span
    //         animate={{
    //           display: animate ? (open ? "inline-block" : "none") : "inline-block",
    //           opacity: animate ? (open ? 1 : 0) : 1,
    //         }}
    //         className={cn("text-neutral-700 dark:text-neutral-200 text-sm group-hover/sidebar:translate-x-1 transition duration-150 whitespace-pre inline-block !p-0 !m-0")}
    //       >
    //         {label}
    //       </motion.span>
    //     </Link>
    //   );
    }
  };

export const Navigation = ({children}: {children: React.ReactNode | React.ReactElement | React.JSX.Element}) => {

  return (
    <div className="flex flex-col space-y-1 my-10 relative z-[100]">
        {children}
    </div>
  );
};



interface SidebarHeaderProps {
    image?: string;
    name?: string;
    designation?: string;
}

export const SidebarHeader = ({image, name, designation}: SidebarHeaderProps) => {
  return (
    <div className="flex space-x-2">
      <Image
        src={image || imagePlaceholders.avtar1}
        alt="Avatar"
        height="40"
        width="40"
        className="object-cover object-top rounded-full flex-shrink-0"
      />
      <div className="flex text-sm flex-col">
        <p className="font-bold text-primary">{name}</p>
        <p className="font-light text-secondary-foreground">{designation}</p>
      </div>
    </div>
  );
};