import jwt, { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken'
import { env } from "@/configuration"
import { ApiResponse } from '@/utils/ApiResponse'

String.prototype.getFlag = function(){
    return {
        src: `https://flagcdn.com/w20/${this.toString()?.toLowerCase()}.png`,
        srcSet: `https://flagcdn.com/w40/${this.toString()?.toLowerCase()}.png 2x`
    }
}

String.prototype.decodeToken = function(){
    try {
        const token =  jwt.verify(this.toString(), env.jwtSecret as jwt.Secret);
        return new ApiResponse(200, token, "Token verified successfully");
    } catch (error) {
        if(error instanceof TokenExpiredError){
            return new ApiResponse(401, null, "Token Expired", error)
        }
        if(error instanceof JsonWebTokenError){
            return new ApiResponse(401, null, "Invalid Token", error)
        }

        return new ApiResponse(400, null, "Some error occurred while validate token", error)
    }
}

declare global {
    interface String {
        getFlag(): {src: string; srcSet: string};
        decodeToken(): ApiResponse;
    }
}

export {}