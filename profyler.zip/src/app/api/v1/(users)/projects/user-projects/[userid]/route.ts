import { asyncHandler, ApiError, ApiResponse } from "@/utils";
import { ProjectModel } from "@/models";
import { Collections } from "@/constants";

export const GET = asyncHandler(true, async (req: Request, {params}: {params: {userid: string}}) => {
    const projects = await ProjectModel.aggregate([
        {$match: {UserId: params.userid.toObjectId()}},
        {
            $unwind: {
                path: '$TeamMembers',
                preserveNullAndEmptyArrays: true
            }
        },
        {
            $lookup: {
                from: Collections.TeamMembers.toLowerCase(),
                localField: 'TeamMembers',
                foreignField: '_id',
                as: 'TeamMembers'
            }
        },
        {
            $group: {
                _id: '$_id',
                UserId: {$first: "UserId"},
                ProjectName: { $first: '$ProjectName' },
                ProjectType: { $first: '$ProjectType' },
                StartDate: { $first: '$StartDate' },
                EndDate: { $first: '$EndDate' },
                Description: { $first: '$Description' },
                TechnologiesUsed: { $first: '$TechnologiesUsed' },
                TeamMembers: { $push: '$TeamMembers' },
                ProjectUrl: { $first: '$ProjectUrl' },
                ImageUrl: { $first: '$ImageUrl' },
                Contributions: { $first: '$Contributions' },
                createdAt: { $first: '$createdAt' },
                updatedAt: { $first: '$updatedAt' },
            }
        }
    ])

    return new ApiResponse(
        200, 
        projects.toRecords(), 
        'Project fetched successfully.'
    );
})