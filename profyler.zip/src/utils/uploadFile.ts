"use server";

import { mkdir, writeFile } from "fs/promises";
import { NextRequest } from "next/server";
import path from "path";

export const uploadFile = async (file: File | File[], directoryPath: string = '') => {
    if(Array.isArray(file)){
        const filePaths = await Promise.all(file.map(async (f) => {
            return await saveFile(f, directoryPath)
        }))
        return filePaths
    } else {
        return await saveFile(file, directoryPath)
    }
    
}

export const saveFile = async (file: File, directoryPath: string) => {
    const bytes = await file.arrayBuffer();
    const buffer : any = Buffer.from(bytes);
  
    // Create uploads directory if it doesn't exist
    const uploadsDir = path.join(process.cwd(), "public/uploads" + directoryPath);
    await mkdir(uploadsDir, { recursive: true });
    
    // Save the file
    const filePath = path.join(uploadsDir, file.name.toReplaceSpace());
    await writeFile(filePath, buffer);
    return filePath.split("public")[1].toCorrectUrl();
}

export const extractFormData = async (request: NextRequest) => {
  const formData = await request.formData();
  const extractResponse: { Data: any, files: any } = { Data: {}, files: {} };

    for (const [key, value] of formData.entries()) {
      const parts = key.split('.'); // split the key into parts to handle deep objects

      let current = extractResponse.Data;
        for (let i = 0; i < parts.length - 1; i++) {
          const part = parts[i];
        if (!current[part]) {
            current[part] = {};
        }
        current = current[part];
      }
      const lastPart = parts[parts.length - 1];
        if (value instanceof File) {
         if (extractResponse.files[key]) {
          if(!Array.isArray(extractResponse.files[key])) {
            extractResponse.files[key] = [extractResponse.files[key]]
          }
           extractResponse.files[key].push(value)
        } else{
          extractResponse.files[key] = value;
        }

        } else if (typeof value === 'string' && (value.startsWith("[") && value.endsWith("]")))
        {
            try{
                current[lastPart] = JSON.parse(value)
            } catch(e) {
             current[lastPart] = value
            }
        }
      else {
       current[lastPart] = value
     }
  }

   return extractResponse
};



export const extractArrayNotationFormData = async (request: NextRequest) => {
    const formData = await request.formData()
    const result: Record<string, any> = {}
  
    for (const [key, value] of formData.entries()) {
      if (key.includes("[")) {
        // Handle nested objects and arrays
        const keys = key.split(/[[\]]+/).filter(Boolean)
        let current = result
        for (let i = 0; i < keys.length - 1; i++) {
          if (!(keys[i] in current)) {
            current[keys[i]] = isNaN(Number(keys[i + 1])) ? {} : []
          }
          current = current[keys[i]]
        }
        if (value instanceof File) {
          current[keys[keys.length - 1]] = value
        } else {
          current[keys[keys.length - 1]] = value
        }
      } else {
        if (value instanceof File) {
          result[key] = value
        } else {
          result[key] = value
        }
      }
    }

    return result;
}
