"use client";

import { useParams } from "next/navigation";
import {VerifyAccount} from '@/views/(auth)'
import { Metadata } from "next";

export default function page() {

  const {token} = useParams<{token: string}>()

  return <VerifyAccount token={token}/>
}

const metadata: Metadata = {
  title: `Profyler - Verify Account`,
  description: `Verify your account`,
  icons: {
    icon: `path to asset file`,
  },
}