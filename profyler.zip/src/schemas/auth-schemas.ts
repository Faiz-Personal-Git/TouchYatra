import {z} from 'zod';

export const signInSchema = z.object({
    Identifier: z.string({message: "Please enter username or email."}).trim(),
    Password: z.string({message: "password is required."}).trim()
});

export const usernameValidation = z
                    .string({message: "Username is required."})
                    .min(6, "Username must be atleast 6 characters")
                    .max(20, "Username must be no more than 20 characters")
                    .regex(/^[a-zA-Z0-9_-]+$/, "Username must not contain special characters");

export const emailValidation = z.string({message: "Email is required."}).email({message: "Invalid email address"});

export const signupSchema = z.object({
    FirstName: z.string({message: "First Name is required."}),
    LastName: z.string().optional(),
    UserName: usernameValidation,
    Email: emailValidation,
    Password: z
                .string({message: "Password is required."})
                .min(8, "Password must be atleast 8 characters")
                .trim()
                .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/, "Your password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., !@#$%^&*)."),
    ConfirmPassword: z.string({message: "Re-enter your password"}).trim(),
}).refine((data) => data.Password === data.ConfirmPassword, {
    message: "Re-Passwords must match with Password",
    path: ["ConfirmPassword"],
});

export const verifySchema = z.object({
    token: z.string({message: "Token is required."})
});

export const sendVerificationTokenSchema = z.object({
    UserName: z.string({message: "Please enter your username or email"})
})

export const resetPasswordSchema = z.object({
    NewPassword: z
                .string({message: "New Password is required."})
                .min(8, "Password must be atleast 8 characters")
                .trim()
                .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/, "Your password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one digit, and one special character (e.g., !@#$%^&*)."),
    ConfirmPassword: z.string({message: "Re-enter your password"}).trim(),
}).refine((data) => data.NewPassword === data.ConfirmPassword, {
    message: "ConfirmPassword must match with NewPassword",
    path: ["ConfirmPassword"],
});
