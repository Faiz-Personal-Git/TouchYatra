"use client";
import React, { useState } from "react";
import {FormField, Form, FormMessage, FormControl, FormItem, FormDescription, LabelInputContainer, Input, Label, BottomGradient} from '@common/index'
import * as z from "zod";
import {zodResolver} from '@hookform/resolvers/zod'
import {
  IconBrandGoogle,
} from "@tabler/icons-react";
import { useForm } from "react-hook-form";
import { signInSchema } from "@/schemas";
import { useToast } from "@/hooks";
import { useRouter } from "next/navigation";
import { Eye, EyeClosed, Loader2 } from "lucide-react";
import {signIn} from 'next-auth/react'
import Link from "next/link";
import Swal from 'sweetalert2'

export default function Signin() {

  const {toast} = useToast()
  const router = useRouter()
  const [passwordType, setPasswordType] = useState("password")

  const form = useForm<z.infer<typeof signInSchema>>({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      Identifier: '',
      Password: ''
    }
  })

  const {control, handleSubmit, formState} = form;


  const onSubmit = handleSubmit(async function(data: z.infer<typeof signInSchema>): Promise<void>{
    debugger
    const res = await signIn("credentials", {redirect: false, ...data})
    console.log(res);
    if(res?.error){
      Swal.fire({
        title: "Failed!",
        text: res.error ?? "Inceorrect credentials.",
        icon: "error",
        timer: 2000
      })
      return;
    }

    const SwalId = Swal.fire({
      title: "Success",
      text: "Signed in successfully",
      icon: "success",
      timer: 2000
    })

    SwalId.finally(() => {
      router.replace("/projects")
    })
  })

  return (
    <div className="max-w-md w-full mx-auto rounded-md md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black my-10">
      <h2 className="font-bold text-xl text-neutral-800 dark:text-neutral-200">
        Welcome to Profyler
      </h2>
      <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
        SignIn to Profyler with your username / email and password
      </p>

      <Form {...form}>
        <form className="my-8" onSubmit={onSubmit}>
          <FormField
            control={control}
            name="Identifier"
            render={({field}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <Label htmlFor="Identifier">Username or email address</Label>
                    <Input placeholder="Username or email address" {...field} />
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="Password"
            render={({field}) => (
              <FormItem>
                <FormControl>
                  <LabelInputContainer className="mb-4">
                    <div className="flex">
                      <Label htmlFor="Password">Password</Label>
                      <FormDescription className="flex w-full justify-end">
                          <Link href="/forget-password" className="text-blue-500 hover:text-blue-700" >Forget password?</Link>
                      </FormDescription>
                    </div>
                    <div className="flex relative">
                      <Input placeholder="Password" className="w-full" type={passwordType} {...field}/>
                      {
                          passwordType === "password" ? (
                            <EyeClosed className="self-end z-50 absolute right-3 cursor-pointer mb-2" onClick={() => setPasswordType("text")}/>
                          ) : (
                            <Eye className="self-end z-50 absolute right-3 cursor-pointer mb-2" onClick={() => setPasswordType("password")} />
                          )
                      }
                    </div>
                    <FormMessage/>
                  </LabelInputContainer>
                </FormControl>
              </FormItem>
            )}
          />

          <button className="p-[3px] relative w-full" type="submit" disabled={formState.isSubmitting}>
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
            <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent">
              {
                formState.isSubmitting ? (
                  <div className="flex justify-center">
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Signing in...
                  </div>
                ) : ("Sign In ")
              }
            </div>
          </button>

          <div className='text-center mt-3'>
            <p>
                Don't have an account? <Link href="/sign-up" rel="preload" className='text-blue-600 hover:text-blue-800'>Sign up</Link>
            </p>
          </div>

          <div className="bg-gradient-to-r from-transparent via-neutral-300 dark:via-neutral-700 to-transparent my-8 h-[1px] w-full" />

          <div className="flex flex-col space-y-4">
            <button
              className=" relative group/btn flex space-x-2 items-center justify-start px-4 w-full text-black rounded-md h-10 font-medium shadow-input bg-gray-50 dark:bg-zinc-900 dark:shadow-[0px_0px_1px_1px_var(--neutral-800)]"
              type="submit"
              onClick={(e) => {
                e.preventDefault();
                signIn("google", {callbackUrl: "/projects"});
              }}
            >
              <IconBrandGoogle className="h-4 w-4 text-neutral-800 dark:text-neutral-300" />
              <span className="text-neutral-700 dark:text-neutral-300 text-sm">
                Google
              </span>
              <BottomGradient />
            </button>
          </div>

        </form>
      </Form>
    </div>
  );
}